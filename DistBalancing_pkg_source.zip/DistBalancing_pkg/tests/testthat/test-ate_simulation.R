test_that("dgp_ate() enforces the kappa=0/kappa=1 boundary conditions on gamma(X)", {
  set.seed(1)
  n <- 500; p <- 10
  e_coef <- rep(0.1, p); mu0_coef <- rep(c(0.5, -0.5), each = p / 2)
  f_coef <- rep(c(-0.3, 0.3), each = p / 2); c_const <- 1

  d0 <- dgp_ate(0, n, p, e_coef, mu0_coef, f_coef, c_const, sigma = 0)
  gamma0 <- (1 - d0$e) * d0$mu1 + d0$e * d0$mu0
  expect_equal(gamma0, rep(c_const, n), tolerance = 1e-8)  # constant at kappa=0

  d1 <- dgp_ate(1, n, p, e_coef, mu0_coef, f_coef, c_const, sigma = 0)
  gamma1 <- (1 - d1$e) * d1$mu1 + d1$e * d1$mu0
  fX <- c_const + as.numeric(d1$X %*% f_coef)
  expect_equal(gamma1, fX, tolerance = 1e-8)                # equals f(X) at kappa=1
  expect_true(stats::sd(gamma1) > 0.01)                     # genuinely non-constant

  d_half <- dgp_ate(0.5, n, p, e_coef, mu0_coef, f_coef, c_const, sigma = 0)
  gamma_half <- (1 - d_half$e) * d_half$mu1 + d_half$e * d_half$mu0
  fX_half <- c_const + as.numeric(d_half$X %*% f_coef)
  expect_equal(gamma_half, 0.5 * c_const + 0.5 * fX_half, tolerance = 1e-8)

  expect_error(dgp_ate(1.5, n, p), "kappa")
})

test_that("dgp_ate() propensity stays safely bounded away from 0/1", {
  set.seed(2)
  d <- dgp_ate(0, n = 5000, p = 10)
  expect_true(all(d$e > 0.1 & d$e < 0.9))
})

test_that("true_ate() is reproducible and stable across a large Monte Carlo sample", {
  a <- true_ate(0, n_mc = 3e5, seed = 42)
  b <- true_ate(0, n_mc = 3e5, seed = 42)
  expect_equal(a, b)
  expect_true(is.finite(a))
})

test_that("plugin_ci() and center_adjusted_plugin_ci() agree on the point estimate but not the SE", {
  set.seed(3)
  d <- dgp_ate(0, n = 300, p = 4)
  w <- rep(1, 300)  # unweighted, to isolate the variance-construction difference
  p1 <- plugin_ci(d$Y, d$A, w)
  p2 <- center_adjusted_plugin_ci(d$Y, d$A, d$X, w)
  expect_equal(p1$estimate, p2$estimate, tolerance = 1e-8)
  expect_equal(p1$estimate, ate_weighting_estimate(d$Y, d$A, w), tolerance = 1e-8)
  expect_true(p1$ci[1] < p1$ci[2])
  expect_true(p2$ci[1] < p2$ci[2])
})

test_that("plugin_ci() / center_adjusted_plugin_ci() give roughly nominal coverage in a well-behaved case", {
  skip_on_cran()
  set.seed(4)
  truth <- true_ate(0, n_mc = 2e6, seed = 1)
  covered <- replicate(200, {
    d <- dgp_ate(0, n = 400, p = 4)
    w <- rep(1, 400)
    ci <- plugin_ci(d$Y, d$A, w)$ci
    truth >= ci[1] && truth <= ci[2]
  })
  expect_true(mean(covered) > 0.85)  # loose sanity bound, not a strict calibration test
})
