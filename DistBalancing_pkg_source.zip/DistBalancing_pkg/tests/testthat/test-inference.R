test_that("bug fix demonstration: rescaling before vs. after computing the volatility index can select a different subsample size", {
  # Minimal, deterministic illustration of why order matters (Summary item
  # "correcting the subsampling calculation" / Appendix A.8 Algorithm 1).
  # Three candidate m's, with RAW (unscaled) CI half-widths that are *locally flattest*
  # (lowest volatility) at m2 -- so the old, buggy order (compute VI on raw bounds)
  # would pick m2. But once every bound is rescaled by sqrt(m/n), the *scaled* bounds
  # are locally flattest at m3 instead -- which is what Algorithm 1 actually requires.
  n <- 400
  grid <- c(m1 = 50, m2 = 100, m3 = 200)
  raw_lower <- c(-1.00, -0.60, -0.30)
  raw_upper <- c(1.00, 0.60, 0.50)

  # "Old" (buggy) selection: volatility computed directly on the raw bounds.
  vi_raw <- function(i) sd(raw_lower[max(1, i - 1):min(3, i + 1)]) +
    sd(raw_upper[max(1, i - 1):min(3, i + 1)])
  old_best <- which.min(vapply(1:3, vi_raw, numeric(1)))

  # "New" (fixed) selection: rescale every bound by sqrt(m/n) *first*, per Algorithm 1.
  scale_factor <- sqrt(grid / n)
  scaled_lower <- scale_factor * raw_lower
  scaled_upper <- scale_factor * raw_upper
  vi_scaled <- function(i) sd(scaled_lower[max(1, i - 1):min(3, i + 1)]) +
    sd(scaled_upper[max(1, i - 1):min(3, i + 1)])
  new_best <- which.min(vapply(1:3, vi_scaled, numeric(1)))

  expect_false(identical(old_best, new_best))
})

test_that("subsample_ci() at a fixed m matches moonboot::mboot()/mboot.ci() directly", {
  set.seed(123)
  n <- 80
  d <- dgp_iv(1, n = n, p = 4)
  m_fixed <- 20
  B <- 60

  # estimand = "ate" has a single component, so subsample_ci() draws from the RNG
  # stream exactly once (per moonboot::mboot() call below), keeping this
  # reproduction's RNG draw order identical to the package's internal one.
  res <- subsample_ci(d$X, d$Z, d$Y, density = "gaussian", m = m_fixed, B = B,
                       estimand = "ate", seed = 123)

  # Reproduce the same computation independently, calling moonboot directly on the
  # same statistic, to confirm subsample_ci() is a thin, correctly-wired wrapper.
  gram <- cfd_kernel_gram(d$X, "gaussian")
  K <- gram$K
  lambda <- default_lambda(n)
  dat <- data.frame(Z = d$Z, Y = d$Y)

  stat_fn <- function(dat, indices) {
    Zs <- dat$Z[indices]
    if (length(unique(Zs)) < 2) return(NA_real_)
    w_sub <- cfd_weights(Z = Zs, K = K[indices, indices, drop = FALSE], lambda = lambda)$w
    ate_weighting_estimate(dat$Y[indices], Zs, w_sub)
  }

  set.seed(123)
  full_w <- cfd_weights(Z = d$Z, K = K, lambda = lambda)$w
  full_ate <- ate_weighting_estimate(d$Y, d$Z, full_w)
  boot_out <- moonboot::mboot(dat, stat_fn, m = m_fixed, R = B, replace = FALSE)
  expected_ci <- moonboot::mboot.ci(boot_out, conf = 0.95, tau = sqrt, types = "basic")$basic

  expect_equal(unname(res$best_m$ate), m_fixed)
  expect_equal(unname(res$full_estimate$ate), unname(full_ate), tolerance = 1e-8)
  expect_equal(unname(res$ci$ate), unname(expected_ci), tolerance = 1e-6)
})

test_that("subsample_ci() CI direction matches the pivot-inversion formula (not the naive '+' formula)", {
  # Direct, minimal check of the Summary's reported bug: with a MINUS sign and the
  # quantile probabilities swapped, LL = tau_hat - sqrt(m/n)*(q_hi_raw - tau_hat) and
  # UL = tau_hat - sqrt(m/n)*(q_lo_raw - tau_hat), where q_lo_raw/q_hi_raw are the
  # alpha/2 and 1-alpha/2 quantiles of the *raw* (unscaled) subsample replicates --
  # this is NOT the same interval as tau_hat + sqrt(m/n)*(q_lo_raw/q_hi_raw - tau_hat)
  # unless the raw replicate distribution is symmetric about tau_hat.
  set.seed(42)
  n <- 100
  d <- dgp_iv(1, n = n, p = 4)
  m <- 25
  B <- 200

  gram <- cfd_kernel_gram(d$X, "gaussian")
  K <- gram$K
  lambda <- default_lambda(n)
  full_w <- cfd_weights(Z = d$Z, K = K, lambda = lambda)$w
  full_ate <- ate_weighting_estimate(d$Y, d$Z, full_w)

  set.seed(7)
  raw <- numeric(B)
  for (b in seq_len(B)) {
    idx <- sample.int(n, m, replace = FALSE)
    w_sub <- cfd_weights(Z = d$Z[idx], K = K[idx, idx, drop = FALSE], lambda = lambda)$w
    raw[b] <- ate_weighting_estimate(d$Y[idx], d$Z[idx], w_sub)
  }
  # Skew the raw replicates asymmetrically around full_ate so the two formulas provably differ.
  raw <- full_ate + ifelse(raw > full_ate, 3, 1) * (raw - full_ate)

  sf <- sqrt(m / n)
  q <- stats::quantile(raw, c(0.025, 0.975))
  correct_LL <- full_ate - sf * (q[["97.5%"]] - full_ate)
  correct_UL <- full_ate - sf * (q[["2.5%"]] - full_ate)
  naive_LL <- full_ate + sf * (q[["2.5%"]] - full_ate)
  naive_UL <- full_ate + sf * (q[["97.5%"]] - full_ate)
  expect_false(isTRUE(all.equal(c(correct_LL, correct_UL), c(naive_LL, naive_UL))))

  scaled <- full_ate - sf * (raw - full_ate)
  reported <- stats::quantile(scaled, c(0.025, 0.975))
  expect_equal(unname(reported[["2.5%"]]), unname(correct_LL), tolerance = 1e-8)
  expect_equal(unname(reported[["97.5%"]]), unname(correct_UL), tolerance = 1e-8)
})

test_that("subsample_ci() end-to-end smoke test (ATE and LATE) returns finite, ordered CIs", {
  set.seed(1)
  n <- 150
  d <- dgp_iv(1, n = n, p = 4)

  res_late <- subsample_ci(d$X, d$Z, d$Y, d$A, density = "gaussian", B = 40,
                            m_R = 20, estimand = "late", seed = 1)
  expect_true(res_late$ci$late[1] <= res_late$ci$late[2])
  expect_true(res_late$best_m$late >= 3)
  expect_true(is.list(res_late$boot))

  res_ate <- subsample_ci(d$X, d$Z, d$Y, density = "gaussian", B = 40,
                           m_R = 20, estimand = "ate", seed = 1)
  expect_true(res_ate$ci$ate[1] <= res_ate$ci$ate[2])
})

test_that("subsample_ci() `m` supplied directly skips the automatic search", {
  set.seed(4)
  n <- 100
  d <- dgp_iv(1, n = n, p = 4)

  res <- subsample_ci(d$X, d$Z, d$Y, density = "gaussian", B = 40, m = 25,
                       estimand = "ate", seed = 4)
  expect_equal(res$best_m$ate, 25)
})

test_that("bootstrap_ci() smoke test returns a valid interval", {
  set.seed(2)
  n <- 100
  d <- dgp_iv(1, n = n, p = 4)
  res <- bootstrap_ci(d$X, d$Z, d$Y, d$A, method = "gaussian", B = 40,
                       estimand = "late", seed = 2)
  expect_true(res$ci$late[1] <= res$ci$late[2])
})

test_that("wald_ci() constructs estimate +/- z*se", {
  out <- wald_ci(estimate = 2, se = 0.5, alpha = 0.05)
  expect_equal(out$ci, c(2 - qnorm(0.975) * 0.5, 2 + qnorm(0.975) * 0.5))
  expect_equal(out$estimate, 2)
  expect_equal(out$se, 0.5)
})

test_that("subsample_ci() and bootstrap_ci() return a Wald CI alongside the percentile CI", {
  set.seed(3)
  n <- 100
  d <- dgp_iv(1, n = n, p = 4)

  res_ss <- subsample_ci(d$X, d$Z, d$Y, density = "gaussian", m = 20,
                          B = 40, estimand = "ate", seed = 3)
  expect_true(is.finite(res_ss$se[["ate"]]))
  expect_equal(res_ss$wald_ci$ate$ci,
               c(res_ss$full_estimate$ate - qnorm(0.975) * res_ss$se[["ate"]],
                 res_ss$full_estimate$ate + qnorm(0.975) * res_ss$se[["ate"]]))

  res_boot <- bootstrap_ci(d$X, d$Z, d$Y, method = "gaussian", B = 40,
                            estimand = "ate", seed = 3)
  expect_true(is.finite(res_boot$se[["ate"]]))
  expect_equal(res_boot$wald_ci$ate$ci,
               c(res_boot$full_estimate$ate - qnorm(0.975) * res_boot$se[["ate"]],
                 res_boot$full_estimate$ate + qnorm(0.975) * res_boot$se[["ate"]]))

  # Passing a precomputed full_w should match the internally-computed one.
  gram <- cfd_kernel_gram(d$X, "gaussian")
  full_w <- cfd_weights(Z = d$Z, K = gram$K, lambda = default_lambda(n))$w
  res_boot2 <- bootstrap_ci(d$X, d$Z, d$Y, method = "gaussian", B = 40,
                             estimand = "ate", seed = 3, full_w = full_w)
  expect_equal(res_boot2$full_estimate$ate, res_boot$full_estimate$ate, tolerance = 1e-8)
})

test_that("subsample_ci()'s full_estimate matches cfd_weights() under the same moment_gamma/moment_Q/moment_features", {
  set.seed(31)
  n <- 60
  d <- dgp_iv(1, n = n, p = 4)
  feats <- function(X) cbind(X, X^2)

  res <- subsample_ci(d$X, d$Z, d$Y, density = "gaussian", m = 15, B = 20,
                       estimand = "ate", seed = 31, moment_gamma = 10,
                       moment_Q = diag(8) * 3, moment_features = feats)

  expected_w <- cfd_weights(Z = d$Z, X = d$X, density = "gaussian",
                             lambda = default_lambda(n), moment_gamma = 10,
                             moment_Q = diag(8) * 3, moment_features = feats)$w
  expected_ate <- ate_weighting_estimate(d$Y, d$Z, expected_w)

  expect_equal(unname(res$full_estimate$ate), unname(expected_ate), tolerance = 1e-8)

  # And, as a contrast, moment_gamma = 0 should NOT match this moment_gamma = 10
  # full-sample estimate (i.e. the pass-through actually changes the estimate).
  res_off <- subsample_ci(d$X, d$Z, d$Y, density = "gaussian", m = 15, B = 20,
                           estimand = "ate", seed = 31)
  expect_false(isTRUE(all.equal(unname(res$full_estimate$ate),
                                 unname(res_off$full_estimate$ate))))
})

test_that("bootstrap_ci()'s full_estimate matches cfd_weights() under the same moment_gamma", {
  set.seed(32)
  n <- 60
  d <- dgp_iv(1, n = n, p = 4)

  res <- bootstrap_ci(d$X, d$Z, d$Y, method = "gaussian", B = 20,
                       estimand = "ate", seed = 32, moment_gamma = 10)
  expected_w <- cfd_weights(Z = d$Z, X = d$X, density = "gaussian",
                             lambda = default_lambda(n), moment_gamma = 10)$w
  expected_ate <- ate_weighting_estimate(d$Y, d$Z, expected_w)
  expect_equal(unname(res$full_estimate$ate), unname(expected_ate), tolerance = 1e-8)
})

test_that("subsample_ci() and bootstrap_ci() reject a user-supplied Q with a clear error", {
  set.seed(33)
  n <- 40
  d <- dgp_iv(1, n = n, p = 4)
  custom_Q <- diag(n) * 0.01

  expect_error(
    subsample_ci(d$X, d$Z, d$Y, density = "gaussian", Q = custom_Q, estimand = "ate"),
    "cannot be reused across subsamples"
  )
  expect_error(
    bootstrap_ci(d$X, d$Z, d$Y, method = "gaussian", Q = custom_Q, estimand = "ate"),
    "cannot be reused across bootstrap resamples"
  )
})

test_that("bootstrap_ci() rejects moment_gamma with a non-kernel method", {
  set.seed(34)
  n <- 40
  d <- dgp_iv(1, n = n, p = 4)
  expect_error(
    bootstrap_ci(d$X, d$Z, d$Y, method = "ipw", moment_gamma = 10, estimand = "ate"),
    "requires a kernel"
  )
})
