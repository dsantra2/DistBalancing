test_that("cfd_weights() satisfies the sum-to-group-size constraints (eq. 13/17)", {
  set.seed(10)
  n <- 40
  X <- matrix(rnorm(n * 3), n, 3)
  Z <- rbinom(n, 1, 0.5)
  res <- cfd_weights(Z, X, density = "gaussian")
  expect_true(all(res$w >= -1e-8))
  expect_equal(sum(res$w[Z == 1]), sum(Z == 1), tolerance = 1e-4)
  expect_equal(sum(res$w[Z == 0]), sum(Z == 0), tolerance = 1e-4)
})

test_that("cfd_weights() Q/q match the paper's eq. (17) three-way construction", {
  set.seed(11)
  n <- 25
  X <- matrix(rnorm(n * 2), n, 2)
  Z <- rbinom(n, 1, 0.5)
  lambda <- default_lambda(n)
  gram <- cfd_kernel_gram(X, "gaussian")
  K <- gram$K
  i1 <- as.numeric(Z == 1); i0 <- as.numeric(Z == 0)
  n1 <- sum(i1); n0 <- sum(i0)
  D1 <- diag(i1); D0 <- diag(i0); one <- rep(1, n)
  Qb0 <- (D1 %*% K %*% D1) / n1^2 + (D0 %*% K %*% D0) / n0^2 - (D1 %*% K %*% D0) / (n1 * n0)
  Q_expected <- 2 * Qb0 + lambda^2 * diag(n)
  q_expected <- -2 * ((D1 %*% K %*% one) / (n1 * n) + (D0 %*% K %*% one) / (n0 * n))

  res <- cfd_weights(Z, X, density = "gaussian", bandwidth = gram$bandwidth, lambda = lambda)
  expect_equal(res$Q, Q_expected, tolerance = 1e-8)
  expect_equal(as.numeric(res$q), as.numeric(q_expected), tolerance = 1e-8)
})

test_that("cfd_weights() Q/q match the two-way objective of eq. (12) when three_way = FALSE", {
  set.seed(111)
  n <- 25
  X <- matrix(rnorm(n * 2), n, 2)
  Z <- rbinom(n, 1, 0.5)
  lambda <- default_lambda(n)
  gram <- cfd_kernel_gram(X, "gaussian")
  K <- gram$K
  i1 <- as.numeric(Z == 1); i0 <- as.numeric(Z == 0)
  n1 <- sum(i1); n0 <- sum(i0)
  D1 <- diag(i1); D0 <- diag(i0); one <- rep(1, n)
  Q_expected <- (D1 %*% K %*% D1) / n1^2 + (D0 %*% K %*% D0) / n0^2 + lambda^2 * diag(n)
  q_expected <- -2 * ((D1 %*% K %*% one) / (n1 * n) + (D0 %*% K %*% one) / (n0 * n))

  res <- cfd_weights(Z, X, density = "gaussian", bandwidth = gram$bandwidth, lambda = lambda,
                      three_way = FALSE)
  expect_equal(res$Q, Q_expected, tolerance = 1e-8)
  expect_equal(as.numeric(res$q), as.numeric(q_expected), tolerance = 1e-8)
})

test_that("cfd_weights()'s objective equals the sum of pairwise squared MMDs (three_way = TRUE: treated-vs-pooled + control-vs-pooled + treated-vs-control; three_way = FALSE: treated-vs-pooled + control-vs-pooled only)", {
  # Direct brute-force check, independent of the D1/D0/K algebra used inside
  # cfd_weights() itself: build the treated/control/pooled empirical measures
  # implied by an arbitrary probe weight vector w, compute their pairwise
  # MMD^2's directly from the kernel matrix, and compare against w'Qw + q'w
  # (up to the w-independent constant, which cancels when comparing two w's).
  set.seed(112)
  n <- 22
  X <- matrix(rnorm(n * 2), n, 2)
  Z <- rbinom(n, 1, 0.5)
  gram <- cfd_kernel_gram(X, "gaussian")
  K <- gram$K
  n1 <- sum(Z == 1); n0 <- sum(Z == 0)

  mmd2 <- function(a, b) as.numeric(t(a) %*% K %*% a - 2 * t(a) %*% K %*% b + t(b) %*% K %*% b)

  obj_direct <- function(w, three_way) {
    a <- ifelse(Z == 1, w, 0) / n1
    b <- ifelse(Z == 0, w, 0) / n0
    t_ <- rep(1 / n, n)
    if (three_way) mmd2(a, t_) + mmd2(b, t_) + mmd2(a, b) else mmd2(a, t_) + mmd2(b, t_)
  }

  for (tw in c(TRUE, FALSE)) {
    res <- cfd_weights(Z, X, density = "gaussian", bandwidth = gram$bandwidth,
                        lambda = 0, three_way = tw)
    w1 <- rnorm(n); w2 <- rnorm(n)
    via_qp <- function(w) as.numeric(t(w) %*% res$Q %*% w + t(res$q) %*% w)
    expect_equal(obj_direct(w1, tw) - obj_direct(w2, tw),
                 via_qp(w1) - via_qp(w2), tolerance = 1e-6)
  }
})

test_that("a user-supplied Q matrix is used directly (flexible Q hook)", {
  set.seed(12)
  n <- 20
  Z <- rbinom(n, 1, 0.5)
  custom_Q <- diag(n) * 0.01
  res <- cfd_weights(Z, Q = custom_Q)
  expect_equal(res$Q, custom_Q)
  expect_true(all(res$w >= -1e-8))
})

test_that("a user-supplied custom density (kernel_fun) is honored", {
  set.seed(13)
  n <- 20
  X <- matrix(rnorm(n * 2), n, 2)
  Z <- rbinom(n, 1, 0.5)
  my_density <- cfd_density("custom", kernel_fun = function(D, bandwidth) exp(-D / bandwidth),
                             distance = "manhattan")
  res <- cfd_weights(Z, X, density = my_density)
  expect_true(all(is.finite(res$w)))
})

test_that("bug fix: the energy-distance QP solves reliably via solve_qp_safe()", {
  set.seed(14)
  n <- 60
  X <- matrix(rnorm(n * 5), n, 5)
  Z <- rbinom(n, 1, 0.5)
  # A tiny lambda stresses the conditionally-PSD-only energy kernel the hardest.
  res <- cfd_weights(Z, X, density = "energy", lambda = 1e-10)
  expect_true(all(is.finite(res$w)))
  expect_true(all(res$w >= -1e-6))
})

test_that("solve_qp_safe(): optiSolve and the quadprog fallback agree on a hand-derived optimum", {
  # min w'Qw + q'w s.t. sum(w) = 2, w >= 0, with Q = I, q = c(-1, -3): an interior
  # (non-boundary) solution, chosen so the linear and quadratic terms interact
  # asymmetrically -- this is what exposes a missing factor of 2 in the quadprog
  # fallback's Dmat (Bug fix, post-release: `Dmat <- Qmat` should be `2 * Qmat`,
  # since quadprog::solve.QP solves `1/2 w'Dw - d'w`, not `w'Dw - d'w`).
  # By Lagrangian calculus, the true optimum is w = (0.5, 1.5); the (fixed) bug
  # instead gave w = (0, 2).
  Q <- diag(2); q <- c(-1, -3)
  Amat <- matrix(c(1, 1), 1, 2); dvec <- 2
  expected <- c(0.5, 1.5)

  res_opti <- .try_optisolve(Q, q, Amat, dvec, 0, TRUE)
  expect_false(is.null(res_opti))  # also regression-tests the lincon() `name` fix
  expect_equal(unname(res_opti), expected, tolerance = 1e-5)

  res_qp <- .try_quadprog(Q, q, Amat, dvec, 0)
  expect_equal(res_qp, expected, tolerance = 1e-8)
})

test_that("solve_qp_safe() eigenvalue-floors an indefinite Q and still solves", {
  set.seed(15)
  n <- 10
  # An intentionally indefinite matrix (negative eigenvalues), mimicking -D for ED.
  M <- matrix(rnorm(n * n), n, n); Qbad <- -(M %*% t(M)) / n
  Amat <- matrix(1, 1, n); dvec <- n
  res <- solve_qp_safe(Qbad, rep(0, n), Amat, dvec)
  expect_true(res$jittered)
  expect_true(all(is.finite(res$w)))
})

test_that("default_lambda() satisfies lambda = o(n^-1) and .check_lambda_rate warns otherwise", {
  expect_lt(default_lambda(100) * 100, 1)
  expect_lt(default_lambda(10000) * 10000, default_lambda(100) * 100)  # ratio shrinks
  expect_warning(cfd_weights(rbinom(20, 1, 0.5), Q = diag(20), lambda = 1 / 20 * 2),
                  "does not satisfy")
})

test_that("moment_balance_gram() matches a direct, brute-force computation of m(w)'Qm m(w)", {
  set.seed(20)
  n <- 30; d <- 3
  X <- matrix(rnorm(n * d), n, d)
  Z <- rbinom(n, 1, 0.5)
  Qm <- diag(d) * 2  # arbitrary, non-default weighting

  mb <- moment_balance_gram(X, Z, Qm = Qm, three_way = TRUE)
  w <- rnorm(n)  # arbitrary probe weight vector (need not satisfy QP constraints)

  n1 <- sum(Z == 1); n0 <- sum(Z == 0)
  xbar <- colMeans(X)
  m1 <- as.numeric(t(X) %*% (w * (Z == 1))) / n1 - xbar
  m0 <- as.numeric(t(X) %*% (w * (Z == 0))) / n0 - xbar
  direct <- as.numeric(t(m1) %*% Qm %*% m1 + t(m0) %*% Qm %*% m0 +
                          t(m1 - m0) %*% Qm %*% (m1 - m0))
  via_gram <- as.numeric(t(w) %*% mb$Q %*% w + t(mb$q) %*% w)
  # via_gram omits the w-independent constant, so the two agree up to that constant --
  # check instead that the *difference* between two w's matches (constant cancels).
  w2 <- rnorm(n)
  m1b <- as.numeric(t(X) %*% (w2 * (Z == 1))) / n1 - xbar
  m0b <- as.numeric(t(X) %*% (w2 * (Z == 0))) / n0 - xbar
  direct2 <- as.numeric(t(m1b) %*% Qm %*% m1b + t(m0b) %*% Qm %*% m0b +
                           t(m1b - m0b) %*% Qm %*% (m1b - m0b))
  via_gram2 <- as.numeric(t(w2) %*% mb$Q %*% w2 + t(mb$q) %*% w2)
  expect_equal(direct - direct2, via_gram - via_gram2, tolerance = 1e-8)
})

test_that("cfd_weights(moment_gamma = 0) is unaffected (regression: default behavior unchanged)", {
  set.seed(21)
  n <- 25
  X <- matrix(rnorm(n * 2), n, 2)
  Z <- rbinom(n, 1, 0.5)
  res0 <- cfd_weights(Z, X, density = "gaussian", moment_gamma = 0)
  res_default <- cfd_weights(Z, X, density = "gaussian")
  expect_equal(res0$w, res_default$w, tolerance = 1e-10)
})

test_that("moment_balance_gram(features = NULL) matches an explicit identity feature map", {
  set.seed(23)
  n <- 25; d <- 3
  X <- matrix(rnorm(n * d), n, d)
  Z <- rbinom(n, 1, 0.5)

  mb_default <- moment_balance_gram(X, Z, three_way = TRUE)
  mb_identity <- moment_balance_gram(X, Z, three_way = TRUE, features = function(X) X)
  expect_equal(mb_default$Q, mb_identity$Q)
  expect_equal(mb_default$q, mb_identity$q)
})

test_that("moment_balance_gram() with a nonlinear feature map matches a direct computation", {
  set.seed(24)
  n <- 30; d <- 2
  X <- matrix(rnorm(n * d), n, d)
  Z <- rbinom(n, 1, 0.5)
  quad_features <- function(X) cbind(X, X^2)  # balance means AND second moments
  Qm <- diag(2 * d)  # unweighted, sized to the 2*d-dimensional feature space

  mb <- moment_balance_gram(X, Z, Qm = Qm, three_way = TRUE, features = quad_features)
  expect_equal(dim(mb$Q), c(n, n))
  expect_equal(length(mb$q), n)

  Phi <- quad_features(X)
  n1 <- sum(Z == 1); n0 <- sum(Z == 0)
  phibar <- colMeans(Phi)
  w <- rnorm(n); w2 <- rnorm(n)
  direct_imbalance <- function(w) {
    m1 <- as.numeric(t(Phi) %*% (w * (Z == 1))) / n1 - phibar
    m0 <- as.numeric(t(Phi) %*% (w * (Z == 0))) / n0 - phibar
    as.numeric(t(m1) %*% Qm %*% m1 + t(m0) %*% Qm %*% m0 + t(m1 - m0) %*% Qm %*% (m1 - m0))
  }
  via_gram <- function(w) as.numeric(t(w) %*% mb$Q %*% w + t(mb$q) %*% w)
  # (see the identity-feature test above for why we compare differences, not raw values)
  expect_equal(direct_imbalance(w) - direct_imbalance(w2),
               via_gram(w) - via_gram(w2), tolerance = 1e-8)
})

test_that("moment_balance_gram() rejects a features() function with the wrong row count", {
  X <- matrix(rnorm(20), 10, 2)
  Z <- rbinom(10, 1, 0.5)
  expect_error(moment_balance_gram(X, Z, features = function(X) X[1:5, ]),
               "same number of rows")
})

test_that("cfd_weights(moment_features = ...) reduces imbalance in the *nonlinear* feature space", {
  set.seed(25)
  n <- 200
  X <- matrix(rnorm(n * 3), n, 3)
  # Confound both the mean AND the spread of X[,1] with treatment, so a quadratic
  # (second-moment) imbalance genuinely exists for the nonlinear penalty to fix.
  Z <- rbinom(n, 1, plogis(X[, 1] * 0.5 + (X[, 1]^2 - 1) * 0.5))
  quad_features <- function(X) cbind(X, X^2)
  Phi <- quad_features(X)
  phibar <- colMeans(Phi)

  imbalance <- function(w) {
    n1 <- sum(Z == 1); n0 <- sum(Z == 0)
    m1 <- as.numeric(t(Phi) %*% (w * (Z == 1))) / n1 - phibar
    m0 <- as.numeric(t(Phi) %*% (w * (Z == 0))) / n0 - phibar
    sum(m1^2) + sum(m0^2)
  }

  res_off <- cfd_weights(Z, X, density = "gaussian", moment_gamma = 0)
  res_on  <- cfd_weights(Z, X, density = "gaussian", moment_gamma = 5,
                          moment_features = quad_features)
  expect_lt(imbalance(res_on$w), imbalance(res_off$w))
  expect_true(all(res_on$w >= -1e-6))
  expect_equal(sum(res_on$w[Z == 1]), sum(Z == 1), tolerance = 1e-3)
  expect_equal(sum(res_on$w[Z == 0]), sum(Z == 0), tolerance = 1e-3)
})

test_that("cfd_weights(moment_gamma > 0) reduces the weighted covariate-mean imbalance", {
  set.seed(22)
  n <- 200
  X <- matrix(rnorm(n * 4), n, 4)
  Z <- rbinom(n, 1, plogis(X[, 1] * 0.8))  # confounded, so imbalance exists to fix
  xbar <- colMeans(X)

  imbalance <- function(w) {
    n1 <- sum(Z == 1); n0 <- sum(Z == 0)
    m1 <- as.numeric(t(X) %*% (w * (Z == 1))) / n1 - xbar
    m0 <- as.numeric(t(X) %*% (w * (Z == 0))) / n0 - xbar
    sum(m1^2) + sum(m0^2)
  }

  res_off <- cfd_weights(Z, X, density = "gaussian", moment_gamma = 0)
  res_on <- cfd_weights(Z, X, density = "gaussian", moment_gamma = 5)
  expect_lt(imbalance(res_on$w), imbalance(res_off$w))
  expect_true(all(res_on$w >= -1e-6))
  expect_equal(sum(res_on$w[Z == 1]), sum(Z == 1), tolerance = 1e-3)
  expect_equal(sum(res_on$w[Z == 0]), sum(Z == 0), tolerance = 1e-3)
})
