#' Numerically robust solver for the CFD balancing quadratic program
#'
#' Solves
#' \deqn{\min_w \; w^\top Q w + q^\top w \quad \text{s.t.} \quad A w = d,\; w \ge 0,}
#' the constrained quadratic program underlying the CFD balancing weights (eq. 17 of
#' Santra, Chen and Park, 2026). Two interchangeable backends are supported --
#' \code{quadprog::solve.QP()} and \code{optiSolve::solvecop()} -- and this function
#' additionally guards against a case that arises naturally for some kernel choices:
#' \code{Q} may be only *conditionally* negative definite rather than positive
#' definite (this happens, for instance, for the energy-distance kernel of Example 4,
#' \eqn{k_{\mathrm{ED}}(x,x') = -\|x-x'\|_2}, especially when the regularization
#' parameter \eqn{\lambda} is small). Before solving, \code{Q} is symmetrized and, if
#' it is not numerically positive definite, its smallest eigenvalue is floored (a
#' standard nearest-PD / Tikhonov-style safeguard, applied only if needed and only by
#' the minimal amount required); the solver's return status is checked rather than
#' assumed, and the second backend is tried automatically if the first fails to reach
#' an optimal solution.
#'
#' @param Qmat Symmetric quadratic-form matrix (n x n).
#' @param qvec Linear-term vector (length n).
#' @param Amat Equality-constraint matrix (k x n), such that \code{Amat \%*\% w == dvec}.
#' @param dvec Equality-constraint right-hand side (length k).
#' @param lb Lower bound for \code{w} (default 0, i.e. non-negative weights).
#' @param eig_tol Minimum eigenvalue enforced on \code{Qmat} before solving (default
#'   \code{1e-8}).
#' @param quiet Suppress solver messages (default `TRUE`).
#' @param prefer_solver Which backend to try first: `"quadprog"` (default) or
#'   `"optiSolve"`; the other is used as a fallback if the first fails to reach an
#'   optimal solution. The two backends solve the identical QP and give numerically
#'   equivalent weights, but `quadprog::solve.QP()` is typically orders of magnitude
#'   faster than `optiSolve::solvecop()` at the problem sizes this package produces,
#'   which matters for [subsample_ci()]/[bootstrap_ci()] (each solves hundreds of QPs
#'   per call). Pass `prefer_solver = "optiSolve"` to match the solver used in the
#'   paper's own simulation and data analysis (Section 3.2) exactly, at a large speed
#'   cost.
#'
#' @return A list with elements `w` (the solution), `status` (`"optimal"` or a
#'   diagnostic string), `solver` (which backend produced the solution), and
#'   `jittered` (`TRUE` if the eigenvalue floor was applied).
#' @export
solve_qp_safe <- function(Qmat, qvec, Amat, dvec, lb = 0, eig_tol = 1e-8, quiet = TRUE,
                           prefer_solver = c("quadprog", "optiSolve")) {
  prefer_solver <- match.arg(prefer_solver)
  n <- nrow(Qmat)
  stopifnot(ncol(Qmat) == n, length(qvec) == n, ncol(Amat) == n, length(dvec) == nrow(Amat))

  Qmat <- (Qmat + t(Qmat)) / 2  # (i) symmetrize

  jittered <- FALSE
  ev_min <- tryCatch(min(eigen(Qmat, symmetric = TRUE, only.values = TRUE)$values),
                      error = function(e) NA_real_)
  if (is.na(ev_min) || ev_min < eig_tol) {
    bump <- eig_tol - ifelse(is.na(ev_min), 0, ev_min)
    Qmat <- Qmat + diag(bump, n)  # (ii) eigenvalue floor / nearest-PD safeguard
    jittered <- TRUE
  }

  backends <- list(
    quadprog  = function() .try_quadprog(Qmat, qvec, Amat, dvec, lb),
    optiSolve = function() .try_optisolve(Qmat, qvec, Amat, dvec, lb, quiet)
  )
  labels <- list(quadprog = "quadprog::solve.QP", optiSolve = "optiSolve::solvecop")
  order <- if (prefer_solver == "quadprog") c("quadprog", "optiSolve") else c("optiSolve", "quadprog")

  out <- backends[[order[1]]]()
  if (!is.null(out)) {
    return(list(w = out, status = "optimal", solver = labels[[order[1]]], jittered = jittered))
  }

  out <- backends[[order[2]]]()  # (iv) fallback backend
  if (!is.null(out)) {
    return(list(w = out, status = "optimal (fallback solver)", solver = labels[[order[2]]],
                jittered = jittered))
  }

  stop("solve_qp_safe(): both optiSolve and the quadprog fallback failed to solve the ",
       "CFD balancing QP. This usually means lambda is too small for the chosen kernel; ",
       "try increasing `lambda` (see Assumption 7 / `default_lambda()`).")
}

.try_optisolve <- function(Qmat, qvec, Amat, dvec, lb, quiet) {
  n <- nrow(Qmat)
  res <- tryCatch({
    mycop <- optiSolve::cop(
      f = optiSolve::quadfun(Qmat, a = as.numeric(qvec), d = 0),
      lb = optiSolve::lbcon(val = rep(lb, n)),
      # `name` is supplied explicitly since some optiSolve versions default it to
      # rownames(A), which is NULL for a plain matrix with no row names and would
      # otherwise cause lincon() to error.
      lc = optiSolve::lincon(A = Amat, dir = rep("==", nrow(Amat)), val = dvec,
                              name = as.character(seq_len(nrow(Amat))))
    )
    sol <- optiSolve::solvecop(mycop, quiet = quiet)
    sol
  }, error = function(e) NULL, warning = function(w) NULL)

  if (is.null(res) || is.null(res$x) || anyNA(res$x)) return(NULL)
  # (iii) actually check the status instead of trusting the return value blindly
  status_ok <- is.null(res$status) || grepl("optimal|converged|ok", res$status,
                                             ignore.case = TRUE) || is.numeric(res$status)
  if (!status_ok) return(NULL)
  res$x
}

.try_quadprog <- function(Qmat, qvec, Amat, dvec, lb) {
  n <- nrow(Qmat)
  # quadprog::solve.QP() minimizes 1/2 w'Dw - d'w s.t. t(A) %*% w >= b0 (meq of which
  # are equalities), i.e. its `D` carries an implicit factor of 1/2 that this
  # function's own min w'Qw + q'w convention does not -- matching the two requires
  # Dmat = 2*Qmat (dvec_qp = -qvec is unaffected).
  Dmat <- 2 * Qmat
  dvec_qp <- -qvec
  A_eq <- t(Amat)                       # n x k
  A_ge <- diag(1, n)                    # w >= lb
  Amat_qp <- cbind(A_eq, A_ge)
  bvec_qp <- c(dvec, rep(lb, n))
  meq <- nrow(Amat)
  res <- tryCatch(
    quadprog::solve.QP(Dmat = Dmat, dvec = dvec_qp, Amat = Amat_qp, bvec = bvec_qp, meq = meq),
    error = function(e) NULL
  )
  if (is.null(res)) return(NULL)
  res$solution
}

#' Default regularization rate for the CFD balancing QP
#'
#' Returns \eqn{\lambda = n^{-2}}, the regularization rate used by default throughout
#' this package for the ridge penalty \eqn{\lambda^2\|w\|_2^2} in the CFD balancing QP
#' (eq. 17). This rate satisfies \eqn{\lambda = o(n^{-1})}, the condition required by
#' Assumption 7 of Santra, Chen and Park (2026) for the penalty term to be
#' asymptotically negligible relative to the CFD terms, and is compatible with the
#' \eqn{\sqrt n}-consistency of the weighting estimator (Theorem 4.1). A different
#' `lambda` can be supplied directly to [cfd_weights()] and related functions;
#' [.check_lambda_rate()] warns if it provably violates this rate.
#'
#' @param n Sample size.
#' @export
default_lambda <- function(n) 1 / n^2

#' Check whether a chosen lambda plausibly satisfies Assumption 7 (`lambda = o(n^-1)`)
#'
#' This is a single-\eqn{n} heuristic (the true condition is asymptotic and cannot be
#' verified from one sample size), warning when \eqn{\lambda \ge n^{-1}}, which
#' certifiably violates the required rate.
#' @param lambda Numeric regularization parameter actually used.
#' @param n Sample size.
#' @keywords internal
.check_lambda_rate <- function(lambda, n) {
  if (is.finite(lambda) && lambda >= 1 / n) {
    warning(sprintf(
      "lambda = %.3g does not satisfy lambda = o(n^-1) at n = %d (lambda >= 1/n); ",
      lambda, n), "Assumption 7 (and the sqrt(n)-consistency guarantee of Theorem 4.1) ",
      "may fail. Consider default_lambda(n) = 1/n^2 instead.", call. = FALSE)
  }
  invisible(NULL)
}
