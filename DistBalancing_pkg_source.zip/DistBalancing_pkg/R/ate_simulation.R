#' Data-generating process for the ATE simulation study (kappa design)
#'
#' Generates a single observational-study sample for evaluating ATE weighting
#' estimators. \code{kappa} controls how far the cross term
#' \eqn{\gamma(X) = (1-e(X))\mu_1(X) + e(X)\mu_0(X)} is from constant: at
#' \code{kappa = 0}, \eqn{\gamma(X) = c} is constant; at \code{kappa = 1},
#' \eqn{\gamma(X) = f(X)} is a genuinely non-constant function of the covariates.
#' Intermediate values interpolate linearly, \eqn{\gamma_\kappa(X) = (1-\kappa)c +
#' \kappa f(X)}, and \eqn{\mu_1} is backed out by solving
#' \eqn{\mu_1(X) = (\gamma_\kappa(X) - e(X)\mu_0(X)) / (1 - e(X))} for a fixed
#' propensity model \eqn{e(X)} and baseline outcome model \eqn{\mu_0(X)}. This lets a
#' simulation study vary, in a controlled way, how much a treatment-effect estimator
#' can rely on \eqn{\gamma(X)} being (nearly) constant -- see `p`, `e_coef`,
#' `mu0_coef`, `f_coef` and `c_const` below to adjust the specific propensity,
#' outcome, and target models used.
#'
#' @param kappa Interpolation parameter in `[0, 1]`.
#' @param n Sample size.
#' @param p Covariate dimension (default 10, matching the paper's other simulations).
#' @param e_coef,mu0_coef,f_coef Coefficient vectors (length `p`) for the propensity,
#'   baseline outcome, and non-constant target models; sensible defaults are used if
#'   `NULL`.
#' @param c_const The constant value of `gamma` at `kappa = 0` (default 1).
#' @param sigma Outcome noise standard deviation (default 1).
#' @return A list with `X`, `A` (treatment), `Y` (observed outcome), `mu1`, `mu0`
#'   (the true, unit-level outcome regressions), and `e` (the true propensity score).
#' @export
dgp_ate <- function(kappa, n, p = 10, e_coef = NULL, mu0_coef = NULL, f_coef = NULL,
                     c_const = 1, sigma = 1) {
  if (kappa < 0 || kappa > 1) stop("dgp_ate(): `kappa` must be in [0, 1].")
  if (is.null(e_coef))   e_coef   <- rep(0.1, p)
  if (is.null(mu0_coef)) mu0_coef <- rep(c(0.5, -0.5), each = p / 2)
  if (is.null(f_coef))   f_coef   <- rep(c(-0.3, 0.3), each = p / 2)

  X <- matrix(stats::rnorm(n * p), nrow = n)
  e <- as.numeric(stats::plogis(X %*% e_coef))
  mu0 <- as.numeric(X %*% mu0_coef)
  fX <- c_const + as.numeric(X %*% f_coef)
  gamma_kappa <- (1 - kappa) * c_const + kappa * fX
  mu1 <- (gamma_kappa - e * mu0) / (1 - e)

  A <- stats::rbinom(n, 1, e)
  Y1 <- mu1 + stats::rnorm(n, sd = sigma)
  Y0 <- mu0 + stats::rnorm(n, sd = sigma)
  Y <- A * Y1 + (1 - A) * Y0

  list(X = X, A = A, Y = Y, mu1 = mu1, mu0 = mu0, e = e)
}

#' Monte Carlo ground-truth ATE for [dgp_ate()]
#'
#' Because \eqn{\mu_1(X)} in [dgp_ate()] is a rational (not closed-form-integrable)
#' function of `X`, the true ATE `E[mu1(X) - mu0(X)]` is computed by a large,
#' noise-free Monte Carlo average (no outcome noise or treatment assignment is
#' needed, since `mu1`/`mu0` are deterministic functions of `X`), rather than a
#' closed form.
#'
#' @inheritParams dgp_ate
#' @param n_mc Monte Carlo sample size (default 2e6).
#' @param seed Optional RNG seed.
#' @return Numeric scalar, the (approximate) true ATE.
#' @export
true_ate <- function(kappa, p = 10, e_coef = NULL, mu0_coef = NULL, f_coef = NULL,
                      c_const = 1, n_mc = 2e6, seed = NULL) {
  if (!is.null(seed)) set.seed(seed)
  d <- dgp_ate(kappa, n = n_mc, p = p, e_coef = e_coef, mu0_coef = mu0_coef,
               f_coef = f_coef, c_const = c_const, sigma = 0)
  mean(d$mu1 - d$mu0)
}

#' Plug-in (design-based) variance confidence interval for a weighting estimator
#'
#' A model-free "plug-in" (Horvitz-Thompson-/Hajek-style) variance estimator for the
#' weighting estimator of eq. (2)/(18): treats the weights `w` as fixed and estimates
#' the variance of each group's weighted mean from the weighted spread of `Y` around
#' its own weighted group mean,
#' \deqn{\widehat V = \frac{1}{n_1^2}\sum_{i:Z_i=1} w_i^2 (Y_i - \bar Y_{w,1})^2 +
#'   \frac{1}{n_0^2}\sum_{i:Z_i=0} w_i^2 (Y_i - \bar Y_{w,0})^2,}
#' with a normal-approximation confidence interval
#' \eqn{\hat\tau \pm z_{1-\alpha/2}\sqrt{\widehat V}}.
#'
#' @param Y Outcome vector.
#' @param Z Treatment indicator (0/1).
#' @param w Weights.
#' @param alpha Confidence level parameter (default 0.05 for a 95\% CI).
#' @return A list with `estimate`, `se`, and `ci` (see [wald_ci()] -- this *is* a
#'   Wald CI, using this function's own design-based `se`).
#' @export
plugin_ci <- function(Y, Z, w, alpha = 0.05) {
  n1 <- sum(Z == 1); n0 <- sum(Z == 0)
  mu1w <- sum(w * Z * Y) / n1
  mu0w <- sum(w * (1 - Z) * Y) / n0
  V1 <- sum((w * Z)^2 * (Y - mu1w)^2) / n1^2
  V0 <- sum((w * (1 - Z))^2 * (Y - mu0w)^2) / n0^2
  se <- sqrt(V1 + V0)
  est <- mu1w - mu0w
  wald_ci(est, se, alpha)
}

#' Center-adjusted plug-in variance confidence interval
#'
#' A variant of [plugin_ci()] that centers each group's weighted squared residuals
#' at an auxiliary linear outcome-regression fit, \eqn{\hat\mu_z(X)} (fit in-sample
#' by OLS, separately for each treatment arm), rather than at that group's own
#' weighted mean:
#' \deqn{\widehat V_{\mathrm{adj}} = \frac{1}{n_1^2}\sum_{i:Z_i=1} w_i^2 (Y_i -
#'   \hat\mu_1(X_i))^2 + \frac{1}{n_0^2}\sum_{i:Z_i=0} w_i^2 (Y_i - \hat\mu_0(X_i))^2.}
#' This adjusts for covariate heterogeneity within each treatment arm that
#' [plugin_ci()]'s group-mean centering does not capture. The point estimate itself
#' is unchanged from [plugin_ci()]; only the variance/CI construction differs. The
#' `mu1_model`/`mu0_model` fits are returned so the adjustment can be inspected or
#' the regression specification changed.
#'
#' @inheritParams plugin_ci
#' @param X Covariate matrix or data frame, used to fit the auxiliary outcome
#'   regressions.
#' @return A list with `estimate`, `se`, `ci` (see [wald_ci()] -- this too is a Wald
#'   CI, using this function's own center-adjusted `se`), and the fitted
#'   `mu1_model`/`mu0_model`.
#' @export
center_adjusted_plugin_ci <- function(Y, Z, X, w, alpha = 0.05) {
  Xdf <- as.data.frame(X)
  n1 <- sum(Z == 1); n0 <- sum(Z == 0)

  fit1 <- stats::lm(Y ~ ., data = cbind(Y = Y, Xdf), subset = Z == 1)
  fit0 <- stats::lm(Y ~ ., data = cbind(Y = Y, Xdf), subset = Z == 0)
  mu1hat <- stats::predict(fit1, newdata = Xdf)
  mu0hat <- stats::predict(fit0, newdata = Xdf)

  est <- sum(w * Z * Y) / n1 - sum(w * (1 - Z) * Y) / n0
  V1 <- sum((w * Z)^2 * (Y - mu1hat)^2) / n1^2
  V0 <- sum((w * (1 - Z))^2 * (Y - mu0hat)^2) / n0^2
  se <- sqrt(V1 + V0)
  out <- wald_ci(est, se, alpha)
  c(out, list(mu1_model = fit1, mu0_model = fit0))
}
