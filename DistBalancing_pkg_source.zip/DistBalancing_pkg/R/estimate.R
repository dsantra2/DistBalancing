#' Weighting estimator of the average treatment effect (eq. 2 / eq. 18)
#'
#' @param Y Outcome vector.
#' @param Z Treatment indicator (0/1).
#' @param w Weights (e.g. `cfd_weights(...)$w`, or IPW/CBPS weights).
#' @return Numeric scalar, the estimated ATE.
#' @export
ate_weighting_estimate <- function(Y, Z, w) {
  n1 <- sum(Z == 1); n0 <- sum(Z == 0)
  sum(w * Z * Y) / n1 - sum(w * (1 - Z) * Y) / n0
}

#' Weighting estimator of the local average treatment effect (eq. 21)
#'
#' Computes the CFD weighting estimator of the LATE in the instrumental-variable
#' setting of Section 5: the ratio of the weighting estimators of the "intent to
#' treat" effects of the instrument `Z` on the outcome `Y` and on treatment receipt
#' `A`.
#'
#' @param Y Outcome vector.
#' @param A Treatment-receipt indicator (0/1).
#' @param Z Instrument indicator (0/1).
#' @param w Weights (e.g. `cfd_weights(Z = Z, X = X, ...)$w`).
#' @return A list with elements `late`, `numerator`, `denominator`.
#' @export
late_weighting_estimate <- function(Y, A, Z, w) {
  numerator <- ate_weighting_estimate(Y, Z, w)
  denominator <- ate_weighting_estimate(A, Z, w)
  list(late = numerator / denominator, numerator = numerator, denominator = denominator)
}

#' Inverse probability weighting (IPW) estimator (Appendix A.10)
#'
#' Fits `Z ~ X` by logistic regression with main effects only and returns the
#' resulting Hajek-style IPW weights and, if `Y`/`A` are supplied, the ATE and/or
#' LATE weighting estimates.
#'
#' @param Z Treatment/instrument indicator (0/1).
#' @param X Covariate matrix or data frame.
#' @param Y Optional outcome vector.
#' @param A Optional treatment-receipt vector (for the LATE numerator/denominator).
#' @param clip Probability clipping applied to the fitted propensity score to avoid
#'   division by (near-)zero (default `1e-6`, matching Appendix A.10's bootstrap
#'   implementation).
#' @return A list with elements `w` (weights), `prop_score`, and, when applicable,
#'   `ate` and/or `late`.
#' @export
ipw_estimate <- function(Z, X, Y = NULL, A = NULL, clip = 1e-6) {
  n <- length(Z)
  df <- data.frame(Z = Z, as.data.frame(X))
  fit <- stats::glm(Z ~ ., data = df, family = stats::binomial())
  ps <- stats::predict(fit, type = "response")
  ps <- pmin(pmax(ps, clip), 1 - clip)
  n1 <- sum(Z == 1); n0 <- sum(Z == 0)
  w <- (1 / n) * (n1 * Z / ps + n0 * (1 - Z) / (1 - ps))

  out <- list(w = w, prop_score = ps, model = fit)
  if (!is.null(Y)) out$ate <- ate_weighting_estimate(Y, Z, w)
  if (!is.null(Y) && !is.null(A)) out$late <- late_weighting_estimate(Y, A, Z, w)
  out
}

#' Covariate balancing propensity score (CBPS) estimator
#'
#' Fits an ATE-targeting covariate balancing propensity score via
#' `CBPS::CBPS(..., ATT = 0)` (Imai and Ratkovic, 2014), matching Appendix A.10, and
#' returns the resulting weights and, if `Y`/`A` are supplied, the ATE and/or LATE
#' weighting estimates.
#'
#' @inheritParams ipw_estimate
#' @return As [ipw_estimate()].
#' @export
cbps_estimate <- function(Z, X, Y = NULL, A = NULL, clip = 1e-6) {
  if (!requireNamespace("CBPS", quietly = TRUE)) {
    stop("cbps_estimate() requires the 'CBPS' package. Install it with ",
         "install.packages(\"CBPS\").")
  }
  n <- length(Z)
  df <- data.frame(Z = Z, as.data.frame(X))
  fit <- CBPS::CBPS(Z ~ ., data = df, ATT = 0, standardize = FALSE)
  ps <- pmin(pmax(as.numeric(fit$fitted.values), clip), 1 - clip)
  n1 <- sum(Z == 1); n0 <- sum(Z == 0)
  w <- (1 / n) * (n1 * Z / ps + n0 * (1 - Z) / (1 - ps))

  out <- list(w = w, prop_score = ps, model = fit)
  if (!is.null(Y)) out$ate <- ate_weighting_estimate(Y, Z, w)
  if (!is.null(Y) && !is.null(A)) out$late <- late_weighting_estimate(Y, A, Z, w)
  out
}
