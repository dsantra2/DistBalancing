#' Subsampling confidence interval (Politis, Romano, and Wolf, 1999)
#'
#' Constructs a subsampling confidence interval for the CFD weighting estimator of
#' the ATE or LATE. Subsampling remains valid without requiring the estimator to be
#' asymptotically regular (Section 4.2 of the paper), unlike a naive bootstrap
#' ([bootstrap_ci()]).
#'
#' The weighting estimator is recomputed on `B` random subsamples of size `m`,
#' drawn without replacement from the full sample of size `n`, producing replicates
#' \eqn{\hat\tau^{(m,b)}}. Write \eqn{\hat\tau} for the full-sample estimate and
#' \eqn{\tilde\tau^{(m)}(p)} for the `p`-quantile of the replicates. The confidence
#' interval is obtained by inverting the pivot \eqn{\sqrt n(\hat\tau - \tau)}, whose
#' sampling distribution is approximated by that of \eqn{\sqrt m(\hat\tau^{(m,b)} -
#' \hat\tau)} (Politis, Romano and Wolf, 1999, Ch. 2):
#' \deqn{LL = \hat\tau - \sqrt{m/n}\,\{\tilde\tau^{(m)}(1-\alpha/2) - \hat\tau\},
#'   \quad UL = \hat\tau - \sqrt{m/n}\,\{\tilde\tau^{(m)}(\alpha/2) - \hat\tau\}.}
#' The subsample size `m` is chosen automatically, separately for each estimand
#' component, by [moonboot::estimate.m()]'s data-adaptive minimum-volatility
#' criterion (`m_method = "politis"` by default, matching Appendix A.8's
#' subsample-size selection); the resampling and CI construction themselves are then
#' carried out by [moonboot::mboot()] and [moonboot::mboot.ci()] (`type = "basic"`),
#' using the estimator's \eqn{\sqrt n} convergence rate (Theorem 4.1). Pass `m`
#' directly to skip the automatic search and use a fixed subsample size instead.
#'
#' @param X Covariate matrix (n x d).
#' @param Z Treatment/instrument indicator (0/1).
#' @param Y Outcome vector.
#' @param A Treatment-receipt vector, required when `estimand = "late"`.
#' @param density Passed to [cfd_weights()] for the full-sample and subsample weight
#'   computations.
#' @param bandwidth Passed to [cfd_weights()] for the full-sample and subsample
#'   weight computations.
#' @param K Optional precomputed full-sample Gram matrix; if supplied, subsample Gram
#'   matrices are taken as the corresponding submatrix `K[idx, idx]`, reusing the
#'   full-sample kernel/bandwidth rather than recomputing the median heuristic on
#'   every subsample.
#' @param lambda Passed to [cfd_weights()] for the full-sample and subsample weight
#'   computations.
#' @param three_way Passed to [cfd_weights()] for the full-sample and subsample
#'   weight computations.
#' @param L Passed to [cfd_weights()] for the full-sample and subsample weight
#'   computations.
#' @param B Number of subsample replicates drawn at the selected `m` to build the
#'   final confidence interval (default 500).
#' @param alpha Confidence level parameter (default 0.05 for a 95\% CI).
#' @param m Optional fixed subsample size, used directly (for every estimand
#'   component) instead of searching for one. If `NULL` (default), `m` is chosen
#'   separately per component by [moonboot::estimate.m()].
#' @param m_method Subsample-size selection method passed to
#'   [moonboot::estimate.m()]'s `method` argument: `"politis"` (default, the
#'   minimum-volatility method of Politis, Romano and Wolf 1999, matching Appendix
#'   A.8), `"bickel"`, `"goetze"`, or `"sherman"`. Ignored when `m` is supplied.
#' @param min.m Smallest candidate subsample size considered while searching for
#'   `m` (default `max(3, floor(sqrt(n)))`). Ignored when `m` is supplied.
#' @param m_params Additional method-specific arguments passed to
#'   [moonboot::estimate.m()]'s `params`.
#' @param m_R Number of subsample replicates drawn per candidate value of `m` while
#'   searching for the subsample size (default 100; smaller than `B` because the
#'   search evaluates many candidate values of `m`). Ignored when `m` is supplied.
#' @param tau Convergence-rate function passed to [moonboot::estimate.m()] and
#'   [moonboot::mboot.ci()] (default `sqrt`, i.e. \eqn{\tau(n) = \sqrt n}, matching
#'   the estimator's root-n consistency, Theorem 4.1).
#' @param estimand `"late"` (default) or `"ate"`.
#' @param seed Optional RNG seed for reproducibility.
#'
#' @return A list with the selected subsample size(s) `best_m`, the (percentile)
#'   confidence interval(s) `ci`, the Wald (normal-approximation) confidence
#'   interval(s) `wald_ci` and their standard error(s) `se` (see [wald_ci()]), the
#'   full-sample point estimate(s) `full_estimate`, and the underlying
#'   [moonboot::mboot()] object(s) `boot`, one list element per estimand component
#'   (`"ate"`, or `"numerator"`/`"denominator"`/`"late"`).
#' @export
subsample_ci <- function(X, Z, Y, A = NULL, density = "gaussian", bandwidth = NULL,
                          K = NULL, lambda = NULL, three_way = TRUE, L = 1e4,
                          B = 500, alpha = 0.05, m = NULL, m_method = "politis",
                          min.m = NULL, m_params = NULL, m_R = 100, tau = sqrt,
                          estimand = c("late", "ate"), seed = NULL) {
  estimand <- match.arg(estimand)
  if (estimand == "late" && is.null(A)) stop("subsample_ci(): `A` is required when estimand = 'late'.")
  if (!is.null(seed)) set.seed(seed)

  n <- length(Z)
  X <- as.matrix(X)
  if (is.null(K)) {
    gram <- cfd_kernel_gram(X, density = density, bandwidth = bandwidth, L = L)
    K <- gram$K
    bandwidth <- gram$bandwidth
  }
  if (is.null(lambda)) lambda <- default_lambda(n)
  if (is.null(min.m)) min.m <- max(3, floor(sqrt(n)))

  full_w <- cfd_weights(Z = Z, K = K, lambda = lambda, three_way = three_way)$w
  full_est <- .point_estimate(Y, Z, A, full_w, estimand)
  comps <- names(full_est)  # e.g. c("numerator","denominator","late") or c("ate")

  dat <- data.frame(Z = Z, Y = Y)
  if (!is.null(A)) dat$A <- A

  best_m <- list(); ci <- list(); se <- list(); wald <- list(); boots <- list()

  for (cc in comps) {
    stat_fn <- function(dat, indices) {
      Zs <- dat$Z[indices]
      if (length(unique(Zs)) < 2) return(NA_real_)
      w_sub <- tryCatch(
        cfd_weights(Z = Zs, K = K[indices, indices, drop = FALSE], lambda = lambda,
                    three_way = three_way)$w,
        error = function(e) NULL
      )
      if (is.null(w_sub)) return(NA_real_)
      As <- if (!is.null(dat$A)) dat$A[indices] else NULL
      est <- .point_estimate(dat$Y[indices], Zs, As, w_sub, estimand)
      est[[cc]]
    }

    m_cc <- if (!is.null(m)) m else moonboot::estimate.m(
      dat, stat_fn, tau = tau, R = m_R, replace = FALSE, min.m = min.m,
      method = m_method, params = m_params
    )

    boot_out <- moonboot::mboot(dat, stat_fn, m = m_cc, R = B, replace = FALSE)
    ok <- !is.na(boot_out$t)
    if (sum(ok) < 2) {
      stop("subsample_ci(): too many subsamples of size m = ", m_cc,
           " contained only one treatment group to construct a confidence interval ",
           "for '", cc, "'; try a larger `min.m`.")
    }
    if (!all(ok)) boot_out$t <- boot_out$t[ok]

    cis <- moonboot::mboot.ci(boot_out, conf = 1 - alpha, tau = tau, types = "basic")
    se_cc <- stats::sd(boot_out$t) * tau(m_cc) / tau(n)

    best_m[[cc]] <- m_cc
    ci[[cc]] <- cis$basic
    se[[cc]] <- se_cc
    wald[[cc]] <- wald_ci(full_est[[cc]], se_cc, alpha)
    boots[[cc]] <- boot_out
  }

  list(estimand = estimand, full_estimate = full_est, best_m = best_m, ci = ci,
       se = stats::setNames(unlist(se), comps), wald_ci = wald, boot = boots,
       bandwidth = bandwidth, lambda = lambda)
}

.neighborhood <- function(i, G, h) {
  lo <- max(1, i - h); hi <- min(G, i + h)
  unique(c(lo:i, i:hi))
}

#' Select a subsample size by the volatility index (Politis, Romano, and Wolf, 1999)
#'
#' An alternative, manual way to pick the subsample size `m` used by a subsampling
#' confidence interval, given subsampling replicates that have already been
#' recomputed at several candidate values of `m` -- for example when those
#' replicates were produced across separate batch jobs on a cluster (see
#' `system.file("scripts", package = "DistBalancing")` for a worked example) rather
#' than in a single call to [subsample_ci()] (which performs this same selection
#' internally via [moonboot::estimate.m()]).
#'
#' Before calling this function, every replicate \eqn{\hat\tau^{(m,b)}} at
#' subsample size `m` must be rescaled to the pivot's (full-sample) scale:
#' \deqn{\hat\tau - \sqrt{m/n}\,(\hat\tau^{(m,b)} - \hat\tau)}
#' where \eqn{\hat\tau} is the full-sample estimate and `n` the full-sample size
#' (Politis, Romano and Wolf, 1999, Ch. 2). This function then computes, at each
#' candidate `m`, the confidence interval implied by the rescaled replicates'
#' `alpha/2` and `1 - alpha/2` quantiles, and a volatility index -- the local
#' (neighborhood) standard deviation of the interval endpoints across nearby values
#' of `m`, following Remark 9.3.10 of Politis, Romano and Wolf (1999), with
#' neighborhood half-width `VI_bw` -- and returns the `m` with the smallest
#' volatility index, together with its confidence interval.
#'
#' @param scaled_reps_by_m A named list, keyed by `as.character(grid)`, of matrices
#'   (or data frames) of already-rescaled replicate statistics, one column per
#'   estimand component (e.g. `"numerator"`, `"denominator"`, `"late"`, or `"ate"`).
#' @param grid Candidate subsample sizes, in the same order/values as the names of
#'   `scaled_reps_by_m`.
#' @param alpha Confidence level parameter (default 0.05 for a 95\% CI).
#' @param VI_bw Neighborhood half-width `h` for the volatility index (default 2,
#'   following Remark 9.3.10 of Politis, Romano and Wolf 1999).
#' @return A list with `ci_by_m` (per-`m` confidence intervals), `VI` (the
#'   volatility index matrix), `best_m`, and `ci` (the confidence interval at the
#'   selected `best_m`, one per component).
#' @export
select_m_by_volatility <- function(scaled_reps_by_m, grid, alpha = 0.05, VI_bw = 2) {
  G <- length(grid)
  comps <- colnames(scaled_reps_by_m[[1]])

  ci_by_m <- lapply(scaled_reps_by_m, function(reps) {
    apply(reps, 2, stats::quantile, probs = c(alpha / 2, 1 - alpha / 2), na.rm = TRUE)
  })

  VI <- matrix(NA_real_, G, length(comps), dimnames = list(as.character(grid), comps))
  for (i in seq_len(G)) {
    nb <- .neighborhood(i, G, VI_bw)
    for (cc in comps) {
      Ls <- vapply(ci_by_m[nb], function(m2) m2[1, cc], numeric(1))
      Us <- vapply(ci_by_m[nb], function(m2) m2[2, cc], numeric(1))
      VI[i, cc] <- stats::sd(Ls, na.rm = TRUE) + stats::sd(Us, na.rm = TRUE)
    }
  }

  best_idx <- vapply(comps, function(cc) which.min(VI[, cc]), integer(1))
  best_m <- as.list(stats::setNames(grid[best_idx], comps))
  ci <- lapply(comps, function(cc) ci_by_m[[best_idx[[cc]]]][, cc])
  names(ci) <- comps

  list(ci_by_m = ci_by_m, VI = VI, best_m = best_m, ci = ci)
}

.point_estimate <- function(Y, Z, A, w, estimand) {
  if (estimand == "ate") {
    list(ate = ate_weighting_estimate(Y, Z, w))
  } else {
    r <- late_weighting_estimate(Y, A, Z, w)
    list(numerator = r$numerator, denominator = r$denominator, late = r$late)
  }
}

#' Wald (normal-approximation) confidence interval
#'
#' Constructs the standard Wald-type confidence interval
#' \eqn{\hat\tau \pm z_{1-\alpha/2}\,\hat{se}} from a point estimate and its estimated
#' standard error. This is the general building block used internally by
#' [plugin_ci()] and [center_adjusted_plugin_ci()] (whose `se` comes from a
#' closed-form design-based variance formula), and is also returned directly by
#' [subsample_ci()] (`se` = standard deviation of the subsampling replicates at the
#' selected `m`, rescaled to the full-sample pivot's scale, as an alternative to that
#' function's percentile CI) and [bootstrap_ci()] (`se` = standard deviation of the
#' bootstrap replicates, centered at the *original-sample* point estimate rather than
#' the bootstrap mean, as an alternative to the percentile bootstrap CI).
#'
#' @param estimate Point estimate.
#' @param se Estimated standard error of `estimate`.
#' @param alpha Confidence level parameter (default 0.05 for a 95\% CI).
#' @return A list with `estimate`, `se`, and `ci` (a length-2 vector
#'   `c(lower, upper)`).
#' @export
wald_ci <- function(estimate, se, alpha = 0.05) {
  zcrit <- stats::qnorm(1 - alpha / 2)
  list(estimate = estimate, se = se, ci = c(estimate - zcrit * se, estimate + zcrit * se))
}

#' Nonparametric bootstrap confidence interval (Appendix A.9)
#'
#' Standard nonparametric bootstrap: resample the data with replacement `B` times,
#' recompute the weighting estimator on each bootstrap sample, and report the
#' empirical `alpha/2` and `1 - alpha/2` quantiles as the confidence interval. Note
#' (Section 4.2 of the paper): this bootstrap can fail to attain nominal coverage for
#' the CFD weighting estimator, because the estimator need not be regular; subsampling
#' via [subsample_ci()] is the paper's recommended, provably valid alternative.
#'
#' @inheritParams subsample_ci
#' @param method One of the CFD density names (`"gaussian"`, `"laplacian"`, `"t"`,
#'   `"matern"`, `"energy"`), or `"ipw"` / `"cbps"`.
#' @param B Number of bootstrap replicates (default 500).
#' @param full_w Optional precomputed full-sample weights (e.g. from
#'   `cfd_weights(...)$w`, `ipw_estimate(...)$w`, or `cbps_estimate(...)$w`), used
#'   only to center the Wald CI at the original-sample point estimate. If `NULL`
#'   (default), it is computed with the same `method`/`bandwidth`/`lambda`/
#'   `three_way`/`L` as the bootstrap replicates; supplying it avoids a redundant QP
#'   solve when the caller has already computed the full-sample weights.
#' @return A list with `ci` (percentile CI), `se` and `wald_ci` (the
#'   normal-approximation alternative -- see [wald_ci()]), `full_estimate` (the
#'   original-sample point estimate used to center `wald_ci`), and the raw
#'   replicates `reps`.
#' @export
bootstrap_ci <- function(X, Z, Y, A = NULL, method = "gaussian", bandwidth = NULL,
                          lambda = NULL, three_way = TRUE, L = 1e4, B = 500,
                          alpha = 0.05, estimand = c("late", "ate"), seed = NULL,
                          full_w = NULL) {
  estimand <- match.arg(estimand)
  if (estimand == "late" && is.null(A)) stop("bootstrap_ci(): `A` is required when estimand = 'late'.")
  if (!is.null(seed)) set.seed(seed)

  n <- length(Z)
  X <- as.matrix(X)
  is_kernel <- method %in% c("gaussian", "laplacian", "t", "matern", "energy")
  if (is.null(lambda)) lambda <- default_lambda(n)

  comps <- if (estimand == "ate") "ate" else c("numerator", "denominator", "late")

  # Original-sample point estimate, used only to center the Wald CI (see `full_w`).
  if (is.null(full_w)) {
    full_w <- if (is_kernel) {
      cfd_weights(Z = Z, X = X, density = method, bandwidth = bandwidth, lambda = lambda,
                  three_way = three_way, L = L)$w
    } else if (method == "ipw") {
      ipw_estimate(Z, X)$w
    } else if (method == "cbps") {
      cbps_estimate(Z, X)$w
    } else {
      stop("bootstrap_ci(): unknown method '", method, "'.")
    }
  }
  full_est <- .point_estimate(Y, Z, A, full_w, estimand)

  reps <- matrix(NA_real_, B, length(comps), dimnames = list(NULL, comps))

  for (b in seq_len(B)) {
    idx <- sample.int(n, n, replace = TRUE)
    Zb <- Z[idx]; Yb <- Y[idx]; Xb <- X[idx, , drop = FALSE]
    Ab <- if (!is.null(A)) A[idx] else NULL
    if (length(unique(Zb)) < 2) next

    w_b <- tryCatch({
      if (is_kernel) {
        cfd_weights(Z = Zb, X = Xb, density = method, bandwidth = bandwidth,
                    lambda = lambda, three_way = three_way, L = L)$w
      } else if (method == "ipw") {
        ipw_estimate(Zb, Xb)$w
      } else if (method == "cbps") {
        cbps_estimate(Zb, Xb)$w
      } else {
        stop("bootstrap_ci(): unknown method '", method, "'.")
      }
    }, error = function(e) NULL)
    if (is.null(w_b)) next

    est_b <- .point_estimate(Yb, Zb, Ab, w_b, estimand)
    reps[b, ] <- unlist(est_b[comps])
  }

  ci <- apply(reps, 2, stats::quantile, probs = c(alpha / 2, 1 - alpha / 2), na.rm = TRUE)

  se <- stats::setNames(apply(reps, 2, stats::sd, na.rm = TRUE), comps)
  wald <- lapply(comps, function(cc) wald_ci(full_est[[cc]], se[[cc]], alpha))
  names(wald) <- comps

  list(estimand = estimand, method = method, full_estimate = full_est,
       ci = as.list(as.data.frame(ci)), se = se, wald_ci = wald, reps = reps)
}
