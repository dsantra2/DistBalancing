#' Finite-moment balance penalty (quadratic-form contribution)
#'
#' Constructs the QP quadratic-form (`Q`) and linear (`q`) contributions of a
#' finite-dimensional moment-balance penalty \eqn{m_1(w)^\top Q_m m_1(w) +
#' m_0(w)^\top Q_m m_0(w)} (plus, if `three_way = TRUE`, a third term
#' \eqn{\{m_1(w)-m_0(w)\}^\top Q_m \{m_1(w)-m_0(w)\}}, mirroring the CFD's own
#' arm-vs-arm term in eq. 16), where \eqn{m_z(w) = \frac{1}{n_z}\sum_{i:Z_i=z} w_i
#' \Phi(X_i) - \overline{\Phi(X)}} is the weighted-mean imbalance, in a feature
#' space \eqn{\Phi}, of arm `z` against the full-sample mean \eqn{\overline{\Phi(X)}}.
#' By default \eqn{\Phi} is the identity (\eqn{\Phi(X) = X}), so `m_z(w)` is simply
#' the weighted-mean covariate imbalance; supplying `features` lets the penalty
#' target any finite set of (possibly nonlinear) functions of `X` instead -- e.g.
#' `function(X) cbind(X, X^2)` to also balance second moments, or interaction terms
#' -- while the quadratic-form/RKHS structure (and its combination with the CFD
#' term below) is unchanged. This is the finite-dimensional analogue of the CFD's
#' distributional (characteristic-function) balance: instead of matching the full
#' spectral/kernel-implied distribution, it matches (a weighted combination of) a
#' finite set of moments of `X` directly. It is additive with the CFD term -- see
#' `moment_gamma`/`moment_Q`/`moment_features` in [cfd_weights()] -- so the two can
#' be combined in one QP, and its cost is negligible (`Q_m` is at most an `m x m`
#' matrix, `m` = number of features, versus the CFD's `n x n` Gram matrix).
#'
#' This construction is a soft, quadratic-penalty analogue of exact moment-balancing
#' methods such as entropy balancing (Hainmueller, 2012) and SBW (Zubizarreta, 2015).
#' Its role is to supplement the CFD's distributional balance with an explicit,
#' directly interpretable penalty on a finite set of covariate-imbalance moments;
#' only this function's body needs to change to use a different moment vector or
#' weighting matrix.
#'
#' @param X Covariate matrix or data frame (n x d).
#' @param Z Treatment indicator (0/1 vector, length n).
#' @param Qm Optional `m x m` weighting matrix for the moment vector (`m` = number
#'   of features returned by `features`; default: the diagonal matrix of inverse
#'   marginal feature variances, i.e. each moment imbalance is measured in
#'   standardized units -- a common choice in the balancing literature; pass
#'   `diag(m)` for an unweighted/Euclidean penalty, or any other symmetric positive
#'   semi-definite `m x m` matrix, e.g. an inverse covariance).
#' @param three_way If `TRUE` (default), also include the arm-vs-arm moment term,
#'   matching `cfd_weights()`'s own `three_way` default.
#' @param features A function mapping the `n x d` covariate matrix `X` to an
#'   `n x m` feature matrix \eqn{\Phi(X)} (default `NULL`, i.e. the identity
#'   `function(X) X`, so `m = d` and the penalty targets covariate means). Supply a
#'   different function to balance nonlinear moments instead -- the returned matrix
#'   must have `n` rows and a fixed number of columns `m`.
#' @return A list with `Q` (`n x n`) and `q` (length `n`), to be added to a CFD (or
#'   any other) QP's own `Q`/`q` before solving.
#' @seealso `system.file("scripts", "08_moment_gamma_study.R", package =
#'   "DistBalancing")` for an example comparing weighting performance with and
#'   without this penalty across a range of `moment_gamma` values.
#' @export
moment_balance_gram <- function(X, Z, Qm = NULL, three_way = TRUE, features = NULL) {
  X <- as.matrix(X)
  storage.mode(X) <- "double"
  if (is.null(features)) features <- function(X) X
  Phi <- as.matrix(features(X))
  storage.mode(Phi) <- "double"
  if (nrow(Phi) != nrow(X)) {
    stop("moment_balance_gram(): `features(X)` must return a matrix with the same ",
         "number of rows as `X`.")
  }
  Z <- as.numeric(Z)
  n <- length(Z); d <- ncol(Phi)
  i1 <- as.numeric(Z == 1); i0 <- as.numeric(Z == 0)
  n1 <- sum(i1); n0 <- sum(i0)

  if (is.null(Qm)) {
    v <- apply(Phi, 2, stats::var)
    v[v <= 0] <- 1  # guard against a constant column
    Qm <- diag(1 / v, nrow = d, ncol = d)
  }

  xbar <- colMeans(Phi)
  A1 <- t(Phi * i1) / n1   # d x n : (1/n1) * t(Phi) %*% diag(i1)
  A0 <- t(Phi * i0) / n0

  Q_full <- t(A1) %*% Qm %*% A1 + t(A0) %*% Qm %*% A0
  if (three_way) {
    Ad <- A1 - A0
    Q_full <- Q_full + t(Ad) %*% Qm %*% Ad
  }
  q_full <- as.numeric(-2 * t(A1 + A0) %*% (Qm %*% xbar))

  list(Q = Q_full, q = q_full)
}

#' CFD-based distributional balancing weights
#'
#' Computes the characteristic-function-distance (CFD) balancing weights of eq. (13)
#' / (17) (three-way balancing, the paper's default) or eq. (12) (two-way balancing,
#' `three_way = FALSE`). This is the package's central, deliberately flexible entry
#' point: the Gram/kernel matrix can be built automatically from a named or custom
#' [cfd_density()], or the caller can bypass kernel construction entirely and supply
#' the quadratic program's `Q` matrix (and, optionally, its linear term `q`) directly.
#'
#' Writing \eqn{D_1}/\eqn{D_0} for the diagonal matrices of the treated/control
#' indicators, \eqn{K} for the Gram matrix, \eqn{n_1}/\eqn{n_0}/\eqn{n} for the arm
#' and total sample sizes, and \eqn{\mathbf{1}} for the all-ones vector, the QP solved
#' is \eqn{\min_w w^\top Q w + q^\top w} subject to \eqn{\sum_{i:Z_i=1} w_i = n_1},
#' \eqn{\sum_{i:Z_i=0} w_i = n_0}, and \eqn{w \ge 0}, where (up to a constant not
#' involving `w`) this objective equals the sum of pairwise squared MMDs between the
#' treated-arm, control-arm, and (when `three_way = TRUE`) full-sample empirical
#' measures implied by `w` -- treated-vs-pooled plus control-vs-pooled (eq. 12), and
#' also treated-vs-control when `three_way = TRUE` (eq. 13/17). Concretely,
#' \deqn{Q = \begin{cases} \dfrac{D_1 K D_1}{n_1^2} + \dfrac{D_0 K D_0}{n_0^2} +
#' \lambda^2 I, & \texttt{three\_way = FALSE} \\[4pt]
#' 2\left(\dfrac{D_1 K D_1}{n_1^2} + \dfrac{D_0 K D_0}{n_0^2} - \dfrac{D_1 K D_0}{n_1
#' n_0}\right) + \lambda^2 I, & \texttt{three\_way = TRUE} \end{cases}}
#' \deqn{q = -2\left(\dfrac{D_1 K \mathbf{1}}{n_1 n} + \dfrac{D_0 K \mathbf{1}}{n_0
#' n}\right).}
#'
#' @param Z Treatment indicator (0/1 vector, length n).
#' @param X Covariate matrix (n x d). Not needed if `K` or `Q` is supplied directly.
#' @param density A [cfd_density()] object, or one of the built-in names
#'   `"gaussian"`, `"laplacian"`, `"t"`, `"matern"`, `"energy"` (default
#'   `"gaussian"`). Ignored if `K` or `Q` is supplied.
#' @param bandwidth Kernel bandwidth; `NULL` uses the median heuristic (Appendix A.7).
#'   Ignored if `K` or `Q` is supplied.
#' @param K Optional precomputed Gram matrix (n x n), e.g. a subset `K_full[idx, idx]`
#'   reused across subsampling/bootstrap replicates, or a kernel not otherwise
#'   supported by [cfd_density()]. If supplied, `X`/`density`/`bandwidth` are ignored.
#' @param Q Optional precomputed QP quadratic-form matrix, bypassing the automatic
#'   construction from `K` entirely: supply any valid `Q` (e.g. built from a
#'   different discrepancy measure entirely) and `cfd_weights()` will solve the
#'   resulting QP directly. Because a supplied `Q` is a fixed `n x n` matrix tied to
#'   this specific sample's size and arm composition, it cannot be validly re-derived
#'   for a resample of a different size or composition; [subsample_ci()] and
#'   [bootstrap_ci()] therefore only accept `Q`/`q` for the full-sample point
#'   estimate, not for resampling (use `K`/`density` there instead, which they can
#'   correctly rebuild per replicate).
#' @param q Optional linear term paired with a user-supplied `Q` (defaults to a zero
#'   vector if `Q` is supplied but `q` is not).
#' @param lambda Regularization parameter. `NULL` (default) uses
#'   [default_lambda()]\eqn{{}= n^{-2}}, which satisfies the \eqn{\lambda = o(n^{-1})}
#'   rate of Assumption 7. If a numeric value is supplied instead, it is checked
#'   against that rate and a warning is issued if it provably violates it.
#' @param three_way If `TRUE` (default), balances the treated group and the control
#'   group each against the full sample *and* against each other (eq. 13/17,
#'   Remark 1 -- the specification used throughout the paper's simulation and data
#'   analysis). If `FALSE`, uses the simpler two-way objective of eq. (12).
#' @param L Number of Monte Carlo draws for kernels without a closed form (default
#'   \eqn{10^4}).
#' @param moment_gamma Weight on an additional finite-moment balancing penalty
#'   \eqn{\gamma \cdot m(w)^\top Q_m m(w)}, added to the CFD (or user-supplied `Q`)
#'   objective before solving -- see [moment_balance_gram()] for the exact
#'   construction. Default `0` (off). Requires `X` (even if `Q`/`K` were supplied
#'   directly).
#' @param moment_Q Optional weighting matrix for the moment penalty, passed to
#'   [moment_balance_gram()]'s `Qm` (default: inverse marginal variances, sized to
#'   match `moment_features`). Ignored if `moment_gamma = 0`.
#' @param moment_features Optional feature-map function for the moment penalty,
#'   passed to [moment_balance_gram()]'s `features` (default `NULL`, i.e. covariate
#'   means -- `m(w)` is the weighted-mean imbalance of `X` itself). Supply a
#'   function (e.g. `function(X) cbind(X, X^2)`) to balance nonlinear moments
#'   instead. Ignored if `moment_gamma = 0`.
#' @param eig_tol,quiet Passed to [solve_qp_safe()].
#'
#' @return An object of class `"cfd_weights"`: a list with elements `w` (the
#'   estimated weights), `K`, `bandwidth`, `lambda`, `Q`, `q`, `status`, `solver`,
#'   `jittered`, `three_way`, `moment_gamma`.
#' @export
cfd_weights <- function(Z, X = NULL, density = "gaussian", bandwidth = NULL, K = NULL,
                         Q = NULL, q = NULL, lambda = NULL, three_way = TRUE,
                         L = 1e4, moment_gamma = 0, moment_Q = NULL,
                         moment_features = NULL,
                         eig_tol = 1e-8, quiet = TRUE) {
  Z <- as.numeric(Z)
  n <- length(Z)
  i1 <- as.numeric(Z == 1); i0 <- as.numeric(Z == 0)
  n1 <- sum(i1); n0 <- sum(i0)
  if (n1 == 0 || n0 == 0) stop("cfd_weights(): both treatment groups must be non-empty.")

  if (is.null(lambda)) {
    lambda <- default_lambda(n)
  } else {
    .check_lambda_rate(lambda, n)
  }

  if (is.null(Q)) {
    if (is.null(K)) {
      if (is.null(X)) stop("cfd_weights(): supply `X` (or a precomputed `K` or `Q`).")
      gram <- cfd_kernel_gram(X, density = density, bandwidth = bandwidth, L = L)
      K <- gram$K
      bandwidth <- gram$bandwidth
    }
    D1 <- diag(i1); D0 <- diag(i0); one <- rep(1, n)

    Qb <- (D1 %*% K %*% D1) / n1^2 + (D0 %*% K %*% D0) / n0^2
    if (three_way) Qb <- 2 * (Qb - (D1 %*% K %*% D0) / (n1 * n0))
    Qb <- Qb + lambda^2 * diag(n)
    qb <- -2 * ((D1 %*% K %*% one) / (n1 * n) + (D0 %*% K %*% one) / (n0 * n))
  } else {
    Qb <- Q
    qb <- if (is.null(q)) rep(0, n) else as.numeric(q)
    bandwidth <- NULL
  }

  if (moment_gamma != 0) {
    if (is.null(X)) stop("cfd_weights(): `X` is required when `moment_gamma != 0` ",
                          "(needed to compute the moment-balance penalty), even if ",
                          "`K`/`Q` were supplied directly.")
    mb <- moment_balance_gram(X, Z, Qm = moment_Q, three_way = three_way,
                               features = moment_features)
    Qb <- Qb + moment_gamma * mb$Q
    qb <- qb + moment_gamma * mb$q
  }

  Amat <- matrix(0, 2, n)
  Amat[1, Z == 1] <- 1
  Amat[2, Z == 0] <- 1
  dvec <- c(n1, n0)

  sol <- solve_qp_safe(Qb, as.numeric(qb), Amat, dvec, lb = 0, eig_tol = eig_tol, quiet = quiet)

  structure(
    list(w = sol$w, K = K, bandwidth = bandwidth, lambda = lambda,
         Q = Qb, q = qb, status = sol$status, solver = sol$solver,
         jittered = sol$jittered, three_way = three_way, moment_gamma = moment_gamma,
         n1 = n1, n0 = n0),
    class = "cfd_weights"
  )
}

#' @export
print.cfd_weights <- function(x, ...) {
  cat(sprintf("<cfd_weights: n1=%d, n0=%d, lambda=%.3g, solver=%s%s>\n",
              x$n1, x$n0, x$lambda, x$solver,
              if (isTRUE(x$jittered)) ", eigenvalue-floored" else ""))
  invisible(x)
}

#' Legacy-compatible alias for `cfd_weights()`
#'
#' A thin wrapper around [cfd_weights()] using the argument names and kernel-name
#' spellings of earlier, script-based versions of this method (e.g. `treatment`/
#' `covariate`/`name` in place of `Z`/`X`/`density`), provided so that analysis code
#' written against that interface needs minimal changes. New code should call
#' [cfd_weights()] directly.
#'
#' @inheritParams cfd_weights
#' @param treatment Alias for `Z`.
#' @param covariate Alias for `X`.
#' @param name Alias for `density`; also accepts `"Gaussian"`, `"Laplacian"`,
#'   `"Energy"`, `"Matern"`, `"TCFD"` case-insensitively.
#' @export
distbalance <- function(treatment, covariate, name = "gaussian", bandwidth = NULL,
                         lambda = NULL, K = NULL) {
  density <- switch(tolower(name),
                     gaussian = "gaussian", laplacian = "laplacian",
                     energy = "energy", matern = "matern",
                     tcfd = "t", t5 = "t", t = "t",
                     tolower(name))
  res <- cfd_weights(Z = treatment, X = covariate, density = density,
                      bandwidth = bandwidth, K = K, lambda = lambda)
  res$w
}
