#' DistBalancing: Distributional Balancing for Causal Inference via CFD
#'
#' @description
#' Implements the characteristic function distance (CFD) framework of Santra, Chen,
#' and Park (2026), "Distributional Balancing for Causal Inference: A Unified
#' Framework via Characteristic Function Distance", for estimating average and local
#' average treatment effects from observational data. See the package README and the
#' vignette-style scripts in `system.file("scripts", package = "DistBalancing")` for
#' worked examples, including a full simulation study and a 401(k) data application.
#'
#' @section Main functions:
#' \itemize{
#'   \item \strong{Weights}: [cfd_weights()] computes CFD-based distributional
#'     balancing weights from a named or custom kernel/spectral density
#'     ([cfd_density()]), or from a user-supplied quadratic-program matrix; an
#'     optional finite-moment balancing penalty can be added via `moment_gamma`
#'     (see [moment_balance_gram()]).
#'   \item \strong{Treatment-effect estimation}: [ate_weighting_estimate()] and
#'     [late_weighting_estimate()] compute the weighting estimators of the ATE and
#'     LATE; [ipw_estimate()] and [cbps_estimate()] provide inverse-probability and
#'     covariate-balancing-propensity-score alternatives for comparison.
#'   \item \strong{Inference}: [subsample_ci()] (the paper's recommended method,
#'     valid without assuming the estimator is asymptotically regular),
#'     [bootstrap_ci()], [plugin_ci()]/[center_adjusted_plugin_ci()] (closed-form
#'     variance estimators), and the general-purpose [wald_ci()] each construct a
#'     confidence interval for the estimated treatment effect.
#'   \item \strong{Simulation}: [dgp_ate()]/[true_ate()] generate data and ground
#'     truth for evaluating ATE estimators under a range of designs; [dgp_iv()] does
#'     the same for the LATE/instrumental-variable setting.
#'   \item \strong{QP solving}: [solve_qp_safe()] is the numerically robust quadratic
#'     program solver underlying [cfd_weights()], with two interchangeable backends.
#' }
#'
#' @keywords internal
"_PACKAGE"
