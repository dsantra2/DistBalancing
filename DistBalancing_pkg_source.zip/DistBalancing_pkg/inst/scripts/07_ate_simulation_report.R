#!/usr/bin/env Rscript
## ============================================================================
## Aggregates the per-job CSVs from 06_ate_simulation_cluster.R (concatenate them
## into Result_ATE_combined.csv first, e.g. `cat Result_ATE_*.csv | ...` or with
## data.table::rbindlist(lapply(list.files(pattern="Result_ATE_.*csv"), fread))))
## into the Summary's target table: for every (N, kernel, kappa) cell, Bias, ESE,
## SEB, a Shapiro-Wilk normality test, and length/coverage/time for each of the
## four CI methods.
##
##   Rscript 07_ate_simulation_report.R
##
## Definitions used here (standard Monte Carlo simulation-study terminology):
##   Bias     = 100 * mean(point_est - truth)                  across replicates
##   ESE      = 100 * sd(point_est)                             across replicates
##              ("empirical standard error": the actual finite-sample SD of the
##              estimator across the N_REPS simulation replicates)
##   SEB      = 100 * mean(bootstrap SD)                        across replicates
##              (the average, over replicates, of that replicate's own B=500
##              bootstrap point estimates' SD -- an estimated SE; well-calibrated
##              bootstrap SEs should track ESE closely, per the Summary's note)
##   Shapiro  = the Shapiro-Wilk p-value for the standardized point estimates
##              (point_est - mean(point_est)) / sd(point_est) across replicates,
##              per cell -- testing the paper's new (in-progress) asymptotic
##              normality result, not part of this package's "Coding"-only scope.
##
## SS.Wald.* / Boot.Wald.* summarize the Wald (normal-approximation) CI columns that
## 06_ate_simulation_cluster.R writes alongside the percentile SS.*/Boot.* columns
## (see ?DistBalancing::wald_ci); Plugin.*/CenterAdj.* were already Wald CIs.
## ============================================================================

suppressMessages({
  library(dplyr)
  library(tidyr)
  library(purrr)
})

results <- read.csv("Result_ATE_combined.csv", header = TRUE)

## 06_ate_simulation_cluster.R writes each job's own bootstrap replicates' SD as
## `Boot.SD`; SEB (below) is the average of that quantity across simulation
## replicates within each (kernel, N, kappa) cell.

truth_by_kappa <- results %>% distinct(kappa) %>% pull(kappa) %>%
  purrr::map_dbl(~ DistBalancing::true_ate(.x, n_mc = 2e6, seed = 1)) %>%
  setNames(as.character(sort(unique(results$kappa))))

summarize_ci <- function(df, lower_col, upper_col, time_col, truth) {
  lower <- df[[lower_col]]; upper <- df[[upper_col]]
  data.frame(
    Length = mean(upper - lower, na.rm = TRUE),
    Coverage = mean(truth >= lower & truth <= upper, na.rm = TRUE),
    Time = mean(df[[time_col]], na.rm = TRUE)
  )
}

report <- results %>%
  group_by(kernel, N, kappa) %>%
  group_modify(function(df, key) {
    truth <- truth_by_kappa[[as.character(key$kappa)]]
    z <- (df$point_est - mean(df$point_est)) / stats::sd(df$point_est)
    sw_p <- if (length(z) >= 3 && length(z) <= 5000) stats::shapiro.test(z)$p.value else NA_real_

    bind_cols(
      data.frame(
        Bias = 100 * mean(df$point_est - truth),
        ESE = 100 * stats::sd(df$point_est),
        SEB = 100 * mean(df$Boot.SD, na.rm = TRUE),
        Shapiro_p = sw_p
      ),
      setNames(summarize_ci(df, "SS.Lower", "SS.Upper", "SS.Time", truth), paste0("SS.", names(summarize_ci(df, "SS.Lower", "SS.Upper", "SS.Time", truth)))),
      # SS.Wald reuses SS.Time: it comes out of the same subsample_ci() call as SS.
      setNames(summarize_ci(df, "SS.Wald.Lower", "SS.Wald.Upper", "SS.Time", truth), paste0("SS.Wald.", names(summarize_ci(df, "SS.Wald.Lower", "SS.Wald.Upper", "SS.Time", truth)))),
      setNames(summarize_ci(df, "Boot.Lower", "Boot.Upper", "Boot.Time", truth), paste0("Boot.", names(summarize_ci(df, "Boot.Lower", "Boot.Upper", "Boot.Time", truth)))),
      # Boot.Wald reuses Boot.Time: it comes out of the same bootstrap_ci() call as Boot.
      setNames(summarize_ci(df, "Boot.Wald.Lower", "Boot.Wald.Upper", "Boot.Time", truth), paste0("Boot.Wald.", names(summarize_ci(df, "Boot.Wald.Lower", "Boot.Wald.Upper", "Boot.Time", truth)))),
      setNames(summarize_ci(df, "Plugin.Lower", "Plugin.Upper", "Plugin.Time", truth), paste0("Plugin.", names(summarize_ci(df, "Plugin.Lower", "Plugin.Upper", "Plugin.Time", truth)))),
      setNames(summarize_ci(df, "CenterAdj.Lower", "CenterAdj.Upper", "CenterAdj.Time", truth), paste0("CenterAdj.", names(summarize_ci(df, "CenterAdj.Lower", "CenterAdj.Upper", "CenterAdj.Time", truth))))
    )
  }) %>%
  ungroup()

write.csv(report, file = "ATE_simulation_summary_table.csv", row.names = FALSE)
print(report)
