#!/usr/bin/env Rscript
## ============================================================================
## Supplementary study: does the finite-moment balance penalty (moment_gamma in
## cfd_weights(); see ?moment_balance_gram) improve finite-sample performance,
## relative to the CFD-only objective (moment_gamma = 0)?
##
## This is NOT part of the Summary's six-kernel/kappa/N grid (inst/scripts/06-07);
## it is a small, standalone comparison across moment_gamma at one kernel
## (Gaussian) and kappa (0), at two sample sizes, using the same dgp_ate()/
## plugin_ci() building blocks. Edit KERNEL/KAPPA/N/GAMMAS/N_REPS below to extend
## it (e.g. to other kernels or a wider N grid) -- it is deliberately small so it
## runs in a few minutes rather than requiring a cluster.
##
## The moment penalty targets covariate MEANS by default. `moment_balance_gram()` /
## `cfd_weights(moment_features = ...)` also accept an arbitrary feature map, so the
## penalty can target nonlinear moments instead (e.g. `function(X) cbind(X, X^2)` to
## also balance second moments) -- pass `features` through to `run_grid()` below to
## compare that against the mean-only default; the observed result recorded at the
## bottom of this file used the (default) mean-only penalty.
## ============================================================================

suppressMessages(library(DistBalancing))

KAPPA  <- 0
GAMMAS <- c(0, 5, 20, 100)   # 0 = CFD-only (no moment penalty)
N_REPS <- 150

run_grid <- function(N, gammas = GAMMAS, n_reps = N_REPS, kappa = KAPPA, seed = 1,
                      features = NULL) {
  set.seed(seed)
  truth <- true_ate(kappa, n_mc = 2e6, seed = 1)
  out <- lapply(gammas, function(g) {
    est <- numeric(n_reps); covered <- logical(n_reps); ci_len <- numeric(n_reps)
    for (r in seq_len(n_reps)) {
      d <- dgp_ate(kappa, N, p = 10)
      w <- cfd_weights(Z = d$A, X = d$X, density = "gaussian",
                        lambda = default_lambda(N), moment_gamma = g,
                        moment_features = features)$w
      est[r] <- ate_weighting_estimate(d$Y, d$A, w)
      pc <- plugin_ci(d$Y, d$A, w)
      covered[r] <- (truth >= pc$ci[1] && truth <= pc$ci[2])
      ci_len[r] <- pc$ci[2] - pc$ci[1]
    }
    data.frame(N = N, gamma = g, Bias = mean(est - truth),
               RMSE = sqrt(mean((est - truth)^2)), ESE = stats::sd(est),
               Plugin_Coverage = mean(covered), Plugin_Length = mean(ci_len))
  })
  do.call(rbind, out)
}

results <- rbind(
  run_grid(N = 300, seed = 2026),
  run_grid(N = 150, gammas = c(0, 20, 100), seed = 99)
)
rownames(results) <- NULL
print(results, digits = 4)
write.csv(results, "moment_gamma_study.csv", row.names = FALSE)

## ---- Observed result (N_REPS = 150, one seed each -- a small Monte Carlo study,
## not the full replicate count used elsewhere in this package) ----
##
##    N gamma      Bias   RMSE    ESE Plugin_Coverage Plugin_Length
##  300     0 -6.16e-05 0.2451 0.2460          0.9800         1.084
##  300     5  1.46e-03 0.2604 0.2613          0.9600         1.085
##  300    20 -1.75e-02 0.2491 0.2494          0.9733         1.104
##  300   100  2.87e-02 0.2338 0.2328          0.9800         1.093
##  150     0  3.14e-02 0.3310 0.3306          0.9533         1.472
##  150    20 -1.34e-02 0.3601 0.3611          0.9600         1.470
##  150   100  3.59e-02 0.3467 0.3459          0.9600         1.490
##
## No consistent finite-sample improvement from moment_gamma > 0 in this DGP: at
## N=300, RMSE drops modestly at the largest gamma tried (0.245 -> 0.234, ~5%,
## driven by a small ESE reduction, not bias); at N=150 the pattern reverses
## (RMSE gets *worse* at gamma=20, only partially recovers at gamma=100). Plug-in
## CI coverage stays close to nominal 95% throughout, with no systematic gain or
## loss. Plausible explanation: the CFD objective already balances the full
## characteristic function (all frequencies), which implicitly constrains
## low-order moments fairly well on its own in this DGP -- so an *additive*,
## low-order-only penalty has little further imbalance to correct, and mostly
## adds noise (via its own regularization-like pull on the weights) rather than
## signal. This is a small study (one kernel, one kappa, 150 replicates); a firmer
## verdict would need the full N/kernel/kappa grid this script's `run_grid()` can
## be pointed at.
