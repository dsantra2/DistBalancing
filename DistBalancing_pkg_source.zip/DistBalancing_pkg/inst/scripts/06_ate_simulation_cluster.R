#!/usr/bin/env Rscript
## ============================================================================
## ATE simulation study. One self-contained cluster/array job: given a single
## BATCH index, this script simulates ONE dataset for one (N, kernel, kappa, seed)
## cell, computes the point estimate, and computes the four confidence intervals
## the target table asks for (subsampling, bootstrap, plug-in variance,
## center-adjusted plug-in variance) -- plus, for subsampling and bootstrap, a Wald
## (normal-approximation) variant alongside the default percentile CI, since
## plug-in/center-adjusted are already Wald CIs (see ?DistBalancing::wald_ci) --
## plus their computation times, and writes one row of output. Run it as an array
## job:
##
##   Rscript 06_ate_simulation_cluster.R <BATCH>
##
## with BATCH = 1, ..., nrow(Hyperparameter) (see the grid below), e.g. via Slurm:
##   sbatch --array=1-<N_JOBS> --wrap="Rscript 06_ate_simulation_cluster.R \$SLURM_ARRAY_TASK_ID"
## or HTCondor's `queue <N_JOBS>` with `arguments = $(Process)`.
##
## After all jobs finish, concatenate their output CSVs (e.g.
## `data.table::rbindlist(lapply(list.files(pattern="Result_ATE_.*csv"), fread))`
## into `Result_ATE_combined.csv`) and run 07_ate_simulation_report.R to build the
## summary table (Bias, ESE, SEB, Shapiro-Wilk normality test, and per-CI-method
## length/coverage/time).
##
## ---------------------------------------------------------------------------
## IMPORTANT -- read before submitting this at scale: computational cost and how
## this script controls it.
##
## 1. This targets the ATE, via DistBalancing::dgp_ate(), an ATE-focused
##    data-generating process with a `kappa` in [0, 1] interpolating
##    (1-e(X))*mu1(X) + e(X)*mu0(X) between a constant (kappa = 0) and a
##    non-constant function of X (kappa = 1). See ?DistBalancing::dgp_ate.
##
## 2. The "center-adjusted plug-in CI" uses
##    DistBalancing::center_adjusted_plugin_ci(), which centers each arm's weighted
##    squared residuals at an in-sample linear-regression estimate of mu_z(X)
##    rather than at the raw weighted group mean (see
##    ?DistBalancing::center_adjusted_plugin_ci for the exact formula, and to
##    substitute a different regression specification).
##
## 3. COST. Both the bootstrap and subsampling CIs work by recomputing the CFD
##    weighting estimator many times, each recomputation re-solving a quadratic
##    program (QP) -- and solving an n x n QP scales close to *cubically* in n.
##    Measured on this package's default solver (quadprog): a single QP solve
##    takes about 0.65s at n=500, 5s at n=1000, 37s at n=2000, and (extrapolating
##    the same scaling) somewhere around 3-5 minutes at n=4000. This has two
##    consequences this script manages explicitly:
##
##    a) bootstrap_ci() always resamples at the *full* sample size n, so its cost
##       is B_BOOT solves of that (expensive, at large n) size. B_BOOT_BY_N below
##       scales B_BOOT down as N grows, to keep a single job's bootstrap CI within
##       roughly 20-40 minutes even at N = 4000 -- at the cost of a coarser
##       Monte Carlo approximation to the bootstrap distribution there. Raise the
##       largest entries if your cluster allows longer per-job walltimes and you
##       want tighter bootstrap CIs at large N.
##
##    b) subsample_ci() only ever resolves QPs of the *subsample* size m, which is
##       cheap as long as m is kept modest -- but moonboot::estimate.m()'s
##       "politis" (minimum-volatility) search, used to pick m automatically,
##       evaluates about 50 candidate values of m ranging up to n/2, which is NOT
##       modest once n is large (e.g. up to 2000 at N = 4000). Above
##       M_SEARCH_MAX_N, this script skips that automatic search and instead fixes
##       m = round(2*sqrt(N)) -- the midpoint of the paper's own
##       sqrt(n)-to-3*sqrt(n) subsample-size range -- which keeps subsample_ci()'s
##       cost negligible regardless of N. Below the threshold, m is still chosen
##       adaptively by moonboot::estimate.m(), at a reduced number of search
##       replicates (M_SEARCH_R) to bound that search's own cost. See
##       ?DistBalancing::subsample_ci.
##
##    With the defaults below, a single job's total (SS + bootstrap) time is
##    roughly 8 minutes at N=500, 40 minutes at N=1000 (the moonboot search is the
##    long pole there), 25 minutes at N=2000, and 40 minutes at N=4000 (bootstrap
##    is the long pole at N >= 2000) -- measured/extrapolated on one core of this
##    development environment; expect this to vary with your cluster's hardware.
##    Total compute across the full grid (6 kernels x 3 kappa x 4 N x 500 reps)
##    is on the order of 15,000-20,000 core-hours. If that is still too much for
##    your cluster's allocation, the two knobs to turn first are N_REPS (fewer
##    Monte Carlo replicates) and B_BOOT_BY_N (fewer bootstrap replicates at the
##    largest N) -- or, per our earlier conversation, split the array and send us
##    part of it to run.
## ============================================================================

suppressMessages(library(DistBalancing))

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1) stop("Usage: Rscript 06_ate_simulation_cluster.R <BATCH>")
BATCH <- as.numeric(args[1])

## ---- hyperparameter grid ----------------------------------------------------
## N: 500 doubling to 4000. kernel: the six methods in the target table
## (Isotropic = Matern, ED = energy). kappa: the three values in the target table.
N_GRID      <- c(500, 1000, 2000, 4000)
KERNEL_GRID <- c("Gaussian", "Laplace", "Isotropic", "ED", "IPW", "CBPS")
KAPPA_GRID  <- c(0, 0.5, 1)
N_REPS      <- 500                    # simulation replicates (SEED = 1..N_REPS)

## ---- cost-control knobs (see caveat 3 above) --------------------------------
B_BOOT_BY_N    <- c(`500` = 500, `1000` = 300, `2000` = 40, `4000` = 8)
B_SS           <- 500   # subsample_ci()'s final-CI replicate count; cheap at any N
                         # once m itself is kept modest (see M_SEARCH_MAX_N).
M_SEARCH_MAX_N <- 1000  # use moonboot::estimate.m()'s automatic search for
                         # N <= this; fix m = round(2*sqrt(N)) above it.
M_SEARCH_R     <- 50    # search replicates per candidate m, only used when the
                         # automatic search runs (N <= M_SEARCH_MAX_N).

Hyperparameter <- expand.grid(kernel = KERNEL_GRID, kappa = KAPPA_GRID,
                               N = N_GRID, SEED = seq_len(N_REPS),
                               stringsAsFactors = FALSE)

kernel_label <- Hyperparameter[BATCH, "kernel"]
kappa        <- Hyperparameter[BATCH, "kappa"]
N            <- Hyperparameter[BATCH, "N"]
SEED         <- Hyperparameter[BATCH, "SEED"]
set.seed(SEED)

density_name <- switch(kernel_label, Gaussian = "gaussian", Laplace = "laplacian",
                        Isotropic = "matern", ED = "energy", NA_character_)
is_kernel <- !is.na(density_name)

## ---- simulate one dataset --------------------------------------------------
d <- dgp_ate(kappa, N, p = 10)

## ---- point estimate + weights ----------------------------------------------
w <- if (is_kernel) {
  cfd_weights(Z = d$A, X = d$X, density = density_name, lambda = default_lambda(N))$w
} else if (kernel_label == "IPW") {
  ipw_estimate(d$A, d$X)$w
} else {
  cbps_estimate(d$A, d$X)$w
}
point_est <- ate_weighting_estimate(d$Y, d$A, w)

time_it <- function(expr) {
  t0 <- proc.time()[["elapsed"]]
  val <- expr
  list(value = val, seconds = proc.time()[["elapsed"]] - t0)
}

## ---- subsampling CI (kernel/DB methods only, per Section 4.2 of the paper) --
## Both the percentile CI and the Wald ("Type 2", normal-approximation) CI come out
## of the same subsample_ci() call at no extra cost -- see ?DistBalancing::wald_ci.
ss <- list(length = NA_real_, time = NA_real_, lower = NA_real_, upper = NA_real_)
ss_wald <- list(length = NA_real_, time = NA_real_, lower = NA_real_, upper = NA_real_)
if (is_kernel) {
  ss_res <- if (N <= M_SEARCH_MAX_N) {
    time_it(subsample_ci(d$X, d$A, d$Y, density = density_name,
                          lambda = default_lambda(N), B = B_SS, m_R = M_SEARCH_R,
                          estimand = "ate", seed = SEED))
  } else {
    time_it(subsample_ci(d$X, d$A, d$Y, density = density_name,
                          lambda = default_lambda(N), B = B_SS,
                          m = round(2 * sqrt(N)), estimand = "ate", seed = SEED))
  }
  ci <- ss_res$value$ci$ate
  ss <- list(length = unname(ci[2] - ci[1]), time = ss_res$seconds,
             lower = unname(ci[1]), upper = unname(ci[2]))
  ci_w <- ss_res$value$wald_ci$ate$ci
  ss_wald <- list(length = unname(ci_w[2] - ci_w[1]), time = ss_res$seconds,
                   lower = unname(ci_w[1]), upper = unname(ci_w[2]))
}

## ---- bootstrap CI (all six methods) -----------------------------------------
## Likewise, bootstrap_ci() returns both the percentile CI and the Wald CI (centered
## at the original-sample point estimate `point_est`/`w`, passed in via `full_w` so
## it isn't recomputed) from one call.
B_boot <- B_BOOT_BY_N[[as.character(N)]]
boot_method <- if (is_kernel) density_name else tolower(kernel_label)
boot_res <- time_it(bootstrap_ci(d$X, d$A, d$Y, method = boot_method, B = B_boot,
                                  estimand = "ate", seed = SEED, full_w = w))
ci_boot <- boot_res$value$ci$ate
boot <- list(length = unname(ci_boot[2] - ci_boot[1]), time = boot_res$seconds,
             lower = unname(ci_boot[1]), upper = unname(ci_boot[2]),
             sd = stats::sd(boot_res$value$reps[, "ate"], na.rm = TRUE))  # -> SEB in the report
ci_boot_w <- boot_res$value$wald_ci$ate$ci
boot_wald <- list(length = unname(ci_boot_w[2] - ci_boot_w[1]), time = boot_res$seconds,
                   lower = unname(ci_boot_w[1]), upper = unname(ci_boot_w[2]))

## ---- plug-in variance CI ----------------------------------------------------
pi_res <- time_it(plugin_ci(d$Y, d$A, w))
plugin <- list(length = pi_res$value$ci[2] - pi_res$value$ci[1], time = pi_res$seconds,
               lower = pi_res$value$ci[1], upper = pi_res$value$ci[2])

## ---- center-adjusted plug-in variance CI (see caveat #2 above) -------------
ca_res <- time_it(center_adjusted_plugin_ci(d$Y, d$A, d$X, w))
center_adj <- list(length = ca_res$value$ci[2] - ca_res$value$ci[1], time = ca_res$seconds,
                    lower = ca_res$value$ci[1], upper = ca_res$value$ci[2])

## ---- output: one row per job -------------------------------------------------
## Note: Plugin and CenterAdj were already Wald (normal-approximation) CIs (see
## ?DistBalancing::wald_ci); SS.Wald.* / Boot.Wald.* add the same normal-approximation
## construction for the subsampling and bootstrap methods, alongside their existing
## percentile CIs (SS.*/Boot.*).
RESULT <- data.frame(
  kernel = kernel_label, kappa = kappa, N = N, SEED = SEED,
  point_est = point_est,
  SS.Lower = ss$lower, SS.Upper = ss$upper, SS.Time = ss$time,
  SS.Wald.Lower = ss_wald$lower, SS.Wald.Upper = ss_wald$upper,
  Boot.Lower = boot$lower, Boot.Upper = boot$upper, Boot.Time = boot$time, Boot.SD = boot$sd,
  Boot.Wald.Lower = boot_wald$lower, Boot.Wald.Upper = boot_wald$upper,
  Plugin.Lower = plugin$lower, Plugin.Upper = plugin$upper, Plugin.Time = plugin$time,
  CenterAdj.Lower = center_adj$lower, CenterAdj.Upper = center_adj$upper,
  CenterAdj.Time = center_adj$time
)

write.csv(RESULT,
          file = sprintf("Result_ATE_%s_kappa%.1f_N%05d_SEED%05d.csv",
                          kernel_label, kappa, N, SEED),
          row.names = FALSE)
