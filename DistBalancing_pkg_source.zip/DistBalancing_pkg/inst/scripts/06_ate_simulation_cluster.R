#!/usr/bin/env Rscript
## ============================================================================
## Simulation study (Summary_2026_08_21.pdf, "Simulation study" section).
## One self-contained cluster/array job: given a single BATCH index, this script
## simulates ONE dataset for one (N, kernel, kappa, seed) cell, computes the point
## estimate, and computes the four confidence intervals the target table asks for
## (SS, bootstrap, plug-in variance, center-adjusted plug-in variance) -- plus, for
## SS and bootstrap, a Wald (normal-approximation) variant alongside the default
## percentile CI, since plug-in/center-adjusted were already Wald CIs and SS/bootstrap
## previously had no Wald counterpart (see ?DistBalancing::wald_ci) -- plus their
## computation times, and writes one row of output. Run it as an array job:
##
##   Rscript 06_ate_simulation_cluster.R <BATCH>
##
## with BATCH = 1, ..., nrow(Hyperparameter) (see the grid below), e.g. via Slurm:
##   sbatch --array=1-<N_JOBS> --wrap="Rscript 06_ate_simulation_cluster.R \$SLURM_ARRAY_TASK_ID"
## or HTCondor's `queue <N_JOBS>` with `arguments = $(Process)`.
##
## After all jobs finish, concatenate their output CSVs and run
## 07_ate_simulation_report.R to build the summary table (Bias, ESE, SEB,
## Shapiro-Wilk normality test, and per-CI-method length/coverage/time).
##
## ---------------------------------------------------------------------------
## IMPORTANT CAVEATS -- please read before running at scale:
##
## 1. This targets the ATE (Summary: "Focus on the ATE estimation, not LATE"), via
##    DistBalancing::dgp_ate(), an ATE-focused data-generating process with a
##    `kappa` in [0, 1] interpolating (1-e(X))*mu1(X) + e(X)*mu0(X) between a
##    constant (kappa = 0) and a non-constant function of X (kappa = 1), per the
##    Summary's two stated boundary conditions. THIS IS OUR OWN CONSTRUCTIVE
##    INTERPRETATION of those two conditions for general kappa -- the source
##    material does not specify one. See ?DistBalancing::dgp_ate.
##
## 2. The "center-adjusted plug-in CI" uses DistBalancing::center_adjusted_plugin_ci(),
##    which is EXPLICITLY A PLACEHOLDER: the Summary refers to "the center-adjusted
##    variance estimator described in the document I provided", which was not part
##    of the materials available to this implementation. Our version centers each
##    arm's weighted squared residuals at an in-sample linear-regression estimate of
##    mu_z(X) rather than at the raw weighted group mean (see
##    ?DistBalancing::center_adjusted_plugin_ci for the exact formula). If your
##    team's intended definition differs, only that one function needs to change --
##    this script and the report script do not need to.
##
## 3. Cost: for N = 4000, the CFD Gram matrix is 4000 x 4000, and both the
##    subsampling (B = 500 replicates) and bootstrap (B = 500 replicates) CIs each
##    re-solve a quadratic program of that size hundreds of times. This can be slow
##    per job (the QP solve, not the kernel construction, dominates). If a BATCH is
##    too slow on your cluster's per-job time limit, reduce `B_INFERENCE` below (it
##    only affects CI width/precision, not the point estimate), or -- per the
##    Summary -- split the work and share it back.
## ============================================================================

suppressMessages(library(DistBalancing))

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1) stop("Usage: Rscript 06_ate_simulation_cluster.R <BATCH>")
BATCH <- as.numeric(args[1])

## ---- hyperparameter grid --------------------------------------------------
## N: 500 doubling to 4000, matching the doubling pattern of the paper's other
##    simulation (100, 200, ..., 1600) at the new scale implied by the table image.
## kernel: the six methods in the target table (Isotropic = Matern, ED = energy).
## kappa: the three values named in the Summary.
N_GRID      <- c(500, 1000, 2000, 4000)
KERNEL_GRID <- c("Gaussian", "Laplace", "Isotropic", "ED", "IPW", "CBPS")
KAPPA_GRID  <- c(0, 0.5, 1)
N_REPS      <- 500                    # simulation replicates (SEED = 1..N_REPS)
B_INFERENCE <- 500                    # subsampling / bootstrap replicates per job

Hyperparameter <- expand.grid(kernel = KERNEL_GRID, kappa = KAPPA_GRID,
                               N = N_GRID, SEED = seq_len(N_REPS),
                               stringsAsFactors = FALSE)

kernel_label <- Hyperparameter[BATCH, "kernel"]
kappa        <- Hyperparameter[BATCH, "kappa"]
N            <- Hyperparameter[BATCH, "N"]
SEED         <- Hyperparameter[BATCH, "SEED"]
set.seed(SEED)

density_name <- switch(kernel_label, Gaussian = "gaussian", Laplace = "laplacian",
                        Isotropic = "matern", ED = "energy", NA_character_)
is_kernel <- !is.na(density_name)

## ---- simulate one dataset --------------------------------------------------
d <- dgp_ate(kappa, N, p = 10)

## ---- point estimate + weights ----------------------------------------------
w <- if (is_kernel) {
  cfd_weights(Z = d$A, X = d$X, density = density_name, lambda = default_lambda(N))$w
} else if (kernel_label == "IPW") {
  ipw_estimate(d$A, d$X)$w
} else {
  cbps_estimate(d$A, d$X)$w
}
point_est <- ate_weighting_estimate(d$Y, d$A, w)

time_it <- function(expr) {
  t0 <- proc.time()[["elapsed"]]
  val <- expr
  list(value = val, seconds = proc.time()[["elapsed"]] - t0)
}

## ---- SS CI (kernel/DB methods only, per Section 4.2 of the paper) ----------
## Both the percentile CI and the Wald ("Type 2", normal-approximation) CI come out
## of the same subsample_ci() call at no extra cost -- see ?DistBalancing::wald_ci.
ss <- list(length = NA_real_, time = NA_real_, lower = NA_real_, upper = NA_real_)
ss_wald <- list(length = NA_real_, time = NA_real_, lower = NA_real_, upper = NA_real_)
if (is_kernel) {
  ss_res <- time_it(subsample_ci(d$X, d$A, d$Y, density = density_name,
                                  lambda = default_lambda(N), B = B_INFERENCE,
                                  estimand = "ate", seed = SEED))
  ci <- ss_res$value$ci$ate
  ss <- list(length = unname(ci[2] - ci[1]), time = ss_res$seconds,
             lower = unname(ci[1]), upper = unname(ci[2]))
  ci_w <- ss_res$value$wald_ci$ate$ci
  ss_wald <- list(length = unname(ci_w[2] - ci_w[1]), time = ss_res$seconds,
                   lower = unname(ci_w[1]), upper = unname(ci_w[2]))
}

## ---- bootstrap CI (all six methods) -----------------------------------------
## Likewise, bootstrap_ci() returns both the percentile CI and the Wald CI (centered
## at the original-sample point estimate `point_est`/`w`, passed in via `full_w` so
## it isn't recomputed) from one call.
boot_method <- if (is_kernel) density_name else tolower(kernel_label)
boot_res <- time_it(bootstrap_ci(d$X, d$A, d$Y, method = boot_method, B = B_INFERENCE,
                                  estimand = "ate", seed = SEED, full_w = w))
ci_boot <- boot_res$value$ci$ate
boot <- list(length = unname(ci_boot[2] - ci_boot[1]), time = boot_res$seconds,
             lower = unname(ci_boot[1]), upper = unname(ci_boot[2]),
             sd = stats::sd(boot_res$value$reps[, "ate"], na.rm = TRUE))  # -> SEB in the report
ci_boot_w <- boot_res$value$wald_ci$ate$ci
boot_wald <- list(length = unname(ci_boot_w[2] - ci_boot_w[1]), time = boot_res$seconds,
                   lower = unname(ci_boot_w[1]), upper = unname(ci_boot_w[2]))

## ---- plug-in variance CI ----------------------------------------------------
pi_res <- time_it(plugin_ci(d$Y, d$A, w))
plugin <- list(length = pi_res$value$ci[2] - pi_res$value$ci[1], time = pi_res$seconds,
               lower = pi_res$value$ci[1], upper = pi_res$value$ci[2])

## ---- center-adjusted plug-in variance CI (see caveat #2 above) -------------
ca_res <- time_it(center_adjusted_plugin_ci(d$Y, d$A, d$X, w))
center_adj <- list(length = ca_res$value$ci[2] - ca_res$value$ci[1], time = ca_res$seconds,
                    lower = ca_res$value$ci[1], upper = ca_res$value$ci[2])

## ---- output: one row per job -------------------------------------------------
## Note: Plugin and CenterAdj were already Wald (normal-approximation) CIs (see
## ?DistBalancing::wald_ci); SS.Wald.* / Boot.Wald.* add the same normal-approximation
## construction for the subsampling and bootstrap methods, alongside their existing
## percentile CIs (SS.*/Boot.*).
RESULT <- data.frame(
  kernel = kernel_label, kappa = kappa, N = N, SEED = SEED,
  point_est = point_est,
  SS.Lower = ss$lower, SS.Upper = ss$upper, SS.Time = ss$time,
  SS.Wald.Lower = ss_wald$lower, SS.Wald.Upper = ss_wald$upper,
  Boot.Lower = boot$lower, Boot.Upper = boot$upper, Boot.Time = boot$time, Boot.SD = boot$sd,
  Boot.Wald.Lower = boot_wald$lower, Boot.Wald.Upper = boot_wald$upper,
  Plugin.Lower = plugin$lower, Plugin.Upper = plugin$upper, Plugin.Time = plugin$time,
  CenterAdj.Lower = center_adj$lower, CenterAdj.Upper = center_adj$upper,
  CenterAdj.Time = center_adj$time
)

write.csv(RESULT,
          file = sprintf("Result_ATE_%s_kappa%.1f_N%05d_SEED%05d.csv",
                          kernel_label, kappa, N, SEED),
          row.names = FALSE)
