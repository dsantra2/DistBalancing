#!/usr/bin/env Rscript
## Reconstruction of the original replication code's Simulation/Simulation_Final.R,
## rewritten to call functions from the DistBalancing package instead of ad hoc,
## in-script implementations. Run as a single batch job (e.g. from HTCondor or
## SLURM), exactly like the original:
##
##   Rscript 01_simulation_final.R <BATCH>
##
## where <BATCH> selects one row of the hyperparameter grid below. The point
## estimate, subsampling CI (kernel methods only, per Section 4.2 of the paper),
## and bootstrap CI are written to a CSV file named after the row's parameters.
##
## Notable defaults inherited from the package:
##   * lambda = default_lambda(N) = 1/N^2 for every method, satisfying Assumption 7.
##   * the energy ("Energy"/"ED") kernel and the QP solve are both handled through
##     cfd_weights()/solve_qp_safe(), which is robust to the ED kernel's conditional
##     (not global) positive-semi-definiteness.
##   * subsample_ci() picks its subsample size automatically via moonboot's
##     minimum-volatility search and builds the CI via moonboot::mboot()/mboot.ci()
##     (see ?DistBalancing::subsample_ci).

suppressMessages(library(DistBalancing))

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1) stop("Usage: Rscript 01_simulation_final.R <BATCH>")
BATCH <- as.numeric(args[1])
set.seed(BATCH)

Hyperparameter <- expand.grid(
  kernel = c("gaussian", "laplacian", "energy", "IPW", "CBPS", "t", "matern"),
  DGP.type = c(1, 2),
  N = c(100, 200, 400, 800, 1600),
  inference = c("SS", "Boot"),
  SEED = 1:550
)

kernel    <- as.character(Hyperparameter[BATCH, "kernel"])
DGP.type  <- Hyperparameter[BATCH, "DGP.type"]
N         <- Hyperparameter[BATCH, "N"]
inference <- as.character(Hyperparameter[BATCH, "inference"])
SEED      <- Hyperparameter[BATCH, "SEED"]

is_kernel <- kernel %in% c("gaussian", "laplacian", "energy", "t", "matern")

d <- dgp_iv(DGP.type, N, p = 10)

# ---- point estimate --------------------------------------------------------
if (is_kernel) {
  w_full <- cfd_weights(Z = d$Z, X = d$X, density = kernel, lambda = default_lambda(N))$w
} else if (kernel == "IPW") {
  w_full <- ipw_estimate(d$Z, d$X)$w
} else {
  w_full <- cbps_estimate(d$Z, d$X)$w
}
point <- late_weighting_estimate(d$Y, d$A, d$Z, w_full)

# ---- inference --------------------------------------------------------------
best_m <- list(num = NA, denom = NA, late = NA)
CI.num <- CI.denom <- CI.late <- c(NA, NA)

if (inference == "Boot") {
  boot <- bootstrap_ci(d$X, d$Z, d$Y, d$A, method = kernel, B = 500,
                        estimand = "late", seed = SEED)
  CI.num   <- boot$ci$numerator
  CI.denom <- boot$ci$denominator
  CI.late  <- boot$ci$late
  best_m <- list(num = N, denom = N, late = N)
} else if (inference == "SS" && is_kernel) {
  ss <- subsample_ci(d$X, d$Z, d$Y, d$A, density = kernel, lambda = default_lambda(N),
                      B = 500, estimand = "late", seed = SEED)
  CI.num   <- ss$ci$numerator
  CI.denom <- ss$ci$denominator
  CI.late  <- ss$ci$late
  best_m   <- ss$best_m
}

RESULT <- data.frame(
  kernel = kernel, DGP.type = DGP.type, N = N, SEED = SEED, Inference = inference,
  m_num = best_m$num, num = point$numerator, Lower.num = CI.num[1], Upper.num = CI.num[2],
  m_denom = best_m$denom, denom = point$denominator, Lower.denom = CI.denom[1], Upper.denom = CI.denom[2],
  m_late = best_m$late, late = point$late, Lower.late = CI.late[1], Upper.late = CI.late[2]
)

write.csv(RESULT,
          file = sprintf("Result_DistBalancing_%s_DGP%05d_N%05d_%s_SEED%05d.csv",
                          kernel, DGP.type, N, inference, SEED),
          row.names = FALSE)
