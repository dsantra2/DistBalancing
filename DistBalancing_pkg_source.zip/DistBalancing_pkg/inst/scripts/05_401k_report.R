#!/usr/bin/env Rscript
## Reconstruction of DataAnalysis/401k_Report.R, using DistBalancing::load_401k(),
## DistBalancing::late_weighting_estimate(), and
## DistBalancing::select_m_by_volatility() to aggregate the per-resample CSVs
## produced by 04_401k_final.R (concatenated into Result_401k_combined_500.csv, as
## in the original) into the final point estimates and subsampling/bootstrap CIs.
##
## The per-resample CSVs store the *raw* (unscaled) subsampling replicates at every
## candidate m; this script rescales them to the full-sample pivot's scale (see
## ?DistBalancing::select_m_by_volatility for the exact formula) before picking the
## best m and its confidence interval, via the shared, tested
## select_m_by_volatility() helper.

suppressMessages({
  library(DistBalancing)
  library(dplyr)
  library(purrr)
})

d401k <- load_401k()
N <- length(d401k$Y)

results <- read.csv("Result_401k_combined_500.csv", header = TRUE)

methods <- c("gaussian", "laplacian", "energy", "t", "matern")
weight_files <- paste0("weights_", methods, ".csv")

compute_full_estimate <- function(w) late_weighting_estimate(d401k$Y, d401k$A, d401k$Z, w)

estimates <- purrr::map_dfr(seq_along(methods), function(i) {
  w <- read.csv(weight_files[i])$x
  est <- compute_full_estimate(w)
  data.frame(kernel = methods[i], numerator = est$numerator,
             denominator = est$denominator, late = est$late)
})

ipw_full  <- ipw_estimate(d401k$Z, d401k$X, Y = d401k$Y, A = d401k$A)$late
cbps_full <- cbps_estimate(d401k$Z, d401k$X, Y = d401k$Y, A = d401k$A)$late

## ---- subsampling CI (kernel methods only), matching the paper's Section 4.2 ----
select_best_m <- function(method) {
  full_est <- estimates %>% filter(kernel == method)
  df <- results %>% filter(kernel == method, Inference == "SS")
  grid <- sort(unique(df$m))

  scaled_reps_by_m <- setNames(lapply(grid, function(m) {
    reps <- df %>% filter(m == !!m) %>% select(num, denom, late) %>%
      rename(numerator = num, denominator = denom)
    scale_factor <- sqrt(m / N)
    reps$numerator   <- full_est$numerator   - scale_factor * (reps$numerator   - full_est$numerator)
    reps$denominator <- full_est$denominator - scale_factor * (reps$denominator - full_est$denominator)
    reps$late        <- full_est$late        - scale_factor * (reps$late        - full_est$late)
    as.matrix(reps)
  }), as.character(grid))

  select_m_by_volatility(scaled_reps_by_m, grid = grid, VI_bw = 2)
}

## ---- bootstrap CI (all seven methods) ------------------------------------------
run_boot <- function(method) {
  df <- results %>% filter(Inference == "Boot", kernel == method)
  list(
    numerator_CI   = stats::quantile(df$num,   probs = c(0.025, 0.975), na.rm = TRUE),
    denominator_CI = stats::quantile(df$denom, probs = c(0.025, 0.975), na.rm = TRUE),
    late_CI        = stats::quantile(df$late,  probs = c(0.025, 0.975), na.rm = TRUE)
  )
}

all_methods <- c(methods, "IPW", "CBPS")
boot_results <- purrr::map(all_methods, run_boot) %>% setNames(all_methods)
subsampling_results <- purrr::map(methods, select_best_m) %>% setNames(methods)
