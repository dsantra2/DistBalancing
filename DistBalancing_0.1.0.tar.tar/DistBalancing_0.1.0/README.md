# DistBalancing

An R package implementing the characteristic function distance (CFD) framework of
Santra, Chen, and Park (2026), *"Distributional Balancing for Causal Inference: A
Unified Framework via Characteristic Function Distance."* It reimplements the
exploratory simulation/data-analysis code written for the paper's
replication repository (<https://github.com/dsantra2/DistBalancing>) as a R package.


## Installation

```r
# from the package source directory
devtools::install(".")

# core dependency not on CRAN's usual mirrors in every environment:
# install.packages("optiSolve")   # or: remotes::install_github("cran/optiSolve")
```

`WeightIt` (for `cbps_estimate()`) and `DoubleML`/`mlr3`/`mlr3learners` (for
`load_401k()`) are `Suggests`-only — the core package builds, loads, and passes its
test suite without them.

## The flexible `cfd_weights()` entry point

```r
library(DistBalancing)

# 1. Built-in kernel by name (bandwidth defaults to the median heuristic):
w <- cfd_weights(Z, X, density = "gaussian")$w

# 2. A different built-in family, explicit bandwidth:
w <- cfd_weights(Z, X, density = "matern", bandwidth = 0.8)$w

# 3. A fully custom spectral density / kernel:
my_density <- cfd_density("custom",
  kernel_fun = function(D, bandwidth) exp(-(D / bandwidth)^1.5),  # some other kernel
  distance   = "euclidean")
w <- cfd_weights(Z, X, density = my_density)$w

# 4. Bypass kernel construction entirely and hand the QP its Q matrix directly:
w <- cfd_weights(Z, Q = my_own_Q_matrix)$w
```

`density` accepts `"gaussian"`, `"laplacian"`, `"t"` (Student-t / the paper's `t5`
family), `"matern"` (isotropic), `"energy"` (energy distance / ED), or a
`cfd_density("custom", ...)` object. `lambda` defaults to `default_lambda(n) = n^-2`.

## The four coding fixes

### 1. `lambda` rate (Assumption 7: `lambda = o(n^-1)`)

The original replication code was inconsistent: `weights_Final.R` and
`401k_Final.R` used `lambda = 1/N^2`, but `Simulation_Final.R`'s `sim()` used
`lambda = 1/N` — which does **not** satisfy `lambda = o(n^-1)` (the ratio
`lambda / n^-1` is identically 1, not vanishing), so it does not guarantee the
penalty term is asymptotically negligible. `default_lambda(n) = n^-2` is now the
package-wide default, and `cfd_weights()`/`subsample_ci()`/`bootstrap_ci()` all warn
if a caller supplies a `lambda` that provably violates the rate (`lambda >= 1/n`).

### 2. The energy-distance ("ED") Gram matrix

`cfd_density("energy")` implements exactly `k_ED(x, x') = -||x - x'||_2` (Example 4 /
Appendix A.2 of the paper), validated in `tests/testthat/test-kernels.R` against a
direct, brute-force pairwise-distance computation. Because this kernel is only
*conditionally* (not globally) positive semi-definite — Bochner's theorem does not
apply, since the generating density is not integrable — it is also the kernel that
most directly motivates fix #4 below.

### 3. The subsampling calculation

Appendix A.8's Algorithm 1 requires, for every candidate subsample size `m` and every
replicate `b`, first forming the *rescaled* statistic

```
tilde_tau^(m,b) = tau_hat + sqrt(m/n) * (tau_hat^(m,b) - tau_hat)
```

and only *then* computing both the confidence interval at `m` and the volatility
index used to select `m` from those rescaled statistics. The original
`choose_best_m_ss()` in `Simulation_Final.R` instead computed the volatility index
directly from the **unscaled** subsample quantiles, and applied the `sqrt(m/n)`
rescaling only afterward, in a separate script (`Simulation_Report.R`), to the
already-selected `m`'s CI endpoints. Because rescaling and taking a quantile commute,
this produces the same *final reported interval* once `m` is fixed — but it does
**not** select the same `m`, since the local volatility of the unscaled bounds is a
different function of `m` than the local volatility of the rescaled bounds (the
`sqrt(m/n)` factor itself varies with `m`).

Interestingly, the *other* copy of this logic in the original repository —
`401k_Report.R`'s own `choose_best_m_ss()`, used for the real-data application — did
**not** have this bug: it already rescaled before computing the volatility index. So
this fix brings `Simulation_Final.R`'s logic in line with what `401k_Report.R` was
already doing correctly. `subsample_ci()` (live subsampling) and
`select_m_by_volatility()` (for aggregating externally-computed resamples, as in the
batch-job `inst/scripts/04_401k_final.R` / `05_401k_report.R` workflow) both now
apply the rescaling before any CI/volatility computation, and
`tests/testthat/test-inference.R` regression-tests this both conceptually (a minimal
example where the two orderings provably select different `m`) and directly (bit-level
verification that `subsample_ci()`'s per-`m` CI equals the manually-computed,
correctly-ordered quantile).

### 4. The QP solver

`optiSolve::solvecop()` was called directly on the raw `Q` matrix with no check that
the solve actually succeeded. That is fragile precisely for the energy-distance
kernel introduced by the paper's own Example 4: since `-||x - x'||_2` is only
conditionally negative definite, `Q` can be numerically indefinite (especially for
small `lambda`), which makes the `quadprog` backend underneath `optiSolve` fail with
*"matrix D in quadratic function is not positive definite"* — silently, if the
caller doesn't check the solver's status. `solve_qp_safe()` fixes this by
symmetrizing `Q`, flooring its smallest eigenvalue so the problem is always
numerically positive definite, checking the solver's actual return status rather
than trusting it, and falling back to calling `quadprog::solve.QP` directly if
`optiSolve` still fails.

## Reproducing the original analyses

`system.file("scripts", package = "DistBalancing")` contains five scripts that
reconstruct the original repository's five analysis files using package functions:

| Original file | Reconstruction |
|---|---|
| `Simulation/Simulation_Final.R` | `01_simulation_final.R` |
| `Simulation/Simulation_Report.R` | `02_simulation_report.R` |
| `DataAnalysis/weights_Final.R` | `03_weights_401k.R` |
| `DataAnalysis/401k_Final.R` | `04_401k_final.R` |
| `DataAnalysis/401k_Report.R` | `05_401k_report.R` |

`01_simulation_final.R` and `04_401k_final.R` keep the original one-job-per-batch-index
design (`Rscript 01_simulation_final.R <BATCH>`) for HTCondor/SLURM-style array jobs.
Note that, because of fix #1 (a consistent `lambda`) and fix #3 (correct subsample-size
selection), numerical results from these scripts will differ somewhat from the
original repository's output, even holding the random seed fixed.

## Testing

```r
devtools::test(".")       # 40 tests across kernels, weights, estimators, dgp, inference
devtools::check(".")      # 0 errors (Suggests-availability NOTE only, when offline)
```
