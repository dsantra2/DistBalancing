# DistBalancing 0.1.0

Initial release. Reimplements the characteristic function distance (CFD) distributional
balancing framework of Santra, Chen, and Park (2026) as an R package, per the "Coding"
action items of the `Summary_2026_08_21.pdf` revision plan:

* A flexible `cfd_weights()` entry point that either builds the CFD Gram matrix from a
  named or custom `cfd_density()` (Gaussian, Laplacian, Student-t, Matern/isotropic,
  energy-distance, or a user-supplied kernel/sampler), or accepts a user-supplied `Q`
  matrix directly, bypassing kernel construction entirely.
* Four coding-issue fixes carried through the whole package (see `README.md` for
  detail): a consistent `lambda = o(n^-1)` regularization rate via `default_lambda()`;
  a validated, tested energy-distance ("ED") Gram matrix; a subsampling procedure
  (`subsample_ci()` / `select_m_by_volatility()`) that rescales replicates by
  `sqrt(m/n)` *before* selecting the subsample size, per Appendix A.8's Algorithm 1;
  and a numerically robust QP solver (`solve_qp_safe()`) that eigenvalue-floors an
  indefinite `Q` and falls back to `quadprog::solve.QP` if `optiSolve` fails.
* `inst/scripts/` reconstructs the original replication repository's five analysis
  scripts (`Simulation_Final.R`, `Simulation_Report.R`, `weights_Final.R`,
  `401k_Final.R`, `401k_Report.R`) to call these package functions instead of ad hoc
  in-script implementations.
