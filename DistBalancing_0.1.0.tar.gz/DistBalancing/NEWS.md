# DistBalancing 0.1.0

Initial release. Reimplements the characteristic function distance (CFD) distributional
balancing framework of Santra, Chen, and Park (2026) as an R package, per the "Coding"
action items of the `Summary_2026_08_21.pdf` revision plan:

* A flexible `cfd_weights()` entry point that either builds the CFD Gram matrix from a
  named or custom `cfd_density()` (Gaussian, Laplacian, Student-t, Matern/isotropic,
  energy-distance, or a user-supplied kernel/sampler), or accepts a user-supplied `Q`
  matrix directly, bypassing kernel construction entirely.
* Four coding-issue fixes carried through the whole package (see `README.md` for
  detail): a consistent `lambda = o(n^-1)` regularization rate via `default_lambda()`;
  a validated, tested energy-distance ("ED") Gram matrix; a subsampling procedure
  (`subsample_ci()` / `select_m_by_volatility()`) that rescales replicates by
  `sqrt(m/n)` *before* selecting the subsample size, per Appendix A.8's Algorithm 1;
  and a numerically robust QP solver (`solve_qp_safe()`) that eigenvalue-floors an
  indefinite `Q` and falls back to `quadprog::solve.QP` if `optiSolve` fails.
* `inst/scripts/` reconstructs the original replication repository's five analysis
  scripts (`Simulation_Final.R`, `Simulation_Report.R`, `weights_Final.R`,
  `401k_Final.R`, `401k_Report.R`) to call these package functions instead of ad hoc
  in-script implementations.
* Added the ATE-focused simulation study from the Summary's "Simulation study"
  section: `dgp_ate()`, `true_ate()`, `plugin_ci()`, `center_adjusted_plugin_ci()`,
  and the cluster-parallelizable `inst/scripts/06_ate_simulation_cluster.R` /
  `07_ate_simulation_report.R`. See the README for two open interpretive choices
  (the `kappa` DGP and the center-adjusted variance formula) this required in the
  absence of source material specifying them.
* `cbps_estimate()` now calls `CBPS::CBPS(..., ATT = 0)` directly instead of going
  through `WeightIt::weightit(method = "cbps")`, avoiding `WeightIt`'s heavier
  dependency chain (notably a `ggplot2 >= 4.0.0` requirement) for numerically
  equivalent propensity scores.

## Post-release fixes (reported by the paper's authors, 2026-09-07)

* **Fixed the direction of `subsample_ci()`'s rescaling pivot.** The confidence
  interval is obtained by inverting the pivot `sqrt(n)(tau_hat - tau)`, whose
  distribution is approximated by that of the subsample statistic
  `sqrt(m)(tau_hat^(m,b) - tau_hat)` (Politis, Romano and Wolf, 1999). Solving for
  `tau` requires a **minus** sign and swaps which raw quantile enters which bound:
  `LL = tau_hat - sqrt(m/n)*(q_hi_raw - tau_hat)`,
  `UL = tau_hat - sqrt(m/n)*(q_lo_raw - tau_hat)`. The previous implementation used
  `tau_hat + sqrt(m/n)*(q_lo_raw/q_hi_raw - tau_hat)` -- a different, non-equivalent
  interval (they coincide only when the raw subsample distribution happens to be
  symmetric about `tau_hat`). Fixed in `subsample_ci()`; see the "Bug fix 2" note in
  `?subsample_ci` for the full derivation, and `tests/testthat/test-inference.R` for
  a regression test that provably distinguishes the two formulas.
* **Added Wald (normal-approximation) confidence intervals.** A new exported
  `wald_ci(estimate, se, alpha)` implements `estimate +/- z_(1-alpha/2)*se`.
  `plugin_ci()` and `center_adjusted_plugin_ci()` were already Wald CIs (now
  implemented via this shared helper); `subsample_ci()` and `bootstrap_ci()` now
  *also* return a Wald CI (`$wald_ci`, plus `$se`) alongside their existing
  percentile CI, at no extra computational cost (`subsample_ci()`'s Wald `se` is the
  standard deviation of the rescaled replicates at the selected `m` -- Politis,
  Romano and Wolf 1999, Sec. 2.2's "Type 2" CI; `bootstrap_ci()`'s is the standard
  deviation of the bootstrap replicates, centered at the original-sample estimate).
  `bootstrap_ci()` also gained a `full_w` argument to avoid recomputing the
  full-sample weights when the caller already has them, and now returns
  `full_estimate`. `inst/scripts/06_ate_simulation_cluster.R` /
  `07_ate_simulation_report.R` were updated to compute and summarize the new
  `SS.Wald.*` / `Boot.Wald.*` CI columns alongside the existing four.
* **Added a finite-moment balance penalty.** `moment_balance_gram()` constructs the
  QP contribution of `m(w)'Qm m(w)` (weighted-mean covariate imbalance, the
  finite-dimensional analogue of the CFD's distributional balance); `cfd_weights()`
  gained `moment_gamma` (default `0`, off) and `moment_Q` to add it on top of the
  CFD objective. This is our own standard construction -- no source material defines
  a specific `m`/`Q` for this term. `inst/scripts/08_moment_gamma_study.R` compares
  `moment_gamma` empirically and finds **no consistent finite-sample improvement**
  in the ATE simulation DGP (a modest RMSE gain at N=300, a modest RMSE loss at
  N=150, coverage essentially unchanged); see the README for the full result and
  interpretation.
* **Fixed two independent, significant bugs in `solve_qp_safe()`**, found while
  testing the moment-penalty feature (a moment-only QP is rank-deficient and
  reliably triggers code paths the CFD-only QP rarely does):
  1. `.try_optisolve()`'s `optiSolve::lincon()` call omitted `name`, which some
     `optiSolve` versions default to `rownames(A)` (`NULL`/wrong length for a plain
     matrix) -- so the call always errored, and **every QP in this package silently
     ran through the quadprog fallback**, regardless of solver preference.
  2. That fallback's `Dmat` was missing a factor of 2 (`quadprog::solve.QP` solves
     `1/2 w'Dw - d'w`, requiring `Dmat = 2*Q` to match this package's `w'Qw + q'w`
     convention) -- so, combined with bug 1, **every weight vector computed by this
     package up to this point solved a different, incorrect QP** (linear term
     over-weighted 2x). Both are fixed and cross-verified against a hand-derived
     closed-form QP solution (`tests/testthat/test-weights.R`).
  `solve_qp_safe()` gained `prefer_solver = c("quadprog", "optiSolve")` (default
  changed to `"quadprog"` first: with bug 1 fixed, `optiSolve` was measured ~2000x
  slower than `quadprog` at `n=500` for mathematically identical results; pass
  `prefer_solver = "optiSolve"` to match the paper's stated methodology exactly, at
  that speed cost).

## Subsampling now backed by moonboot (2026-09-09)

* **`subsample_ci()` is now built on the CRAN `moonboot` package** instead of a
  hand-rolled implementation of the same procedure. Subsample-size selection now
  calls `moonboot::estimate.m()` (new `m_method` argument, default `"politis"` for
  the minimum-volatility method of Politis, Romano and Wolf 1999, matching Appendix
  A.8; also available: `"bickel"`, `"goetze"`, `"sherman"`), resampling is done by
  `moonboot::mboot()`, and the confidence interval by `moonboot::mboot.ci(type =
  "basic")` at the estimator's root-n convergence rate (`tau = sqrt`, Theorem 4.1).
  This is mathematically equivalent to the previously fixed pivot-inversion formula
  (`?subsample_ci` for the exact formula), while relying on an independently
  maintained package for the resampling and CI mechanics. `moonboot` is now a hard
  dependency (`Imports`).
* **New arguments**: `m` (skip the search and use a fixed subsample size), `m_method`,
  `min.m` (default `max(3, floor(sqrt(n)))`), `m_params`, `m_R` (replicates per
  candidate `m` during the search, default 100), and `tau` (the convergence-rate
  function, default `sqrt`).
* **Removed arguments/return values**: `grid` and `VI_bw` (the manual candidate grid
  and volatility-index neighborhood width are now handled internally by
  `moonboot::estimate.m()`); the returned `grid`, `VI`, and `ci_by_m` diagnostics are
  replaced by `boot`, the underlying per-component `moonboot::mboot()` object(s).
  `select_m_by_volatility()` (for aggregating replicates computed across separate
  batch jobs) is unchanged.
* `inst/scripts/01_simulation_final.R` was updated for the new argument list (its
  `VI_bw` argument no longer exists). `inst/scripts/05_401k_report.R`'s own,
  independent implementation of the replicate-rescaling formula was also corrected
  to use the same minus-sign pivot inversion as `subsample_ci()` (it had inherited
  the earlier, incorrect "+" version).

## Finite-moment penalty generalized to nonlinear features (2026-09-10)

* **`moment_balance_gram()` and `cfd_weights()` now accept an arbitrary feature map
  for the finite-moment penalty**, via a new `features`/`moment_features` argument
  (a function mapping the `n x d` covariate matrix to an `n x m` feature matrix
  \(\Phi(X)\)). The penalty \(\gamma \cdot m(w)^\top Q_m m(w)\) now targets the
  weighted-mean imbalance of \(\Phi(X)\) rather than always `X` itself, so nonlinear
  moments (e.g. second moments, interactions) can be balanced the same way as
  covariate means. This generalizes, rather than changes, the previous behavior:
  the default (`features = NULL`) is exactly the identity map `function(X) X`, so
  every existing call is numerically unaffected (verified by a regression test
  comparing the default against an explicit identity map, and by the full existing
  test suite passing unchanged). `moment_Q`'s dimensions now follow the feature
  map's output size `m` (`d` when `features` is the default identity, as before).
  `inst/scripts/08_moment_gamma_study.R`'s `run_grid()` gained a matching
  `features` argument for comparing the mean-only penalty against a nonlinear one.

## Fixed a factor-of-2 QP bug in `cfd_weights()`, and made `subsample_ci()`/`bootstrap_ci()` consistent with the point estimate's full specification (2026-09-10, reported by the paper's authors)

* **Fixed a significant bug in `cfd_weights()`'s automatic (non-`Q`-supplied) `Qb`/`qb`
  construction: it solved the wrong QP for BOTH `three_way = TRUE` (the package
  default) and `three_way = FALSE`.** Writing \(D_1\)/\(D_0\) for the treated/control
  indicator matrices and \(K\) for the Gram matrix, the correctly-scaled objective
  \(w^\top Q w + q^\top w\) equals (up to a constant not involving `w`) the sum of
  pairwise squared MMDs among the implied treated-arm, control-arm, and (for
  `three_way = TRUE`) full-sample empirical measures -- eq. (12) for `three_way =
  FALSE`, eq. (13)/(17) for `three_way = TRUE`. The previous code's linear term `qb`
  was missing an overall factor of 2 in both cases, and (for `three_way = TRUE`
  only) the quadratic term `Qb` was *also* missing a factor of 2 on the arm-vs-arm
  component relative to the arm-vs-pooled components -- effectively under-weighting
  the arm-vs-arm balancing term relative to the other two. **This changes the
  numeric weights `cfd_weights()` returns for `three_way = TRUE` (the default)
  relative to every prior version of this package**; for `three_way = FALSE` only
  the previously-implicit relative scale of `Qb` vs. `qb` changes (which does affect
  the optimal `w`, since `lambda`'s regularization is added to `Qb` alone). The
  corrected construction is documented in full in `?cfd_weights` and verified by a
  brute-force pairwise-MMD comparison in `tests/testthat/test-weights.R` (in
  addition to the existing closed-form-`Qb` regression test, updated for the fix).
  A user-supplied `Q`/`q` (bypassing automatic construction) is unaffected -- it is
  always used exactly as given -- and `moment_balance_gram()`'s own construction
  was independently verified to already be correct (no change).
* **`subsample_ci()` and `bootstrap_ci()` now accept `moment_gamma`/`moment_Q`/
  `moment_features`**, applied identically to the full-sample point estimate and to
  every subsample/bootstrap replicate's weight computation -- previously these
  arguments could only be passed to `cfd_weights()` directly, so a non-zero
  `moment_gamma` made the full-sample point estimate and the resampled replicates
  silently inconsistent (different QP specifications). Both functions also now
  accept (and immediately reject, with a clear error) a `Q` argument: a
  user-supplied `Q` is a fixed matrix tied to the full sample's own size and arm
  composition and cannot be validly rebuilt for a subsample or bootstrap resample of
  a different size/composition, so this is a deliberate, explicit limitation rather
  than a silent inconsistency -- supply a kernel (`K`/`density`, or `method` for
  `bootstrap_ci()`) instead, which both functions can correctly rebuild per
  replicate.

## User-specified moments with a ratio parameter, data-driven lambda_n (2026-09-24)

* **`cfd_weights(moment_ratio = c0)`** combines the distributional term with the
  user-specified moment term as `L(w) = w'((c0/k) Q_phi + Q_G) w + ...`, where
  `k = ||Q_phi|| / ||Q_G||` (Frobenius by default, `moment_norm = "2"` for the
  spectral norm) puts both matrices on the same scale, so `c0` is directly their
  relative weight (`0` = purely distributional). The fit returns `moment_scale` (`k`)
  and the implied absolute weight `moment_gamma` (`c0/k`); `moment_gamma` can still
  be given directly, but not together with `moment_ratio`.
* **User-specified moments as inputs**: `moment_features` (and
  `moment_balance_gram(features = )`) now also accepts a precomputed `n x m` matrix
  of moment functions, besides a function of `X`. `subsample_ci()`/`bootstrap_ci()`
  subset such a matrix to each resample's rows.
* **Data-driven regularization `lambda = "ipw"`**: the penalty is written
  `lambda_n ||w/n||^2` with
  `lambda_n = n^2 L(w_IPW) / ||w_IPW||^2 * lambda_const * n^(-lambda_decay)`
  (defaults `0.1`, `0.01`), `L` being the full objective (moment term included) at
  the Hajek-normalized inverse-propensity weights; `lambda_ref_w` substitutes other
  reference weights. The fit returns `lambda` (= `lambda_n`), `lambda_method` and
  `ridge` (the coefficient on `||w||^2`). The default `lambda = NULL` is unchanged
  (fixed `n^-2`, penalty `lambda^2 ||w||^2`).
* `moment_balance_gram()` now also returns the constant `const`, and `cfd_weights()`
  returns `loss_const` and `loss`, so the objective `L(w)` (not only its
  `w`-dependent part) is available; this is what the `lambda_n` rule evaluates.
* `subsample_ci()` and `bootstrap_ci()` gained `moment_ratio`, `moment_norm`,
  `lambda_const`, `lambda_decay`, and pass `lambda = "ipw"` through, re-estimating
  `k` and `lambda_n` on every resample so the interval describes the same estimator
  as the point estimate. `subsample_ci()` also gained `full_w` to reuse full-sample
  weights that were already computed.
* **Speed**: the kernel term's `Q_G`/`q_G` are now built block-wise instead of via
  products with `n x n` diagonal matrices, which were cubic in `n` and dominated
  the cost of a fit. A full fit now takes about 1 s at `n = 1000` and 50 s at
  `n = 4000` (previously several minutes). `Q` is now stored in symmetric form; the
  quadratic form, and hence the weights, are unchanged (verified to ~1e-9 against
  the previous version).
* `inst/scripts/06_ate_simulation_cluster.R` / `07_ate_simulation_report.R` were
  rewritten for the new study: per dataset, `c0 = 0` plus every (moment set in
  {linear, quadratic}) x (`c0` in {0.1, 1, 10}) configuration with `lambda = "ipw"`,
  subsampling / plug-in / center-adjusted CIs (the bootstrap CI was dropped), IPW
  and CBPS comparators, kernels Gaussian / Laplace / isotropic / ED,
  `N` in {500, 1000, 2000, 4000}, `kappa = 1`, 55 replicates. The report adds RMSE,
  RMSE relative to `c0 = 0` (paired, same datasets) and the average estimated SEs.

## Plug-in variances now follow (44) and (56) of the asymptotic-normality write-up (2026-09-25)

* **`plugin_ci()` is now the raw plug-in estimator (44)**,
  `V_raw = P_n{(S_hat - tau_hat)^2}` with summands
  `S_i = Z_i g1_i Y_i - (1 - Z_i) g0_i Y_i` and normalized coefficients
  `g_{z,i} = (n / n_z) w_i`, `se = sqrt(V_raw / n)`. The previous version centered
  each arm's weighted outcomes at that arm's own weighted mean, which is a center
  adjustment with two arm-specific constants (not the optimal one), not (44).
* **`center_adjusted_plugin_ci()` now centers by the single constant (56)**,
  `theta_star = P_n{Z g1^2 Y + (1-Z) g0^2 Y} / P_n{Z g1^2 + (1-Z) g0^2}`, computed
  from the weights alone, and recomputes (44) on `Y - theta_star`. The point
  estimate is unchanged. The previous version centered at *fitted functions of X*
  from two arm-wise OLS regressions, which do not appear in the write-up; subtracting
  a function of `X` removes the `E[{mu1(X) - mu0(X) - tau}^2]` term of `V` in (43),
  which is why its coverage in the 06/07 simulation fell to about 0.5-0.65.
  (An interim fix that added that term back through the same regressions has been
  withdrawn.) The function no longer takes `X`: the signature is
  `center_adjusted_plugin_ci(Y, Z, w, alpha = 0.05, theta = NULL)`, where `theta`
  can also be `"mean"` (`P_n Y`) or a number; the constant used is returned as
  `theta`. With weights satisfying the normalization constraints, `theta_star` is
  exactly the minimizer of the empirical centered variance, and `theta = 0`
  reproduces `plugin_ci()`.
* Monte Carlo check (kappa = 1, 200-400 replicates): both intervals cover at or
  above 0.95 and are conservative as Theorem 5 predicts, the centered one narrower
  (e.g. IPW, N = 1000: empirical SE 0.187, raw SE 0.200 / coverage 0.973,
  centered SE 0.189 / coverage 0.963; Gaussian CFD, N = 1000: empirical SE 0.186,
  raw 0.235 / 0.985, centered 0.223 / 0.985).
* `inst/scripts/06_ate_simulation_cluster.R` calls the new signature and gained
  `RUN_SUBSAMPLING` (default `TRUE`); `FALSE` skips subsampling and writes
  `Result_ATEnoSS_*.csv`, so the Plugin and CenterAdj columns of an earlier run can
  be recomputed quickly (datasets and weights are reproduced exactly from the
  seeds) and merged in -- see the comment next to the knob.

## Staged simulation, efficiency-bound SEB (2026-09-26)

* `inst/scripts/06_ate_simulation_cluster.R` now takes a stage:
  `Rscript 06_ate_simulation_cluster.R <STAGE> <BATCH>` with `STAGE` = `dgp`
  (N = 1000, linear moments with c0 = 0.1, bootstrap only, 200 replicates),
  `moments` (N = 1000/2000/4000; no moments vs. linear moments with c0 = 0.5 and 1,
  point estimates only, paired on the same datasets) or `inference` (N =
  1000/2000/4000, no moments; Wald (44), center-adjusted Wald (56), subsampling and
  bootstrap CIs). IPW and CBPS report the bootstrap CI only.
* SEB is now the same for every method: the efficiency bound sd(EIF)/sqrt(n), with
  sd(EIF) computed once from 1e8 draws by the new `inst/scripts/09_seb_eif.R`
  (which also reports the closed-form check and the Monte Carlo ATE used as the
  truth). Each method's own mean estimated SE is kept in the summary CSV.
* `inst/scripts/07_ate_simulation_report.R <STAGE>` writes the stage's summary CSV and
  LaTeX table.
* No changes to package functions.

## Simulation design D2 (2026-09-28)

* New `inst/scripts/sim_design.R` holds the simulation DGP (the pilot designs D0-D5,
  `DESIGN <- "D2"` selected: propensity coefficients 0.4 with e(X) capped into
  [0.05, 0.95]). `06_ate_simulation_cluster.R` and `09_seb_eif.R` source it, so the
  jobs, the true ATE and the SEB always use the same DGP; `07_ate_simulation_report.R`
  matches truth and SEB by design and reads the per-job CSVs directly.
* No changes to package functions.

## Simulation design H (2026-10-01)

* `inst/scripts/sim_design.R` adds design "H", the DGP of Zhang, Chen and Park (2026,
  "Sliced L^p distributional balancing", Section 5.1): X ~ Uniform[0,1]^10, quadratic
  confounding through C(X) = (X3 - 0.5)^2 - (X4 - 0.5)^2, true ATE 0; now the default
  (`DESIGN <- "H"`). `09_seb_eif.R` gives sd(EIF) = 2.128 (SEB x100 = 6.73 at n = 1000,
  matching the paper's Table 1).
* The `dgp` stage of `06_ate_simulation_cluster.R` now fits both phi = none (c0 = 0)
  and linear moments with c0 = 0.1 on each dataset.
* No changes to package functions.

# DistBalancing 0.1.1 (2026-10-01)

* **Fixed the energy-distance ("energy"/ED) kernel.** Its Gram matrix was `-D`
  (`D` = Euclidean distances), which is not positive semi-definite. `solve_qp_safe()`
  then floored the QP matrix's smallest eigenvalue by adding a large constant to its
  diagonal (on the order of 10^4 times the intended ridge penalty), which pulled the
  weights to almost exactly 1: ED weights had SD about 0.006, and the ED estimate
  coincided with the unweighted difference in means (correlation 1.000 across
  datasets). The ED Gram matrix is now the double-centered `-D`,
  `K_ij = -D_ij + mean_k D_ik + mean_k D_kj - mean D`. This leaves every discrepancy
  between equal-mass weightings, hence the CFD objective, its loss value and the
  data-driven lambda_n, exactly unchanged, but is positive semi-definite, so no
  eigenvalue floor is needed. On the Zhang-Chen-Park design (n = 1000, 40
  datasets) the ED bias (x100) drops from 4.40 to 0.67 and its SD rises from 6.07
  to 6.93 (SEB 6.73). Every earlier ED result (all simulations, any design) is
  affected and should be re-run; the other kernels are unchanged.
* `solve_qp_safe()` now warns when its eigenvalue floor exceeds 1% of the average
  diagonal of `Q`, since the balancing problem is then materially changed.
