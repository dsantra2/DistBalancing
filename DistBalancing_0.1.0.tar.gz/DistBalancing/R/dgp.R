#' Simulate data from the paper's instrumental-variable data-generating process
#'
#' Reproduces the data-generating process used in `Simulation_Final.R` of the
#' original replication code (Section 6 setup): a 10-dimensional (by default)
#' standard-normal covariate vector `X`, an unmeasured confounder `U`, a binary
#' instrument `Z` generated from a linear or non-linear propensity model, treatment
#' receipt `A` generated to satisfy the IV monotonicity assumption, and outcomes `Y`
#' with unit-scale noise.
#'
#' @param dgp_type `1` for the linear instrument-propensity model, `2` for the
#'   non-linear model.
#' @param n Sample size.
#' @param p Covariate dimension (default 10).
#' @return A list with elements `X`, `Z`, `A`, `Y`, and the population truths
#'   `denominator`, `numerator`, `LATE`.
#' @export
dgp_iv <- function(dgp_type = 1, n, p = 10) {
  expit <- function(v) exp(v) / (1 + exp(v))
  mu_y <- function(a, X, u) {
    coef <- rep(c(1, -0.5), each = p / 2)
    a * (1 + X %*% coef - u) + X %*% (-coef / 2) + 0.5 * u
  }
  ps_z <- function(dgp_type, X) {
    if (dgp_type == 1) {
      expit(X %*% rep(0.15, p))
    } else if (dgp_type == 2) {
      expit(abs(X) %*% rep(0.25, p) - 2.25)
    } else {
      stop("dgp_iv(): `dgp_type` must be 1 (linear) or 2 (non-linear).")
    }
  }

  X <- matrix(stats::rnorm(n * p), nrow = n)
  U <- stats::rnorm(n)
  Z <- stats::rbinom(n, 1, ps_z(dgp_type, X))

  gamma_0 <- 0.01
  gamma_x <- rep(c(-0.5, 0.5), each = p / 2)
  L0 <- -gamma_0 + X %*% gamma_x - 0.5 * abs(U)
  L1 <- gamma_0 + X %*% gamma_x + 0.5 * abs(U)
  A0 <- as.numeric(L0 >= 0)
  A1 <- as.numeric(L1 >= 0)
  A <- A0 * (1 - Z) + A1 * Z

  potY0 <- mu_y(0, X, U) + stats::rnorm(n) * 0.25
  potY1 <- mu_y(1, X, U) + stats::rnorm(n) * 0.25
  Y <- potY0 * (1 - A) + potY1 * A
  potYz1 <- potY1 * A1 + potY0 * (1 - A1)
  potYz0 <- potY1 * A0 + potY0 * (1 - A0)

  list(
    X = X, Z = Z, A = as.numeric(A), Y = as.numeric(Y),
    denominator = mean(A1 - A0),
    numerator = mean(potYz1 - potYz0),
    LATE = mean((potY1 - potY0)[A1 > A0])
  )
}
