#' Volatility-based subsampling confidence interval (Algorithm 1, Appendix A.8)
#'
#' Constructs a subsampling confidence interval for the CFD weighting estimator of
#' the ATE or LATE, using the volatility-based procedure of Politis, Romano, and Wolf
#' (1999) to data-adaptively pick the subsample size.
#'
#' \strong{Bug fix (Summary item "correcting the subsampling calculation"):} Appendix
#' A.8's Algorithm 1 requires, for every subsample size `m` and every replicate `b`,
#' first forming the *rescaled* statistic
#' \deqn{\tilde\tau^{(m,b)} = \hat\tau + \sqrt{m/n}\,(\hat\tau^{(m,b)} - \hat\tau)}
#' (step 6), and only then computing both the confidence interval at `m` (step 8) and
#' the volatility index used to *select* `m` (steps 12/14) from those rescaled
#' statistics. The original `choose_best_m_ss()` in `Simulation_Final.R` instead took
#' quantiles of the *raw, unscaled* subsample estimates to both pick `m` (via the
#' volatility index) and report the endpoints, applying the \eqn{\sqrt{m/n}} rescaling
#' only afterwards, in a separate post-processing script (`Simulation_Report.R`), to
#' the endpoints of the CI at the already-selected `m`. Because rescaling and taking a
#' quantile commute (the map is a monotone affine transform), the two orders give the
#' same *final reported interval* once `m` is fixed -- but they do **not** give the
#' same *selected* `m`, because the local volatility of the unscaled bounds is not the
#' same function of `m` as the local volatility of the rescaled bounds (the
#' \eqn{\sqrt{m/n}} factor itself varies with `m`). This function performs the
#' rescaling first, exactly as Algorithm 1 specifies, so subsample-size selection and
#' the reported interval are computed from the same (correctly scaled) quantity.
#'
#' @param X Covariate matrix (n x d).
#' @param Z Treatment/instrument indicator (0/1).
#' @param Y Outcome vector.
#' @param A Treatment-receipt vector, required when `estimand = "late"`.
#' @param density Passed to [cfd_weights()] for the full-sample and subsample weight
#'   computations.
#' @param bandwidth Passed to [cfd_weights()] for the full-sample and subsample
#'   weight computations.
#' @param lambda Passed to [cfd_weights()] for the full-sample and subsample weight
#'   computations.
#' @param three_way Passed to [cfd_weights()] for the full-sample and subsample
#'   weight computations.
#' @param L Passed to [cfd_weights()] for the full-sample and subsample weight
#'   computations.
#' @param K Optional precomputed full-sample Gram matrix; if supplied, subsample Gram
#'   matrices are taken as the corresponding submatrix `K[idx, idx]` (matching the
#'   original code's approach of reusing the full-sample kernel/bandwidth rather than
#'   recomputing the median heuristic on every subsample).
#' @param grid Candidate subsample sizes. Default: 20 equally spaced integers between
#'   `floor(sqrt(n))` and `floor(3 * sqrt(n))` (Appendix A.8).
#' @param B Number of subsamples drawn per grid point (default 500).
#' @param alpha Confidence level parameter (default 0.05 for a 95\% CI).
#' @param VI_bw Neighborhood half-width `h` for the volatility index (default 2,
#'   Appendix A.8's choice, following Remark 9.3.10 of Politis, Romano and Wolf 1999).
#' @param estimand `"late"` (default) or `"ate"`.
#' @param seed Optional RNG seed for reproducibility.
#'
#' @return A list with the selected subsample size(s) `best_m`, the confidence
#'   interval(s) `ci`, and `grid`/`VI`/`ci_by_m` diagnostics (the volatility index and
#'   confidence interval at every candidate `m`, keyed by `as.character(grid)`).
#' @export
subsample_ci <- function(X, Z, Y, A = NULL, density = "gaussian", bandwidth = NULL,
                          K = NULL, lambda = NULL, three_way = TRUE, L = 1e4,
                          grid = NULL, B = 500, alpha = 0.05, VI_bw = 2,
                          estimand = c("late", "ate"), seed = NULL) {
  estimand <- match.arg(estimand)
  if (estimand == "late" && is.null(A)) stop("subsample_ci(): `A` is required when estimand = 'late'.")
  if (!is.null(seed)) set.seed(seed)

  n <- length(Z)
  X <- as.matrix(X)
  if (is.null(K)) {
    gram <- cfd_kernel_gram(X, density = density, bandwidth = bandwidth, L = L)
    K <- gram$K
    bandwidth <- gram$bandwidth
  }
  if (is.null(lambda)) lambda <- default_lambda(n)

  full_w <- cfd_weights(Z = Z, K = K, lambda = lambda, three_way = three_way)$w
  full_est <- .point_estimate(Y, Z, A, full_w, estimand)

  if (is.null(grid)) {
    grid <- unique(round(seq(floor(sqrt(n)), floor(3 * sqrt(n)), length.out = 20)))
  }
  G <- length(grid)
  comps <- names(full_est)  # e.g. c("numerator","denominator","late") or c("ate")

  scaled <- vector("list", G)
  names(scaled) <- as.character(grid)

  for (g in seq_len(G)) {
    m <- grid[g]
    reps <- matrix(NA_real_, B, length(comps), dimnames = list(NULL, comps))
    for (b in seq_len(B)) {
      idx <- sample.int(n, m, replace = FALSE)
      Zs <- Z[idx]
      if (length(unique(Zs)) < 2) next
      w_sub <- tryCatch(
        cfd_weights(Z = Zs, K = K[idx, idx, drop = FALSE], lambda = lambda,
                    three_way = three_way)$w,
        error = function(e) NULL
      )
      if (is.null(w_sub)) next
      est_sub <- .point_estimate(Y[idx], Zs, if (!is.null(A)) A[idx] else NULL, w_sub, estimand)
      reps[b, ] <- unlist(est_sub[comps])
    }
    # ---- FIX: rescale every replicate BEFORE computing CI / volatility ----
    scale_factor <- sqrt(m / n)
    for (cc in comps) {
      reps[, cc] <- full_est[[cc]] + scale_factor * (reps[, cc] - full_est[[cc]])
    }
    scaled[[g]] <- reps
  }

  sel <- select_m_by_volatility(scaled, grid = grid, alpha = alpha, VI_bw = VI_bw)

  list(estimand = estimand, full_estimate = full_est, best_m = sel$best_m, ci = sel$ci,
       grid = grid, VI = sel$VI, ci_by_m = sel$ci_by_m, bandwidth = bandwidth, lambda = lambda)
}

.neighborhood <- function(i, G, h) {
  lo <- max(1, i - h); hi <- min(G, i + h)
  unique(c(lo:i, i:hi))
}

#' Select the subsample size by the volatility index (Algorithm 1, steps 8-14)
#'
#' Given the *already rescaled* subsampling replicates for every candidate subsample
#' size (see the "Bug fix" note in [subsample_ci()] for why the rescaling has to
#' happen before this step), computes the confidence interval at each candidate `m`
#' and the volatility index used to pick the best one. Exposed as a standalone
#' function so that it can also be used to reproduce the paper's two-stage
#' replication workflow, where resamples are computed by separate batch jobs (see
#' `04_401k_final.R` / `05_401k_report.R` under
#' `system.file("scripts", package = "DistBalancing")`) and only aggregated
#' afterwards -- in which case the caller performs the rescaling per resample and
#' then calls this function once per estimand component.
#'
#' @param scaled_reps_by_m A named list, keyed by `as.character(grid)`, of matrices
#'   (or data frames) of already-rescaled replicate statistics, one column per
#'   estimand component (e.g. `"numerator"`, `"denominator"`, `"late"`, or `"ate"`).
#' @param grid Candidate subsample sizes, in the same order/values as the names of
#'   `scaled_reps_by_m`.
#' @param alpha,VI_bw As in [subsample_ci()].
#' @return A list with `ci_by_m` (per-`m` confidence intervals), `VI` (the
#'   volatility index matrix), `best_m`, and `ci` (the confidence interval at the
#'   selected `best_m`, one per component).
#' @export
select_m_by_volatility <- function(scaled_reps_by_m, grid, alpha = 0.05, VI_bw = 2) {
  G <- length(grid)
  comps <- colnames(scaled_reps_by_m[[1]])

  ci_by_m <- lapply(scaled_reps_by_m, function(reps) {
    apply(reps, 2, stats::quantile, probs = c(alpha / 2, 1 - alpha / 2), na.rm = TRUE)
  })

  VI <- matrix(NA_real_, G, length(comps), dimnames = list(as.character(grid), comps))
  for (i in seq_len(G)) {
    nb <- .neighborhood(i, G, VI_bw)
    for (cc in comps) {
      Ls <- vapply(ci_by_m[nb], function(m2) m2[1, cc], numeric(1))
      Us <- vapply(ci_by_m[nb], function(m2) m2[2, cc], numeric(1))
      VI[i, cc] <- stats::sd(Ls, na.rm = TRUE) + stats::sd(Us, na.rm = TRUE)
    }
  }

  best_idx <- vapply(comps, function(cc) which.min(VI[, cc]), integer(1))
  best_m <- as.list(setNames(grid[best_idx], comps))
  ci <- lapply(comps, function(cc) ci_by_m[[best_idx[[cc]]]][, cc])
  names(ci) <- comps

  list(ci_by_m = ci_by_m, VI = VI, best_m = best_m, ci = ci)
}

.point_estimate <- function(Y, Z, A, w, estimand) {
  if (estimand == "ate") {
    list(ate = ate_weighting_estimate(Y, Z, w))
  } else {
    r <- late_weighting_estimate(Y, A, Z, w)
    list(numerator = r$numerator, denominator = r$denominator, late = r$late)
  }
}

#' Nonparametric bootstrap confidence interval (Appendix A.9)
#'
#' Standard nonparametric bootstrap: resample the data with replacement `B` times,
#' recompute the weighting estimator on each bootstrap sample, and report the
#' empirical `alpha/2` and `1 - alpha/2` quantiles as the confidence interval. Note
#' (Section 4.2 of the paper): this bootstrap can fail to attain nominal coverage for
#' the CFD weighting estimator, because the estimator need not be regular; subsampling
#' via [subsample_ci()] is the paper's recommended, provably valid alternative.
#'
#' @inheritParams subsample_ci
#' @param method One of the CFD density names (`"gaussian"`, `"laplacian"`, `"t"`,
#'   `"matern"`, `"energy"`), or `"ipw"` / `"cbps"`.
#' @param B Number of bootstrap replicates (default 500).
#' @export
bootstrap_ci <- function(X, Z, Y, A = NULL, method = "gaussian", bandwidth = NULL,
                          lambda = NULL, three_way = TRUE, L = 1e4, B = 500,
                          alpha = 0.05, estimand = c("late", "ate"), seed = NULL) {
  estimand <- match.arg(estimand)
  if (estimand == "late" && is.null(A)) stop("bootstrap_ci(): `A` is required when estimand = 'late'.")
  if (!is.null(seed)) set.seed(seed)

  n <- length(Z)
  X <- as.matrix(X)
  is_kernel <- method %in% c("gaussian", "laplacian", "t", "matern", "energy")
  if (is.null(lambda)) lambda <- default_lambda(n)

  comps <- if (estimand == "ate") "ate" else c("numerator", "denominator", "late")
  reps <- matrix(NA_real_, B, length(comps), dimnames = list(NULL, comps))

  for (b in seq_len(B)) {
    idx <- sample.int(n, n, replace = TRUE)
    Zb <- Z[idx]; Yb <- Y[idx]; Xb <- X[idx, , drop = FALSE]
    Ab <- if (!is.null(A)) A[idx] else NULL
    if (length(unique(Zb)) < 2) next

    w_b <- tryCatch({
      if (is_kernel) {
        cfd_weights(Z = Zb, X = Xb, density = method, bandwidth = bandwidth,
                    lambda = lambda, three_way = three_way, L = L)$w
      } else if (method == "ipw") {
        ipw_estimate(Zb, Xb)$w
      } else if (method == "cbps") {
        cbps_estimate(Zb, Xb)$w
      } else {
        stop("bootstrap_ci(): unknown method '", method, "'.")
      }
    }, error = function(e) NULL)
    if (is.null(w_b)) next

    est_b <- .point_estimate(Yb, Zb, Ab, w_b, estimand)
    reps[b, ] <- unlist(est_b[comps])
  }

  ci <- apply(reps, 2, stats::quantile, probs = c(alpha / 2, 1 - alpha / 2), na.rm = TRUE)
  list(estimand = estimand, method = method, ci = as.list(as.data.frame(ci)), reps = reps)
}
