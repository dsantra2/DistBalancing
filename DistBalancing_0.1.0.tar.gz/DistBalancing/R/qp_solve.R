#' Numerically robust solver for the CFD balancing quadratic program
#'
#' Solves
#' \deqn{\min_w \; w^\top Q w + q^\top w \quad \text{s.t.} \quad A w = d,\; w \ge 0,}
#' the CFD balancing QP of eq. (17). The original replication code called
#' \code{optiSolve::solvecop()} directly on the raw \code{Q} matrix and never checked
#' whether the solve actually succeeded. That is fragile for exactly the case the
#' paper's own Example 4 introduces: the energy-distance kernel
#' \eqn{k_{\mathrm{ED}}(x,x') = -\|x-x'\|_2} is only *conditionally* negative definite,
#' so \code{Q} can be numerically indefinite before the \eqn{\lambda^2 I} ridge term is
#' added (or when \eqn{\lambda} is tiny), which makes the \code{quadprog} backend
#' underneath \code{optiSolve} fail with "matrix D in quadratic function is not
#' positive definite" -- silently, if the caller does not check the solver status.
#'
#' This function fixes that by (i) symmetrizing \code{Q}, (ii) flooring its smallest
#' eigenvalue so the problem is always numerically positive definite (a standard
#' nearest-PD / Tikhonov-style safeguard, applied only if needed and only by the
#' minimal amount required), (iii) checking the solver's return status rather than
#' trusting it blindly, and (iv) falling back to calling \code{quadprog::solve.QP}
#' directly if \code{optiSolve} still fails.
#'
#' @param Qmat Symmetric quadratic-form matrix (n x n).
#' @param qvec Linear-term vector (length n).
#' @param Amat Equality-constraint matrix (k x n), such that \code{Amat \%*\% w == dvec}.
#' @param dvec Equality-constraint right-hand side (length k).
#' @param lb Lower bound for \code{w} (default 0, i.e. non-negative weights).
#' @param eig_tol Minimum eigenvalue enforced on \code{Qmat} before solving (default
#'   \code{1e-8}).
#' @param quiet Suppress solver messages (default `TRUE`).
#'
#' @return A list with elements `w` (the solution), `status` (`"optimal"` or a
#'   diagnostic string), `solver` (which backend produced the solution), and
#'   `jittered` (`TRUE` if the eigenvalue floor in step (ii) was applied).
#' @export
solve_qp_safe <- function(Qmat, qvec, Amat, dvec, lb = 0, eig_tol = 1e-8, quiet = TRUE) {
  n <- nrow(Qmat)
  stopifnot(ncol(Qmat) == n, length(qvec) == n, ncol(Amat) == n, length(dvec) == nrow(Amat))

  Qmat <- (Qmat + t(Qmat)) / 2  # (i) symmetrize

  jittered <- FALSE
  ev_min <- tryCatch(min(eigen(Qmat, symmetric = TRUE, only.values = TRUE)$values),
                      error = function(e) NA_real_)
  if (is.na(ev_min) || ev_min < eig_tol) {
    bump <- eig_tol - ifelse(is.na(ev_min), 0, ev_min)
    Qmat <- Qmat + diag(bump, n)  # (ii) eigenvalue floor / nearest-PD safeguard
    jittered <- TRUE
  }

  out <- .try_optisolve(Qmat, qvec, Amat, dvec, lb, quiet)
  if (!is.null(out)) {
    return(list(w = out, status = "optimal", solver = "optiSolve::solvecop",
                jittered = jittered))
  }

  out <- .try_quadprog(Qmat, qvec, Amat, dvec, lb)  # (iv) fallback backend
  if (!is.null(out)) {
    return(list(w = out, status = "optimal (fallback solver)", solver = "quadprog::solve.QP",
                jittered = jittered))
  }

  stop("solve_qp_safe(): both optiSolve and the quadprog fallback failed to solve the ",
       "CFD balancing QP. This usually means lambda is too small for the chosen kernel; ",
       "try increasing `lambda` (see Assumption 7 / `default_lambda()`).")
}

.try_optisolve <- function(Qmat, qvec, Amat, dvec, lb, quiet) {
  n <- nrow(Qmat)
  res <- tryCatch({
    mycop <- optiSolve::cop(
      f = optiSolve::quadfun(Qmat, a = as.numeric(qvec), d = 0),
      lb = optiSolve::lbcon(val = rep(lb, n)),
      lc = optiSolve::lincon(A = Amat, dir = rep("==", nrow(Amat)), val = dvec)
    )
    sol <- optiSolve::solvecop(mycop, quiet = quiet)
    sol
  }, error = function(e) NULL, warning = function(w) NULL)

  if (is.null(res) || is.null(res$x) || anyNA(res$x)) return(NULL)
  # (iii) actually check the status instead of trusting the return value blindly
  status_ok <- is.null(res$status) || grepl("optimal|converged|ok", res$status,
                                             ignore.case = TRUE) || is.numeric(res$status)
  if (!status_ok) return(NULL)
  res$x
}

.try_quadprog <- function(Qmat, qvec, Amat, dvec, lb) {
  n <- nrow(Qmat)
  # quadprog::solve.QP minimizes 1/2 w'Dw - d'w  s.t.  t(A) %*% w >= b0 (meq of which are ==)
  Dmat <- Qmat
  dvec_qp <- -qvec
  A_eq <- t(Amat)                       # n x k
  A_ge <- diag(1, n)                    # w >= lb
  Amat_qp <- cbind(A_eq, A_ge)
  bvec_qp <- c(dvec, rep(lb, n))
  meq <- nrow(Amat)
  res <- tryCatch(
    quadprog::solve.QP(Dmat = Dmat, dvec = dvec_qp, Amat = Amat_qp, bvec = bvec_qp, meq = meq),
    error = function(e) NULL
  )
  if (is.null(res)) return(NULL)
  res$solution
}

#' Default regularization rate for the CFD balancing QP
#'
#' Returns \eqn{\lambda = n^{-2}}, which satisfies the \eqn{\lambda = o(n^{-1})} rate
#' required by Assumption 7 for the penalty term \eqn{\lambda^2\|w\|_2^2} to be
#' asymptotically negligible. The original replication code was inconsistent about
#' this: `weights_Final.R` and `401k_Final.R` used \eqn{\lambda = n^{-2}} (correct),
#' but `Simulation_Final.R` used \eqn{\lambda = n^{-1}} inside `sim()`, which does
#' *not* satisfy \eqn{\lambda = o(n^{-1})} (the ratio \eqn{\lambda / n^{-1}} is
#' identically 1, not vanishing). This function/the default in [cfd_weights()] fixes
#' that inconsistency so every estimator in the package uses a lambda rate compatible
#' with both the \eqn{\sqrt n}-consistency conditions (Theorem 4.1) and the
#' \eqn{\lambda = o(n^{-1})} requirement of Assumption 7.
#'
#' @param n Sample size.
#' @export
default_lambda <- function(n) 1 / n^2

#' Check whether a chosen lambda plausibly satisfies Assumption 7 (`lambda = o(n^-1)`)
#'
#' This is a single-\eqn{n} heuristic (the true condition is asymptotic and cannot be
#' verified from one sample size), warning when \eqn{\lambda \ge n^{-1}}, which
#' certifiably violates the required rate.
#' @param lambda Numeric regularization parameter actually used.
#' @param n Sample size.
#' @keywords internal
.check_lambda_rate <- function(lambda, n) {
  if (is.finite(lambda) && lambda >= 1 / n) {
    warning(sprintf(
      "lambda = %.3g does not satisfy lambda = o(n^-1) at n = %d (lambda >= 1/n); ",
      lambda, n), "Assumption 7 (and the sqrt(n)-consistency guarantee of Theorem 4.1) ",
      "may fail. Consider default_lambda(n) = 1/n^2 instead.", call. = FALSE)
  }
  invisible(NULL)
}
