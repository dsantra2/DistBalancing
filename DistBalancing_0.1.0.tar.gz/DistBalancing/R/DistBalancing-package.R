#' DistBalancing: Distributional Balancing for Causal Inference via CFD
#'
#' @description
#' Implements the characteristic function distance (CFD) framework of Santra, Chen,
#' and Park (2026), "Distributional Balancing for Causal Inference: A Unified
#' Framework via Characteristic Function Distance". See the package README and the
#' vignette-style scripts in `system.file("scripts", package = "DistBalancing")` for
#' worked reconstructions of the paper's simulation study and 401(k) data application.
#'
#' @section Coding fixes applied in this package (see the README for full detail):
#' \itemize{
#'   \item \strong{Lambda rate}: [default_lambda()] enforces \eqn{\lambda = n^{-2}}
#'     everywhere, satisfying \eqn{\lambda = o(n^{-1})} (Assumption 7); the original
#'     `Simulation_Final.R` used \eqn{\lambda = n^{-1}} inconsistently with
#'     `weights_Final.R`/`401k_Final.R`.
#'   \item \strong{Energy-distance ("ED") Gram matrix}: [cfd_density()]`("energy")`
#'     implements exactly \eqn{k_{ED}(x,x') = -\|x-x'\|_2} with regression tests
#'     against a brute-force computation.
#'   \item \strong{Subsampling calculation}: [subsample_ci()] rescales every
#'     replicate by \eqn{\sqrt{m/n}} *before* computing both the confidence interval
#'     and the volatility index used to select the subsample size, per Algorithm 1;
#'     the original `choose_best_m_ss()` selected the subsample size from unscaled
#'     bounds.
#'   \item \strong{QP solver}: [solve_qp_safe()] symmetrizes and eigenvalue-floors the
#'     Q matrix, checks the solver's status, and falls back to `quadprog::solve.QP` if
#'     `optiSolve` fails -- needed because the energy-distance kernel yields a
#'     Q matrix that is only conditionally (not globally) positive semi-definite.
#' }
#'
#' @keywords internal
"_PACKAGE"
