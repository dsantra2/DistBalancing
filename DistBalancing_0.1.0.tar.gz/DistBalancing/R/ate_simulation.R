#' Data-generating process for the ATE simulation study (kappa design)
#'
#' Generates a single observational-study sample for evaluating ATE weighting
#' estimators. \code{kappa} controls how far the cross term
#' \eqn{\gamma(X) = (1-e(X))\mu_1(X) + e(X)\mu_0(X)} is from constant: at
#' \code{kappa = 0}, \eqn{\gamma(X) = c} is constant; at \code{kappa = 1},
#' \eqn{\gamma(X) = f(X)} is a genuinely non-constant function of the covariates.
#' Intermediate values interpolate linearly, \eqn{\gamma_\kappa(X) = (1-\kappa)c +
#' \kappa f(X)}, and \eqn{\mu_1} is backed out by solving
#' \eqn{\mu_1(X) = (\gamma_\kappa(X) - e(X)\mu_0(X)) / (1 - e(X))} for a fixed
#' propensity model \eqn{e(X)} and baseline outcome model \eqn{\mu_0(X)}. This lets a
#' simulation study vary, in a controlled way, how much a treatment-effect estimator
#' can rely on \eqn{\gamma(X)} being (nearly) constant -- see `p`, `e_coef`,
#' `mu0_coef`, `f_coef` and `c_const` below to adjust the specific propensity,
#' outcome, and target models used.
#'
#' @param kappa Interpolation parameter in `[0, 1]`.
#' @param n Sample size.
#' @param p Covariate dimension (default 10, matching the paper's other simulations).
#' @param e_coef,mu0_coef,f_coef Coefficient vectors (length `p`) for the propensity,
#'   baseline outcome, and non-constant target models; sensible defaults are used if
#'   `NULL`.
#' @param c_const The constant value of `gamma` at `kappa = 0` (default 1).
#' @param sigma Outcome noise standard deviation (default 1).
#' @return A list with `X`, `A` (treatment), `Y` (observed outcome), `mu1`, `mu0`
#'   (the true, unit-level outcome regressions), and `e` (the true propensity score).
#' @export
dgp_ate <- function(kappa, n, p = 10, e_coef = NULL, mu0_coef = NULL, f_coef = NULL,
                     c_const = 1, sigma = 1) {
  if (kappa < 0 || kappa > 1) stop("dgp_ate(): `kappa` must be in [0, 1].")
  if (is.null(e_coef))   e_coef   <- rep(0.1, p)
  if (is.null(mu0_coef)) mu0_coef <- rep(c(0.5, -0.5), each = p / 2)
  if (is.null(f_coef))   f_coef   <- rep(c(-0.3, 0.3), each = p / 2)

  X <- matrix(stats::rnorm(n * p), nrow = n)
  e <- as.numeric(stats::plogis(X %*% e_coef))
  mu0 <- as.numeric(X %*% mu0_coef)
  fX <- c_const + as.numeric(X %*% f_coef)
  gamma_kappa <- (1 - kappa) * c_const + kappa * fX
  mu1 <- (gamma_kappa - e * mu0) / (1 - e)

  A <- stats::rbinom(n, 1, e)
  Y1 <- mu1 + stats::rnorm(n, sd = sigma)
  Y0 <- mu0 + stats::rnorm(n, sd = sigma)
  Y <- A * Y1 + (1 - A) * Y0

  list(X = X, A = A, Y = Y, mu1 = mu1, mu0 = mu0, e = e)
}

#' Monte Carlo ground-truth ATE for [dgp_ate()]
#'
#' Because \eqn{\mu_1(X)} in [dgp_ate()] is a rational (not closed-form-integrable)
#' function of `X`, the true ATE `E[mu1(X) - mu0(X)]` is computed by a large,
#' noise-free Monte Carlo average (no outcome noise or treatment assignment is
#' needed, since `mu1`/`mu0` are deterministic functions of `X`), rather than a
#' closed form.
#'
#' @inheritParams dgp_ate
#' @param n_mc Monte Carlo sample size (default 2e6).
#' @param seed Optional RNG seed.
#' @return Numeric scalar, the (approximate) true ATE.
#' @export
true_ate <- function(kappa, p = 10, e_coef = NULL, mu0_coef = NULL, f_coef = NULL,
                      c_const = 1, n_mc = 2e6, seed = NULL) {
  if (!is.null(seed)) set.seed(seed)
  d <- dgp_ate(kappa, n = n_mc, p = p, e_coef = e_coef, mu0_coef = mu0_coef,
               f_coef = f_coef, c_const = c_const, sigma = 0)
  mean(d$mu1 - d$mu0)
}

#' Plug-in variance confidence interval for a weighting estimator
#'
#' The raw plug-in variance estimator (44) of the asymptotic-normality write-up:
#' the empirical variance of the weighted-outcome summands. With the normalized
#' coefficients \eqn{\hat\gamma_{z,i} = (n/n_z) w_i} (30), the summands are
#' \deqn{\hat S_i = Z_i\hat\gamma_{1,i}Y_i - (1-Z_i)\hat\gamma_{0,i}Y_i,}
#' whose mean is the weighting estimator \eqn{\hat\tau = \mathbb P_n \hat S} (32), and
#' \deqn{\widehat V_{\rm raw} = \mathbb P_n\{(\hat S - \hat\tau)^2\}, \qquad
#' \widehat{se} = \sqrt{\widehat V_{\rm raw}/n}.}
#' \eqn{\widehat V_{\rm raw}} converges to \eqn{W = V + D \ge V} (Theorem 5), so the
#' Wald interval \eqn{\hat\tau \pm z_{1-\alpha/2}\widehat{se}} is asymptotically
#' conservative, and exact when \eqn{h(X) = \{1-e(X)\}\mu_1(X) + e(X)\mu_0(X) = 0}
#' (Corollary 3). [center_adjusted_plugin_ci()] reduces the gap \eqn{D}.
#'
#' @param Y Outcome vector.
#' @param Z Treatment indicator (0/1).
#' @param w Weights on this package's scale (\eqn{\sum_{Z_i=1} w_i = n_1},
#'   \eqn{\sum_{Z_i=0} w_i = n_0}), e.g. `cfd_weights(...)$w`.
#' @param alpha Confidence level parameter (default 0.05 for a 95\% CI).
#' @return A list with `estimate`, `se`, and `ci` (see [wald_ci()]).
#' @export
plugin_ci <- function(Y, Z, w, alpha = 0.05) {
  S <- .weighted_summands(Y, Z, w)
  wald_ci(mean(S), .plugin_se(S), alpha)
}

#' Center-adjusted plug-in variance confidence interval
#'
#' The center-adjusted plug-in variance of Section 2.3.2 of the asymptotic-normality
#' write-up: the raw plug-in estimator (44) (see [plugin_ci()]) recomputed after
#' replacing \eqn{Y_i} by \eqn{Y_i - \theta} for a single constant \eqn{\theta}.
#' The point estimate is unchanged (by the normalization constraints (31)); the
#' plug-in variance then converges to \eqn{V + D(\theta)} with
#' \eqn{D(\theta) = E[\{h(X)-\theta\}^2 / \{e(X)(1-e(X))\}] \ge 0}, so the interval
#' stays conservative for every \eqn{\theta}. By default \eqn{\theta} is the
#' estimate (56) of the minimizer \eqn{\theta^\star} of \eqn{D(\theta)}, computed
#' from the weights alone:
#' \deqn{\hat\theta^\star = \frac{\mathbb P_n\{Z\hat\gamma_1^2 Y + (1-Z)\hat\gamma_0^2
#' Y\}}{\mathbb P_n\{Z\hat\gamma_1^2 + (1-Z)\hat\gamma_0^2\}},}
#' with \eqn{\hat\gamma_{z,i} = (n/n_z) w_i}. The centered summands are
#' \eqn{\hat S_i(\theta) = Z_i\hat\gamma_{1,i}(Y_i-\theta) -
#' (1-Z_i)\hat\gamma_{0,i}(Y_i-\theta)} and
#' \eqn{\widehat V(\theta) = \mathbb P_n[\{\hat S(\theta) - \mathbb P_n\hat
#' S(\theta)\}^2]}, \eqn{\widehat{se} = \sqrt{\widehat V(\theta)/n}}. No outcome
#' regression is involved.
#'
#' @inheritParams plugin_ci
#' @param theta The centering constant: `NULL` (default) uses \eqn{\hat\theta^\star}
#'   of (56); `"mean"` uses \eqn{\mathbb P_n Y}; or a number.
#' @return A list with `estimate` (identical to [plugin_ci()]'s), `se`, `ci` (see
#'   [wald_ci()]), and the centering constant `theta` used.
#' @export
center_adjusted_plugin_ci <- function(Y, Z, w, alpha = 0.05, theta = NULL) {
  .check_summand_inputs(Y, Z, w)
  gam <- .normalized_coefficients(Z, w)
  if (is.null(theta)) {
    g2 <- ifelse(Z == 1, gam$g1, gam$g0)^2
    theta <- sum(g2 * Y) / sum(g2)
  } else if (identical(theta, "mean")) {
    theta <- mean(Y)
  } else if (!is.numeric(theta) || length(theta) != 1 || !is.finite(theta)) {
    stop("center_adjusted_plugin_ci(): `theta` must be NULL, \"mean\", or a number.")
  }
  est <- mean(.weighted_summands(Y, Z, w))
  S_theta <- .weighted_summands(Y - theta, Z, w)
  out <- wald_ci(est, .plugin_se(S_theta), alpha)
  c(out, list(theta = theta))
}

## Normalized coefficients gamma_{z,i} = (n / n_z) w_i of (30).
.normalized_coefficients <- function(Z, w) {
  n <- length(Z); n1 <- sum(Z == 1); n0 <- sum(Z == 0)
  list(g1 = (n / n1) * w, g0 = (n / n0) * w)
}

## Weighted-outcome summands S_i = Z_i g1_i Y_i - (1 - Z_i) g0_i Y_i of (44).
.weighted_summands <- function(Y, Z, w) {
  .check_summand_inputs(Y, Z, w)
  gam <- .normalized_coefficients(Z, w)
  ifelse(Z == 1, gam$g1 * Y, -gam$g0 * Y)
}

## sqrt(V_hat / n) with V_hat = P_n{(S - P_n S)^2}.
.plugin_se <- function(S) sqrt(mean((S - mean(S))^2) / length(S))

.check_summand_inputs <- function(Y, Z, w) {
  n <- length(Z)
  if (!is.null(dim(w)) || length(w) != n || length(Y) != n) {
    stop("`Y`, `Z` and `w` must be vectors of the same length (note: the ",
         "center-adjusted CI no longer takes a covariate matrix).")
  }
  if (!all(Z %in% c(0, 1)) || sum(Z == 1) == 0 || sum(Z == 0) == 0) {
    stop("`Z` must be a 0/1 vector with both arms non-empty.")
  }
  invisible(NULL)
}
