#' Spectral density / kernel specification for the characteristic function distance
#'
#' Constructs an object describing the spectral density \eqn{\omega} (equivalently,
#' the translation-invariant kernel \eqn{k_\omega}) used to build the characteristic
#' function distance (CFD) of Santra, Chen, and Park (2026), eq. (6)-(7). This is the
#' "density \eqn{\rho}" referenced in the package's design goal of letting the CFD
#' function be specified flexibly: any of the built-in families below can be used, or
#' a fully custom kernel / sampler can be supplied.
#'
#' @param name One of \code{"gaussian"}, \code{"laplacian"} (the \eqn{\ell_1}-Laplacian
#'   / separable Cauchy density of Example 2), \code{"t"} (a Student-t spectral density,
#'   Example 2 with a user-chosen degrees of freedom -- the paper's \code{t5} choice is
#'   \code{df = 5}), \code{"matern"} (isotropic Matern-generating density, Example 3),
#'   \code{"energy"} (the energy-distance "improper density" of Example 4), or
#'   \code{"custom"} for a user-supplied kernel and/or sampler.
#' @param df Degrees of freedom for \code{name = "t"} (default 5, matching the paper).
#' @param nu Smoothness parameter for \code{name = "matern"}; the paper uses
#'   \eqn{s = \nu + d/2} and sets \eqn{s = 7.5} (\eqn{\nu = 2.5}) for its 10-dimensional
#'   simulation and \eqn{s = 4.5} (\eqn{\nu = 2.5}) for its 4-continuous-covariate
#'   401(k) application; the default here is \code{nu = 2.5}.
#' @param kernel_fun Optional custom closed-form kernel: a function
#'   \code{function(D, bandwidth, ...)} of a pairwise-distance matrix returning the
#'   Gram matrix. Required for \code{name = "custom"} unless \code{sampler} is given.
#' @param sampler Optional custom sampler for the Monte Carlo kernel approximation of
#'   eq. (11): a function \code{function(L, d)} returning an \code{L x d} matrix of
#'   i.i.d. draws from a density proportional to \eqn{\omega}. Used when no closed-form
#'   \code{kernel_fun} is available (as for the paper's \code{t5} example) or for a
#'   fully custom \eqn{\omega}.
#' @param distance Which pairwise-distance matrix the closed-form kernel expects:
#'   \code{"euclidean"} or \code{"manhattan"}. Only relevant when \code{kernel_fun} or
#'   a built-in closed form is used.
#' @param symmetric Is \eqn{\omega} symmetric about zero (\eqn{\omega(t) = \omega(-t)})?
#'   If \code{TRUE} (the default, and true of every density in Example 1-4 of the
#'   paper), the Monte Carlo approximation can use the cheaper real-part-only form of
#'   Appendix A.3.
#'
#' @return An object of class \code{"cfd_density"}.
#' @export
cfd_density <- function(name = c("gaussian", "laplacian", "t", "matern", "energy", "custom"),
                         df = 5, nu = 2.5,
                         kernel_fun = NULL, sampler = NULL,
                         distance = c("euclidean", "manhattan"),
                         symmetric = TRUE) {
  name <- match.arg(name)
  distance <- match.arg(distance)

  spec <- switch(
    name,
    gaussian = list(kernel_fun = .k_gaussian, sampler = NULL, distance = "euclidean",
                     needs_bandwidth = TRUE),
    laplacian = list(kernel_fun = .k_laplacian, sampler = NULL, distance = "manhattan",
                      needs_bandwidth = TRUE),
    matern = list(kernel_fun = function(D, bandwidth) .k_matern(D, bandwidth, nu = nu),
                  sampler = NULL, distance = "euclidean", needs_bandwidth = TRUE),
    energy = list(kernel_fun = .k_energy, sampler = NULL, distance = "euclidean",
                  needs_bandwidth = FALSE),
    t = list(kernel_fun = NULL,
             sampler = function(L, d, bandwidth) matrix(stats::rt(L * d, df = df) / bandwidth, L, d),
             distance = "manhattan", needs_bandwidth = TRUE),
    custom = list(kernel_fun = kernel_fun, sampler = sampler, distance = distance,
                  needs_bandwidth = TRUE)
  )

  if (is.null(spec$kernel_fun) && is.null(spec$sampler)) {
    stop("cfd_density(name = \"custom\"): supply at least one of `kernel_fun` or `sampler`.")
  }

  structure(
    list(name = name, df = df, nu = nu,
         kernel_fun = spec$kernel_fun, sampler = spec$sampler,
         distance = spec$distance, needs_bandwidth = spec$needs_bandwidth,
         symmetric = symmetric),
    class = "cfd_density"
  )
}

#' @export
print.cfd_density <- function(x, ...) {
  cat(sprintf("<cfd_density: %s>%s%s\n", x$name,
              if (x$needs_bandwidth) " (bandwidth required)" else "",
              if (is.null(x$kernel_fun)) " [Monte Carlo approximation only]" else ""))
  invisible(x)
}

## ---- Closed-form kernels (Appendix A.2) --------------------------------

.k_gaussian <- function(D, bandwidth) {
  exp(-(D / bandwidth)^2)
}

.k_laplacian <- function(D, bandwidth) {
  exp(-D / bandwidth)
}

#' Matern kernel (isotropic density, Appendix A.2.3)
#'
#' Closed-form Matern kernel with smoothness `nu`. Uses the exact polynomial x
#' exponential forms for the paper's half-integer cases (`nu` in \{0.5, 1.5, 2.5\}) to
#' avoid the 0/0 numerical instability of `besselK()` at `r = 0`, and falls back to
#' the general Bessel-function form (Rasmussen & Williams, 2006, eq. 4.14) otherwise.
#' @keywords internal
.k_matern <- function(D, bandwidth, nu = 2.5) {
  r <- D / bandwidth
  if (isTRUE(all.equal(nu, 0.5))) {
    K <- exp(-r)
  } else if (isTRUE(all.equal(nu, 1.5))) {
    K <- (1 + sqrt(3) * r) * exp(-sqrt(3) * r)
  } else if (isTRUE(all.equal(nu, 2.5))) {
    K <- (1 + sqrt(5) * r + 5 * r^2 / 3) * exp(-sqrt(5) * r)
  } else {
    r_safe <- pmax(r, .Machine$double.eps)
    K <- (2^(1 - nu) / gamma(nu)) * (sqrt(2 * nu) * r_safe)^nu *
      besselK(sqrt(2 * nu) * r_safe, nu)
    diag(K) <- 1
  }
  diag(K) <- 1
  K
}

#' Energy-distance kernel (Example 4 / Appendix, "ED")
#'
#' \eqn{k_{\mathrm{ED}}(x, x') = -\|x - x'\|_2}. This kernel is *conditionally*
#' negative definite rather than positive definite (Bochner's theorem does not apply,
#' since the generating density \eqn{\omega_{ED}(t) \propto \|t\|_2^{-(d+1)}} is not
#' integrable), so the resulting Q matrix in the CFD quadratic program is only
#' positive semi-definite on the constraint set, not positive definite; see
#' [solve_qp_safe()] for how this package makes the QP solve reliably in that case.
#' @keywords internal
.k_energy <- function(D, bandwidth = NULL) {
  -D
}

#' Build a Gram matrix for a `cfd_density`
#'
#' Computes the \eqn{n \times n} Gram matrix \eqn{k_\omega(X_i, X_j)} for the density
#' `density`, using the closed form in eq. (7) when available, and otherwise the
#' Monte Carlo approximation of eq. (11)/Appendix A.3.
#'
#' @param X Numeric matrix of covariates (n x d).
#' @param density A [cfd_density()] object (or a bare character name, coerced via
#'   [cfd_density()]).
#' @param bandwidth Bandwidth `gamma`. If `NULL` and the density needs one, the median
#'   heuristic (Appendix A.7) is used: the median pairwise Euclidean distance for
#'   Gaussian/Matern, or the median pairwise Manhattan distance for Laplacian/t.
#' @param L Number of Monte Carlo draws for the approximation (default \eqn{10^4},
#'   matching the paper).
#' @return A list with elements `K` (the Gram matrix) and `bandwidth` (the bandwidth
#'   actually used).
#' @export
cfd_kernel_gram <- function(X, density = "gaussian", bandwidth = NULL, L = 1e4) {
  if (is.character(density)) density <- cfd_density(density)
  stopifnot(inherits(density, "cfd_density"))
  X <- as.matrix(X)
  d <- ncol(X)

  De <- as.matrix(stats::dist(X, method = "euclidean"))
  Dm <- if (density$distance == "manhattan") as.matrix(stats::dist(X, method = "manhattan")) else NULL
  D <- if (density$distance == "manhattan") Dm else De

  bw <- bandwidth
  if (density$needs_bandwidth && is.null(bw)) {
    bw <- stats::median(D[upper.tri(D)])
    if (!is.finite(bw) || bw <= 0) bw <- 1
  }

  if (!is.null(density$kernel_fun)) {
    K <- density$kernel_fun(D, bw)
  } else {
    K <- mc_kernel_gram(X, density$sampler, L = L, bandwidth = bw, symmetric = density$symmetric)
  }
  list(K = K, bandwidth = bw)
}

#' Monte Carlo kernel approximation (eq. 11 / Appendix A.3)
#'
#' Vectorized Monte Carlo approximation of a translation-invariant kernel using the
#' trigonometric addition-formula identity of Appendix A.3, generalized to an
#' arbitrary sampler so that any spectral density \eqn{\omega} can be used even
#' without a closed form. This is the O(n^2 L) vectorized identity (used, e.g., in the
#' package's `t` density), which is dramatically faster than a naive O(n^2 L)
#' element-by-element loop because it avoids re-looping over rows in R.
#'
#' @param X Numeric matrix (n x d).
#' @param sampler Function `function(L, d, bandwidth)` returning an `L x d` matrix of
#'   draws from a density proportional to `omega`.
#' @param L Number of Monte Carlo draws.
#' @param bandwidth Bandwidth passed through to `sampler`.
#' @param symmetric If `TRUE` (the default), uses the real-part-only simplification
#'   valid when `omega` is symmetric about zero.
#' @export
mc_kernel_gram <- function(X, sampler, L = 1e4, bandwidth = NULL, symmetric = TRUE) {
  X <- as.matrix(X)
  d <- ncol(X)
  Vrandom <- sampler(L, d, bandwidth)
  PX <- Vrandom %*% t(X)                 # L x n
  Cm <- cos(PX)
  Sm <- sin(PX)
  K <- (t(Cm) %*% Cm + t(Sm) %*% Sm) / L  # n x n; exact even when !symmetric,
  K                                       # since cos(a-b)=cos a cos b + sin a sin b always.
}
