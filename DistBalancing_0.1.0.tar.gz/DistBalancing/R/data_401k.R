#' Load and standardize the 401(k) application data (Section 7)
#'
#' Thin wrapper around `DoubleML::fetch_401k()` reproducing the preprocessing used in
#' `401k_Final.R` / `401k_Report.R`: builds a `DoubleMLData` object with the outcome,
#' treatment, instrument, and the paper's nine baseline covariates, then rescales
#' every numeric column to `[0, 1]`.
#'
#' @param features Covariate names to include (default: the paper's nine baseline
#'   covariates).
#' @return A list with elements `data` (the standardized data frame), `Y`, `A`, `Z`,
#'   `X` (a data frame restricted to `features`).
#' @export
load_401k <- function(features = c("age", "inc", "educ", "fsize", "marr", "twoearn",
                                    "db", "pira", "hown")) {
  if (!requireNamespace("DoubleML", quietly = TRUE) ||
      !requireNamespace("mlr3", quietly = TRUE)) {
    stop("load_401k() requires the 'DoubleML' and 'mlr3' packages. Install them with ",
         "install.packages(c(\"DoubleML\", \"mlr3\", \"mlr3learners\", \"data.table\")).")
  }
  raw <- DoubleML::fetch_401k(return_type = "data.table", instrument = TRUE)
  dml <- DoubleML::DoubleMLData$new(raw, y_col = "net_tfa", d_cols = "p401",
                                     x_cols = features, z_cols = "e401")
  data <- as.data.frame(lapply(dml$data, function(x) {
    if (is.numeric(x)) (x - min(x)) / (max(x) - min(x)) else x
  }))
  list(data = data, Y = dml$data$net_tfa, A = dml$data$p401, Z = dml$data$e401,
       X = data[, features, drop = FALSE])
}
