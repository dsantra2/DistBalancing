#' CFD-based distributional balancing weights
#'
#' Computes the characteristic-function-distance (CFD) balancing weights of eq. (13)
#' / (17) (three-way balancing, the paper's default) or eq. (12) (two-way balancing,
#' `three_way = FALSE`). This is the package's central, deliberately flexible entry
#' point: the Gram/kernel matrix can be built automatically from a named or custom
#' [cfd_density()], or the caller can bypass kernel construction entirely and supply
#' the quadratic program's `Q` matrix (and, optionally, its linear term `q`) directly.
#'
#' @param Z Treatment indicator (0/1 vector, length n).
#' @param X Covariate matrix (n x d). Not needed if `K` or `Q` is supplied directly.
#' @param density A [cfd_density()] object, or one of the built-in names
#'   `"gaussian"`, `"laplacian"`, `"t"`, `"matern"`, `"energy"` (default
#'   `"gaussian"`). Ignored if `K` or `Q` is supplied.
#' @param bandwidth Kernel bandwidth; `NULL` uses the median heuristic (Appendix A.7).
#'   Ignored if `K` or `Q` is supplied.
#' @param K Optional precomputed Gram matrix (n x n), e.g. a subset `K_full[idx, idx]`
#'   reused across subsampling/bootstrap replicates, or a kernel not otherwise
#'   supported by [cfd_density()]. If supplied, `X`/`density`/`bandwidth` are ignored.
#' @param Q Optional precomputed QP quadratic-form matrix, bypassing the automatic
#'   construction from `K` entirely. This is the "flexible ... allow users to specify
#'   the Q matrix" hook: supply any valid Q (e.g. from a different discrepancy measure
#'   entirely) and `cfd_weights()` will just solve the resulting QP.
#' @param q Optional linear term paired with a user-supplied `Q` (defaults to a zero
#'   vector if `Q` is supplied but `q` is not).
#' @param lambda Regularization parameter. `NULL` (default) uses
#'   [default_lambda()]\eqn{{}= n^{-2}}, which satisfies the \eqn{\lambda = o(n^{-1})}
#'   rate of Assumption 7. If a numeric value is supplied, it is checked against that
#'   rate (see [default_lambda()] for why the original replication code's
#'   `Simulation_Final.R` violated it).
#' @param three_way If `TRUE` (default), balances the treated group and the control
#'   group each against the full sample *and* against each other (eq. 13/17,
#'   Remark 1 -- the specification used throughout the paper's simulation and data
#'   analysis). If `FALSE`, uses the simpler two-way objective of eq. (12).
#' @param L Number of Monte Carlo draws for kernels without a closed form (default
#'   \eqn{10^4}).
#' @param eig_tol,quiet Passed to [solve_qp_safe()].
#'
#' @return An object of class `"cfd_weights"`: a list with elements `w` (the
#'   estimated weights), `K`, `bandwidth`, `lambda`, `Q`, `q`, `status`, `solver`,
#'   `jittered`, `three_way`.
#' @export
cfd_weights <- function(Z, X = NULL, density = "gaussian", bandwidth = NULL, K = NULL,
                         Q = NULL, q = NULL, lambda = NULL, three_way = TRUE,
                         L = 1e4, eig_tol = 1e-8, quiet = TRUE) {
  Z <- as.numeric(Z)
  n <- length(Z)
  i1 <- as.numeric(Z == 1); i0 <- as.numeric(Z == 0)
  n1 <- sum(i1); n0 <- sum(i0)
  if (n1 == 0 || n0 == 0) stop("cfd_weights(): both treatment groups must be non-empty.")

  if (is.null(lambda)) {
    lambda <- default_lambda(n)
  } else {
    .check_lambda_rate(lambda, n)
  }

  if (is.null(Q)) {
    if (is.null(K)) {
      if (is.null(X)) stop("cfd_weights(): supply `X` (or a precomputed `K` or `Q`).")
      gram <- cfd_kernel_gram(X, density = density, bandwidth = bandwidth, L = L)
      K <- gram$K
      bandwidth <- gram$bandwidth
    }
    D1 <- diag(i1); D0 <- diag(i0); one <- rep(1, n)

    Qb <- (D1 %*% K %*% D1) / n1^2 + (D0 %*% K %*% D0) / n0^2
    if (three_way) Qb <- Qb - (D1 %*% K %*% D0) / (n1 * n0)
    Qb <- Qb + lambda^2 * diag(n)
    qb <- -((D1 %*% K %*% one) / (n1 * n) + (D0 %*% K %*% one) / (n0 * n))
  } else {
    Qb <- Q
    qb <- if (is.null(q)) rep(0, n) else as.numeric(q)
    bandwidth <- NULL
  }

  Amat <- matrix(0, 2, n)
  Amat[1, Z == 1] <- 1
  Amat[2, Z == 0] <- 1
  dvec <- c(n1, n0)

  sol <- solve_qp_safe(Qb, as.numeric(qb), Amat, dvec, lb = 0, eig_tol = eig_tol, quiet = quiet)

  structure(
    list(w = sol$w, K = K, bandwidth = bandwidth, lambda = lambda,
         Q = Qb, q = qb, status = sol$status, solver = sol$solver,
         jittered = sol$jittered, three_way = three_way, n1 = n1, n0 = n0),
    class = "cfd_weights"
  )
}

#' @export
print.cfd_weights <- function(x, ...) {
  cat(sprintf("<cfd_weights: n1=%d, n0=%d, lambda=%.3g, solver=%s%s>\n",
              x$n1, x$n0, x$lambda, x$solver,
              if (isTRUE(x$jittered)) ", eigenvalue-floored" else ""))
  invisible(x)
}

#' Legacy-compatible wrapper matching the original replication code's `distbalance()`
#'
#' A thin wrapper around [cfd_weights()] with the same argument names as the
#' `distbalance()` function in the original (pre-package) `Simulation_Final.R` /
#' `weights_Final.R` scripts, so that ported analysis code needs minimal changes.
#' New code should call [cfd_weights()] directly.
#'
#' @inheritParams cfd_weights
#' @param treatment Alias for `Z`.
#' @param covariate Alias for `X`.
#' @param name Alias for `density`; also accepts the original scripts' kernel names
#'   (`"Gaussian"`, `"Laplacian"`, `"Energy"`, `"Matern"`, `"TCFD"`) case-insensitively.
#' @export
distbalance <- function(treatment, covariate, name = "gaussian", bandwidth = NULL,
                         lambda = NULL, K = NULL) {
  density <- switch(tolower(name),
                     gaussian = "gaussian", laplacian = "laplacian",
                     energy = "energy", matern = "matern",
                     tcfd = "t", t5 = "t", t = "t",
                     tolower(name))
  res <- cfd_weights(Z = treatment, X = covariate, density = density,
                      bandwidth = bandwidth, K = K, lambda = lambda)
  res$w
}
