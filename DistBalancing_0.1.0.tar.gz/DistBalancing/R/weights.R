#' Finite-moment balance term (quadratic-form contribution)
#'
#' Constructs the QP quadratic-form (`Q`), linear (`q`) and constant (`const`)
#' contributions of a finite-dimensional moment-balance term \eqn{m_1(w)^\top Q_m
#' m_1(w) + m_0(w)^\top Q_m m_0(w)} (plus, if `three_way = TRUE`, a third term
#' \eqn{\{m_1(w)-m_0(w)\}^\top Q_m \{m_1(w)-m_0(w)\}}, mirroring the CFD's own
#' arm-vs-arm term), where \eqn{m_z(w) = \frac{1}{n_z}\sum_{i:Z_i=z} w_i
#' \Phi(X_i) - \overline{\Phi(X)}} is the weighted-mean imbalance, in a feature
#' space \eqn{\Phi}, of arm `z` against the full-sample mean \eqn{\overline{\Phi(X)}}.
#' For any `w`, \eqn{w^\top Q w + q^\top w + \mathrm{const}} equals this sum
#' exactly.
#'
#' Equivalently, this is the same pairwise-MMD construction that [cfd_weights()]
#' uses for the distributional term, applied to the finite-rank kernel
#' \eqn{K_\Phi(x, y) = \Phi(x)^\top Q_m \Phi(y)}, since
#' \eqn{(E_\mu\Phi - E_\nu\Phi)^\top Q_m (E_\mu\Phi - E_\nu\Phi)} is the squared
#' MMD under \eqn{K_\Phi}. The returned `Q` is therefore the matrix
#' \eqn{\bar Q_\Phi} that [cfd_weights()] combines with the distributional matrix
#' \eqn{Q_G} (see its `moment_ratio` argument).
#'
#' The moments to balance are user-specified through `features`: by default
#' \eqn{\Phi} is the identity (\eqn{\Phi(X) = X}), so `m_z(w)` is the weighted-mean
#' covariate imbalance; a function such as `function(X) cbind(X, X^2)` also balances
#' second moments, and a precomputed `n x m` matrix of moment functions (evaluated at
#' each unit) can be supplied directly.
#'
#' This construction is a soft, quadratic-penalty analogue of exact moment-balancing
#' methods such as entropy balancing (Hainmueller, 2012) and SBW (Zubizarreta, 2015).
#'
#' @param X Covariate matrix or data frame (n x d). May be `NULL` when `features` is
#'   a precomputed matrix.
#' @param Z Treatment indicator (0/1 vector, length n).
#' @param Qm Optional `m x m` weighting matrix for the moment vector (`m` = number
#'   of features; default: the diagonal matrix of inverse marginal feature variances,
#'   i.e. each moment imbalance is measured in standardized units; pass `diag(m)` for
#'   an unweighted/Euclidean penalty, or any other symmetric positive semi-definite
#'   `m x m` matrix, e.g. an inverse covariance).
#' @param three_way If `TRUE` (default), also include the arm-vs-arm moment term,
#'   matching `cfd_weights()`'s own `three_way` default.
#' @param features The user-specified moments \eqn{\Phi}: either `NULL` (default,
#'   the identity `function(X) X`, so the term targets covariate means), a function
#'   mapping the `n x d` covariate matrix to an `n x m` feature matrix, or a
#'   precomputed numeric `n x m` matrix (or vector, for `m = 1`) whose rows are
#'   \eqn{\Phi(X_i)}.
#' @return A list with `Q` (`n x n`), `q` (length `n`), `const` (scalar), and the
#'   `Qm` actually used.
#' @seealso [cfd_weights()] (`moment_ratio`, `moment_gamma`).
#' @export
moment_balance_gram <- function(X, Z, Qm = NULL, three_way = TRUE, features = NULL) {
  Z <- as.numeric(Z)
  n <- length(Z)
  Phi <- .moment_feature_matrix(X, features, n)
  d <- ncol(Phi)
  i1 <- as.numeric(Z == 1); i0 <- as.numeric(Z == 0)
  n1 <- sum(i1); n0 <- sum(i0)

  if (is.null(Qm)) {
    v <- apply(Phi, 2, stats::var)
    v[!is.finite(v) | v <= 0] <- 1  # guard against a constant column
    Qm <- diag(1 / v, nrow = d, ncol = d)
  }
  Qm <- as.matrix(Qm)
  if (!all(dim(Qm) == c(d, d))) {
    stop(sprintf("moment_balance_gram(): `Qm` must be %d x %d to match the %d moment ",
                 d, d, d), "feature(s).")
  }

  phibar <- colMeans(Phi)
  A1 <- t(Phi * i1) / n1   # m x n : (1/n1) * t(Phi) %*% diag(i1)
  A0 <- t(Phi * i0) / n0

  Q_full <- t(A1) %*% Qm %*% A1 + t(A0) %*% Qm %*% A0
  if (three_way) {
    Ad <- A1 - A0
    Q_full <- Q_full + t(Ad) %*% Qm %*% Ad
  }
  q_full <- as.numeric(-2 * t(A1 + A0) %*% (Qm %*% phibar))
  const <- 2 * as.numeric(t(phibar) %*% Qm %*% phibar)

  list(Q = Q_full, q = q_full, const = const, Qm = Qm)
}

## Resolve the user-specified moments into an n x m numeric matrix.
.moment_feature_matrix <- function(X, features, n) {
  if (is.null(features) || is.function(features)) {
    if (is.null(X)) {
      stop("A covariate matrix `X` is required to evaluate the moment features ",
           "(or supply the moments directly as an n x m matrix).")
    }
    X <- as.matrix(X)
    storage.mode(X) <- "double"
    Phi <- if (is.null(features)) X else features(X)
  } else {
    Phi <- features
  }
  Phi <- as.matrix(Phi)
  storage.mode(Phi) <- "double"
  if (nrow(Phi) != n) {
    stop("The moment features must have one row per unit: got ", nrow(Phi),
         " row(s) for n = ", n, " units (a `features` function must return a matrix ",
         "with the same number of rows as `X`).")
  }
  if (anyNA(Phi)) stop("The moment features contain missing values.")
  Phi
}

## Subset user-specified moments for a resample (only matrices need subsetting;
## functions are re-evaluated on the resampled X).
.subset_moment_features <- function(features, idx) {
  if (is.null(features) || is.function(features)) return(features)
  as.matrix(features)[idx, , drop = FALSE]
}

## Distributional (kernel) term: Q, q and constant of the pairwise-MMD objective.
## Built block-wise (no n x n diagonal-matrix products), and symmetric.
.cfd_kernel_terms <- function(K, Z, three_way) {
  n <- length(Z)
  t1 <- which(Z == 1); t0 <- which(Z == 0)
  n1 <- length(t1); n0 <- length(t0)
  a11 <- 1 / n1^2; a00 <- 1 / n0^2
  if (three_way) { a11 <- 2 * a11; a00 <- 2 * a00 }
  Qg <- matrix(0, n, n)
  Qg[t1, t1] <- K[t1, t1, drop = FALSE] * a11
  Qg[t0, t0] <- K[t0, t0, drop = FALSE] * a00
  if (three_way) {
    a10 <- -1 / (n1 * n0)
    Qg[t1, t0] <- K[t1, t0, drop = FALSE] * a10
    Qg[t0, t1] <- K[t0, t1, drop = FALSE] * a10
  }
  rs <- rowSums(K)
  qg <- numeric(n)
  qg[t1] <- -2 * rs[t1] / (n1 * n)
  qg[t0] <- -2 * rs[t0] / (n0 * n)
  list(Q = Qg, q = qg, const = 2 * sum(K) / n^2)
}

## Hajek-normalized inverse-propensity weights on this package's weight scale
## (sum over treated = n1, sum over controls = n0); used as the reference weights
## of the data-driven lambda_n.
.ipw_reference_weights <- function(Z, X) {
  if (is.null(X)) {
    stop("The data-driven `lambda = \"ipw\"` needs covariates `X` to fit the ",
         "propensity score (or supply `lambda_ref_w`).")
  }
  w <- suppressWarnings(ipw_estimate(Z, X)$w)
  .normalize_arm_weights(w, Z)
}

.normalize_arm_weights <- function(w, Z) {
  w <- as.numeric(w)
  n1 <- sum(Z == 1); n0 <- sum(Z == 0)
  w[Z == 1] <- w[Z == 1] * n1 / sum(w[Z == 1])
  w[Z == 0] <- w[Z == 0] * n0 / sum(w[Z == 0])
  w
}

#' CFD-based distributional balancing weights
#'
#' Computes the characteristic-function-distance (CFD) balancing weights of eq. (13)
#' / (17) (three-way balancing, the paper's default) or eq. (12) (two-way balancing,
#' `three_way = FALSE`), optionally combined with a user-specified finite-moment
#' balance term. The Gram/kernel matrix can be built automatically from a named or
#' custom [cfd_density()], or the caller can bypass kernel construction entirely and
#' supply the quadratic program's `Q` matrix (and, optionally, its linear term `q`)
#' directly.
#'
#' **Distributional term.** Writing \eqn{D_1}/\eqn{D_0} for the diagonal matrices of
#' the treated/control indicators, \eqn{K} for the Gram matrix, \eqn{n_1}/\eqn{n_0}/
#' \eqn{n} for the arm and total sample sizes, and \eqn{\mathbf{1}} for the all-ones
#' vector, the distributional loss is \eqn{L_G(w) = w^\top Q_G w + q_G^\top w + c_G},
#' which equals the sum of pairwise squared MMDs between the treated-arm, control-arm
#' and pooled empirical measures implied by `w` -- treated-vs-pooled plus
#' control-vs-pooled (eq. 12), and also treated-vs-control when `three_way = TRUE`
#' (eq. 13/17):
#' \deqn{Q_G = \begin{cases} \dfrac{D_1 K D_1}{n_1^2} + \dfrac{D_0 K D_0}{n_0^2}, &
#' \texttt{three\_way = FALSE} \\[4pt]
#' 2\left(\dfrac{D_1 K D_1}{n_1^2} + \dfrac{D_0 K D_0}{n_0^2}\right) -
#' \dfrac{D_1 K D_0 + D_0 K D_1}{n_1 n_0}, & \texttt{three\_way = TRUE} \end{cases}}
#' \deqn{q_G = -2\left(\dfrac{D_1 K \mathbf{1}}{n_1 n} + \dfrac{D_0 K \mathbf{1}}{n_0
#' n}\right), \qquad c_G = \frac{2\,\mathbf{1}^\top K \mathbf{1}}{n^2}.}
#'
#' **User-specified moments.** With moments \eqn{\Phi} (`moment_features`) and
#' weighting matrix \eqn{Q_m} (`moment_Q`), [moment_balance_gram()] gives the moment
#' loss \eqn{L_\Phi(w) = w^\top \bar Q_\Phi w + \bar q_\Phi^\top w + \bar c_\Phi}, the
#' same pairwise construction under the finite-rank kernel \eqn{\Phi(x)^\top Q_m
#' \Phi(y)}. The two are combined as
#' \deqn{L(w) = \frac{c_0}{k} L_\Phi(w) + L_G(w), \qquad k =
#' \frac{\|\bar Q_\Phi\|}{\|Q_G\|},}
#' where \eqn{c_0} is `moment_ratio`. Dividing by \eqn{k} puts the moment term
#' on the same scale as the distributional term, so \eqn{c_0} is directly the
#' relative weight of the two (\eqn{c_0 = 1}: equal norms; \eqn{c_0 = 0}: purely
#' distributional). Alternatively, `moment_gamma` sets the absolute weight
#' \eqn{\gamma = c_0/k} directly.
#'
#' **Regularization.** The QP solved is \eqn{\min_w L(w) + r\|w\|_2^2} subject to
#' \eqn{\sum_{i:Z_i=1} w_i = n_1}, \eqn{\sum_{i:Z_i=0} w_i = n_0} and \eqn{w \ge 0}.
#' With a numeric `lambda`, \eqn{r = \lambda^2}. With the data-driven choice
#' `lambda = "ipw"`, the penalty is written \eqn{\lambda_n \|w/n\|_2^2}
#' (\eqn{r = \lambda_n / n^2}), and \eqn{\lambda_n} is chosen so that the penalty
#' is a small, slowly vanishing fraction of the loss at the (Hajek-normalized)
#' inverse-propensity weights \eqn{\hat w_{\rm IPW}}:
#' \deqn{\lambda_n = \frac{n^2 L(\hat w_{\rm IPW})}{\|\hat w_{\rm IPW}\|_2^2}
#' \times c_\lambda\, n^{-a},}
#' with \eqn{c_\lambda} = `lambda_const` (default 0.1) and \eqn{a} = `lambda_decay`
#' (default 0.01), so that \eqn{\lambda_n\|\hat w_{\rm IPW}/n\|_2^2 = c_\lambda
#' n^{-a} L(\hat w_{\rm IPW})}. Since \eqn{L(\hat w_{\rm IPW}) = O_p(n^{-1})} and
#' \eqn{\|\hat w_{\rm IPW}\|_2^2 \asymp n}, the resulting penalty is of order
#' \eqn{n^{-1-a}}, inside the ridge window of the paper for small `a`.
#'
#' @param Z Treatment indicator (0/1 vector, length n).
#' @param X Covariate matrix (n x d). Not needed if `K` or `Q` is supplied directly,
#'   unless moment features must be evaluated from it or `lambda = "ipw"`.
#' @param density A [cfd_density()] object, or one of the built-in names
#'   `"gaussian"`, `"laplacian"`, `"t"`, `"matern"`, `"energy"` (default
#'   `"gaussian"`). Ignored if `K` or `Q` is supplied.
#' @param bandwidth Kernel bandwidth; `NULL` uses the median heuristic (Appendix A.7).
#'   Ignored if `K` or `Q` is supplied.
#' @param K Optional precomputed Gram matrix (n x n), e.g. a subset `K_full[idx, idx]`
#'   reused across subsampling/bootstrap replicates, or a kernel not otherwise
#'   supported by [cfd_density()]. If supplied, `density`/`bandwidth` are ignored.
#' @param Q Optional precomputed QP quadratic-form matrix, used in place of
#'   \eqn{Q_G}: supply any valid `Q` (e.g. built from a different discrepancy
#'   measure) and `cfd_weights()` will solve the resulting QP directly, with no ridge
#'   term added. Because a supplied `Q` is a fixed `n x n` matrix tied to this
#'   specific sample's size and arm composition, it cannot be validly re-derived for a
#'   resample of a different size or composition; [subsample_ci()] and
#'   [bootstrap_ci()] therefore do not accept it (use `K`/`density` there instead,
#'   which they can correctly rebuild per replicate).
#' @param q Optional linear term paired with a user-supplied `Q` (defaults to a zero
#'   vector if `Q` is supplied but `q` is not).
#' @param lambda Regularization. `NULL` (default) uses the fixed rate
#'   [default_lambda()]\eqn{{}= n^{-2}} with penalty \eqn{\lambda^2\|w\|_2^2}; a
#'   numeric value is used the same way (and checked against the
#'   \eqn{\lambda = o(n^{-1})} rate of Assumption 7). `"ipw"` selects the
#'   data-driven \eqn{\lambda_n} described in Details (not available with a
#'   user-supplied `Q`).
#' @param three_way If `TRUE` (default), balances the treated group and the control
#'   group each against the full sample *and* against each other (eq. 13/17,
#'   Remark 1 -- the specification used throughout the paper's simulation and data
#'   analysis). If `FALSE`, uses the simpler two-way objective of eq. (12).
#' @param L Number of Monte Carlo draws for kernels without a closed form (default
#'   \eqn{10^4}).
#' @param moment_ratio The ratio \eqn{c_0 \ge 0} controlling the relative weight of
#'   the user-specified moment term against the distributional term (see Details;
#'   e.g. `0.1`, `1`, `10`). `NULL` (default) means no ratio-scaled moment term.
#'   Cannot be combined with a non-zero `moment_gamma`.
#' @param moment_gamma Absolute weight \eqn{\gamma} on the moment term (default `0`,
#'   off). Prefer `moment_ratio`, whose scale does not depend on the kernel or
#'   sample size.
#' @param moment_Q Optional weighting matrix for the moment term, passed to
#'   [moment_balance_gram()]'s `Qm` (default: inverse marginal variances, sized to
#'   match the moment features).
#' @param moment_features The user-specified moments, passed to
#'   [moment_balance_gram()]'s `features`: `NULL` (default, covariate means), a
#'   function of `X` (e.g. `function(X) cbind(X, X^2)`), or a precomputed `n x m`
#'   matrix of moment functions evaluated at each unit.
#' @param moment_norm Matrix norm used for \eqn{k}, passed to [base::norm()]'s
#'   `type`: `"F"` (Frobenius, default) or `"2"` (spectral; much slower for large n).
#' @param lambda_const,lambda_decay The constants \eqn{c_\lambda} (default 0.1) and
#'   \eqn{a} (default 0.01) of the data-driven \eqn{\lambda_n}; used only when
#'   `lambda = "ipw"`.
#' @param lambda_ref_w Optional reference weight vector replacing
#'   \eqn{\hat w_{\rm IPW}} in the data-driven \eqn{\lambda_n} (it is rescaled
#'   within each arm to sum to \eqn{n_1}/\eqn{n_0}). Used only when
#'   `lambda = "ipw"`.
#' @param eig_tol,quiet Passed to [solve_qp_safe()].
#'
#' @return An object of class `"cfd_weights"`: a list with elements `w` (the
#'   estimated weights), `K`, `bandwidth`, `lambda` (the numeric \eqn{\lambda} or
#'   \eqn{\lambda_n} used), `lambda_method` (`"fixed"` or `"ipw"`), `ridge` (the
#'   coefficient \eqn{r} on \eqn{\|w\|_2^2}), `Q`, `q` (the QP actually solved,
#'   ridge included), `loss_const` (the constant completing \eqn{L(w)}),
#'   `moment_ratio`, `moment_gamma` (the absolute weight \eqn{\gamma} actually
#'   used), `moment_scale` (\eqn{k}), `loss` (\eqn{L(\hat w)}, without the
#'   ridge), `status`, `solver`, `jittered`, `three_way`, `n1`, `n0`.
#' @export
cfd_weights <- function(Z, X = NULL, density = "gaussian", bandwidth = NULL, K = NULL,
                         Q = NULL, q = NULL, lambda = NULL, three_way = TRUE,
                         L = 1e4, moment_ratio = NULL, moment_gamma = 0,
                         moment_Q = NULL, moment_features = NULL, moment_norm = "F",
                         lambda_const = 0.1, lambda_decay = 0.01, lambda_ref_w = NULL,
                         eig_tol = 1e-8, quiet = TRUE) {
  Z <- as.numeric(Z)
  n <- length(Z)
  i1 <- as.numeric(Z == 1); i0 <- as.numeric(Z == 0)
  n1 <- sum(i1); n0 <- sum(i0)
  if (n1 == 0 || n0 == 0) stop("cfd_weights(): both treatment groups must be non-empty.")
  if (!is.null(X)) X <- as.matrix(X)

  ## ---- regularization rule --------------------------------------------------
  if (is.character(lambda)) {
    if (!identical(lambda, "ipw")) {
      stop("cfd_weights(): `lambda` must be NULL, a number, or \"ipw\".")
    }
    lambda_method <- "ipw"
    if (!is.null(Q)) {
      stop("cfd_weights(): the data-driven `lambda = \"ipw\"` needs the loss's ",
           "constant term, which is unknown for a user-supplied `Q`; supply `K` or ",
           "`X`/`density` instead, or a numeric `lambda`.")
    }
  } else {
    lambda_method <- "fixed"
    if (is.null(lambda)) {
      lambda <- default_lambda(n)
    } else {
      .check_lambda_rate(lambda, n)
    }
  }

  ## ---- distributional term: Q_G, q_G, c_G ------------------------------------
  if (is.null(Q)) {
    if (is.null(K)) {
      if (is.null(X)) stop("cfd_weights(): supply `X` (or a precomputed `K` or `Q`).")
      gram <- cfd_kernel_gram(X, density = density, bandwidth = bandwidth, L = L)
      K <- gram$K
      bandwidth <- gram$bandwidth
    }
    G <- .cfd_kernel_terms(K, Z, three_way)
  } else {
    G <- list(Q = Q, q = if (is.null(q)) rep(0, n) else as.numeric(q), const = NA_real_)
    bandwidth <- NULL
  }

  ## ---- user-specified moment term, scaled by c0 / kappa ----------------------
  if (!is.null(moment_ratio)) {
    if (!is.numeric(moment_ratio) || length(moment_ratio) != 1 || moment_ratio < 0) {
      stop("cfd_weights(): `moment_ratio` must be a single non-negative number.")
    }
    if (moment_gamma != 0) {
      stop("cfd_weights(): supply either `moment_ratio` or `moment_gamma`, not both.")
    }
  }
  use_moment <- (!is.null(moment_ratio) && moment_ratio > 0) || moment_gamma != 0
  gamma <- 0
  kappa <- NA_real_
  Qobj <- G$Q; qobj <- G$q; cobj <- G$const
  if (use_moment) {
    mb <- moment_balance_gram(X, Z, Qm = moment_Q, three_way = three_way,
                               features = moment_features)
    if (!is.null(moment_ratio)) {
      normG <- norm(G$Q, type = moment_norm)
      normM <- norm(mb$Q, type = moment_norm)
      if (!is.finite(normM) || normM <= 0 || !is.finite(normG) || normG <= 0) {
        stop("cfd_weights(): cannot scale the moment term -- a zero or non-finite ",
             "matrix norm (are the moment features constant?).")
      }
      kappa <- normM / normG
      gamma <- moment_ratio / kappa
    } else {
      gamma <- moment_gamma
    }
    Qobj <- Qobj + gamma * mb$Q
    qobj <- qobj + gamma * mb$q
    cobj <- cobj + gamma * mb$const
  }
  loss_fn <- function(w) {
    as.numeric(crossprod(w, Qobj %*% w)) + sum(qobj * w) + cobj
  }

  ## ---- ridge coefficient ----------------------------------------------------
  if (lambda_method == "ipw") {
    w_ref <- if (is.null(lambda_ref_w)) .ipw_reference_weights(Z, X) else
      .normalize_arm_weights(lambda_ref_w, Z)
    L_ref <- max(loss_fn(w_ref), 0)
    lambda <- n^2 * L_ref / sum(w_ref^2) * lambda_const * n^(-lambda_decay)
    ridge <- lambda / n^2
  } else {
    ridge <- if (is.null(Q)) lambda^2 else 0
  }
  Qsolve <- Qobj
  if (ridge > 0) diag(Qsolve) <- diag(Qsolve) + ridge

  Amat <- matrix(0, 2, n)
  Amat[1, Z == 1] <- 1
  Amat[2, Z == 0] <- 1
  dvec <- c(n1, n0)

  sol <- solve_qp_safe(Qsolve, as.numeric(qobj), Amat, dvec, lb = 0, eig_tol = eig_tol,
                        quiet = quiet)

  structure(
    list(w = sol$w, K = K, bandwidth = bandwidth, lambda = lambda,
         lambda_method = lambda_method, ridge = ridge,
         Q = Qsolve, q = qobj, loss_const = cobj,
         loss = if (is.finite(cobj)) loss_fn(sol$w) else NA_real_,
         moment_ratio = moment_ratio, moment_gamma = gamma, moment_scale = kappa,
         status = sol$status, solver = sol$solver, jittered = sol$jittered,
         three_way = three_way, n1 = n1, n0 = n0),
    class = "cfd_weights"
  )
}

#' @export
print.cfd_weights <- function(x, ...) {
  cat(sprintf("<cfd_weights: n1=%d, n0=%d, lambda=%.3g (%s), moment gamma=%.3g, solver=%s%s>\n",
              x$n1, x$n0, x$lambda, x$lambda_method, x$moment_gamma, x$solver,
              if (isTRUE(x$jittered)) ", eigenvalue-floored" else ""))
  invisible(x)
}

#' Legacy-compatible alias for `cfd_weights()`
#'
#' A thin wrapper around [cfd_weights()] using the argument names and kernel-name
#' spellings of earlier, script-based versions of this method (e.g. `treatment`/
#' `covariate`/`name` in place of `Z`/`X`/`density`), provided so that analysis code
#' written against that interface needs minimal changes. New code should call
#' [cfd_weights()] directly.
#'
#' @inheritParams cfd_weights
#' @param treatment Alias for `Z`.
#' @param covariate Alias for `X`.
#' @param name Alias for `density`; also accepts `"Gaussian"`, `"Laplacian"`,
#'   `"Energy"`, `"Matern"`, `"TCFD"` case-insensitively.
#' @export
distbalance <- function(treatment, covariate, name = "gaussian", bandwidth = NULL,
                         lambda = NULL, K = NULL) {
  density <- switch(tolower(name),
                     gaussian = "gaussian", laplacian = "laplacian",
                     energy = "energy", matern = "matern",
                     tcfd = "t", t5 = "t", t = "t",
                     tolower(name))
  res <- cfd_weights(Z = treatment, X = covariate, density = density,
                      bandwidth = bandwidth, K = K, lambda = lambda)
  res$w
}
