#!/usr/bin/env Rscript
## ============================================================================
## ATE simulation study, staged. One self-contained cluster/array job: given a
## STAGE and a BATCH index, this script simulates ONE dataset for one
## (N, kernel, kappa, seed) cell and writes one CSV with one row per balancing
## specification fitted to that dataset.
##
##   Rscript 06_ate_simulation_cluster.R <STAGE> <BATCH>
##
## STAGE = "dgp"        (2.1) Check the DGP: N = 1000, no moments (c0 = 0) and
##                      linear moments with c0 = 0.1 fitted to the same dataset,
##                      bootstrap CI only, 200 reps.
##                      If the DB bootstrap coverage is below 0.95, raise N_REPS
##                      to 500 or 1000 and proceed.
##         "moments"    (2.2) Finite-moment adjustment: N = 1000, 2000, 4000;
##                      phi = none (c0 = 0), linear with c0 = 0.5 and c0 = 1;
##                      point estimates only, all three specifications fitted to
##                      the same dataset (a paired comparison).
##         "inference"  (2.3) Inference methods: N = 1000, 2000, 4000; phi = none;
##                      Wald (plug-in variance (44)), center-adjusted Wald (56),
##                      subsampling (SS) and bootstrap CIs.
## Kernels: Gaussian, Laplace, Isotropic (Matern), ED (energy distance). IPW and
## CBPS are comparators in stages "dgp" and "inference" and report the bootstrap
## CI only (the plug-in-based CIs are not valid for them).
##
## BATCH = 1, ..., nrow(Hyperparameter) for that stage; run the script with
## STAGE only (no BATCH) to print the number of jobs:
##   Rscript 06_ate_simulation_cluster.R inference
## Slurm:   sbatch --array=1-<N_JOBS> --wrap="Rscript 06_ate_simulation_cluster.R inference \$SLURM_ARRAY_TASK_ID"
## HTCondor's $(Process) starts at 0, so pass $(Process)+1 as BATCH.
##
## The data come from dgp_design() in sim_design.R (DESIGN = "D2" by default), which
## must be transferred with this script. Afterwards, put the stage's per-job CSVs,
## sim_design.R and SEB_EIF.csv (09_seb_eif.R) in one folder and run
##   Rscript 07_ate_simulation_report.R <STAGE>
##
## ---------------------------------------------------------------------------
## Cost (one core; p = 10). One full-sample DB fit: ~1s (N=1000), ~5s (N=2000),
## ~50s (N=4000).
##   dgp:       ~18 min per DB job (2 specifications x B = 500 bootstrap refits
##              at N = 1000);
##              6 x 200 = 1,200 jobs (IPW/CBPS jobs are fast).
##   moments:   3 fits per job: ~3s (N=1000), ~15s (N=2000), ~2.5 min (N=4000);
##              4 x 3 x 500 = 6,000 jobs.
##   inference: dominated by the bootstrap: ~9 min (N=1000, B=500), ~17 min
##              (N=2000, B=200), ~85 min (N=4000, B=100) per DB job, plus
##              subsampling (~2-3 min at N=1000, where m is searched, ~1 min
##              otherwise); 6 x 3 x 500 = 9,000 jobs. Peak memory ~2 GB at
##              N = 4000 (request 4 GB).
## ============================================================================

suppressMessages(library(DistBalancing))
source("sim_design.R")   # the DGP (DESIGN, dgp_design()); must sit next to this script

## Arguments are cleaned of whitespace and Windows carriage returns ("\r"), which a
## wrapper script saved with Windows (CRLF) line endings would otherwise pass along.
args <- tolower(trimws(gsub("\r", "", commandArgs(trailingOnly = TRUE))))
args <- args[args != ""]
STAGE_NAMES <- c("dgp", "moments", "inference")
if (length(args) < 1 || !(args[1] %in% STAGE_NAMES)) {
  stop("Usage: Rscript 06_ate_simulation_cluster.R <STAGE> <BATCH>, with STAGE one of ",
       paste(STAGE_NAMES, collapse = ", "), " and BATCH >= 1. Received arguments: ",
       if (length(args)) paste0("'", args, "'", collapse = " ") else "(none)", call. = FALSE)
}
STAGE <- args[1]

## ---- common settings -----------------------------------------------------------
KAPPA        <- 1                      # kappa design parameter (see sim_design.R)
P            <- 10                     # covariate dimension
LAMBDA_CONST <- 0.1                    # data-driven lambda_n (cfd_weights(lambda = "ipw"))
LAMBDA_DECAY <- 0.01
PHI_FUNS     <- list(none = NULL, linear = function(X) X,
                     quadratic = function(X) cbind(X, X^2))
DB_KERNELS   <- c("Gaussian", "Laplace", "Isotropic", "ED")

B_BOOT_BY_N    <- c(`500` = 500, `1000` = 500, `2000` = 200, `4000` = 100)
B_SS           <- 500   # final subsampling replicates
M_SEARCH_MAX_N <- 1000  # choose m by moonboot::estimate.m() for N <= this;
                         # fix m = round(2*sqrt(N)) above it
M_SEARCH_R     <- 50    # search replicates per candidate m

spec <- function(phi, c0) list(phi = phi, c0 = c0)

## ---- stage definitions ----------------------------------------------------------
STAGES <- list(
  dgp = list(
    N_GRID = 1000, KERNEL_GRID = c(DB_KERNELS, "IPW", "CBPS"), N_REPS = 200,
    SPECS = list(spec("none", 0), spec("linear", 0.1)), METHODS = "Boot"),
  moments = list(
    N_GRID = c(1000, 2000, 4000), KERNEL_GRID = DB_KERNELS, N_REPS = 500,
    SPECS = list(spec("none", 0), spec("linear", 0.5), spec("linear", 1)),
    METHODS = character(0)),
  inference = list(
    N_GRID = c(1000, 2000, 4000), KERNEL_GRID = c(DB_KERNELS, "IPW", "CBPS"),
    N_REPS = 500, SPECS = list(spec("none", 0)),
    METHODS = c("Wald", "CAdj", "SS", "Boot"))
)
cfg <- STAGES[[STAGE]]

Hyperparameter <- expand.grid(kernel = cfg$KERNEL_GRID, N = cfg$N_GRID,
                               SEED = seq_len(cfg$N_REPS), stringsAsFactors = FALSE)
if (length(args) < 2) {
  cat(sprintf("Stage '%s': %d jobs (BATCH = 1..%d)\n", STAGE, nrow(Hyperparameter),
              nrow(Hyperparameter)))
  quit(save = "no")
}
BATCH <- as.integer(args[2])
if (is.na(BATCH) || BATCH < 1 || BATCH > nrow(Hyperparameter)) {
  stop("BATCH must be between 1 and ", nrow(Hyperparameter), " for stage '", STAGE, "'")
}

kernel_label <- Hyperparameter[BATCH, "kernel"]
N            <- Hyperparameter[BATCH, "N"]
SEED         <- Hyperparameter[BATCH, "SEED"]
density_name <- switch(kernel_label, Gaussian = "gaussian", Laplace = "laplacian",
                        Isotropic = "matern", ED = "energy", NA_character_)
is_kernel <- !is.na(density_name)

time_it <- function(expr) {
  t0 <- proc.time()[["elapsed"]]
  val <- expr
  list(value = val, seconds = proc.time()[["elapsed"]] - t0)
}
ci_cols <- function(prefix, ci = c(NA_real_, NA_real_), se = NA_real_, time = NA_real_) {
  setNames(data.frame(ci[1], ci[2], se, time),
           paste0(prefix, c(".Lower", ".Upper", ".SE", ".Time")))
}
safely <- function(label, expr) tryCatch(expr, error = function(e) {
  message(label, " failed: ", conditionMessage(e)); NULL })

## ---- simulate one dataset (identical across stages for the same N and SEED) ----
set.seed(SEED)
d <- dgp_design(N, DESIGN_ROW, p = P, kappa = KAPPA)

## ---- fit and infer ----------------------------------------------------------------
specs <- if (is_kernel) cfg$SPECS else list(spec(NA_character_, NA_real_))
K <- if (is_kernel) cfd_kernel_gram(d$X, density = density_name)$K else NULL
B_boot <- B_BOOT_BY_N[[as.character(N)]]

rows <- lapply(specs, function(s) {
  feats <- if (is_kernel) PHI_FUNS[[s$phi]] else NULL

  ## point estimate
  fit <- time_it(
    if (is_kernel) {
      cfd_weights(Z = d$A, X = d$X, K = K, lambda = "ipw", moment_ratio = s$c0,
                  moment_features = feats, lambda_const = LAMBDA_CONST,
                  lambda_decay = LAMBDA_DECAY)
    } else if (kernel_label == "IPW") ipw_estimate(d$A, d$X) else cbps_estimate(d$A, d$X))
  w <- fit$value$w
  row <- data.frame(
    stage = STAGE, design = DESIGN, kernel = kernel_label, phi = s$phi, c0 = s$c0, kappa = KAPPA,
    N = N, SEED = SEED, point_est = ate_weighting_estimate(d$Y, d$A, w),
    Fit.Time = fit$seconds,
    lambda_n = if (is_kernel) fit$value$lambda else NA_real_,
    moment_k = if (is_kernel) fit$value$moment_scale else NA_real_)

  ## Wald CI with the raw plug-in variance (44) -- DB methods only
  if ("Wald" %in% cfg$METHODS) {
    r <- if (is_kernel) time_it(plugin_ci(d$Y, d$A, w)) else NULL
    row <- cbind(row, if (is.null(r)) ci_cols("Wald") else
      ci_cols("Wald", r$value$ci, r$value$se, r$seconds))
  }
  ## Center-adjusted Wald CI, constant centering (56) -- DB methods only
  if ("CAdj" %in% cfg$METHODS) {
    r <- if (is_kernel) time_it(center_adjusted_plugin_ci(d$Y, d$A, w)) else NULL
    row <- cbind(row, if (is.null(r)) ci_cols("CAdj") else
      ci_cols("CAdj", r$value$ci, r$value$se, r$seconds))
  }
  ## Subsampling CI -- DB methods only; same specification on every subsample
  if ("SS" %in% cfg$METHODS) {
    r <- NULL
    if (is_kernel) {
      m_fixed <- if (N <= M_SEARCH_MAX_N) NULL else round(2 * sqrt(N))
      r <- time_it(safely("subsample_ci", subsample_ci(
        d$X, d$A, d$Y, K = K, lambda = "ipw", moment_ratio = s$c0,
        moment_features = feats, lambda_const = LAMBDA_CONST, lambda_decay = LAMBDA_DECAY,
        full_w = w, B = B_SS, m = m_fixed, m_R = M_SEARCH_R, estimand = "ate",
        seed = SEED)))
    }
    ok <- !is.null(r) && !is.null(r$value)
    row <- cbind(row, if (!ok) ci_cols("SS") else
      ci_cols("SS", unname(r$value$ci$ate), unname(r$value$se[["ate"]]), r$seconds),
      SS.m = if (ok) r$value$best_m$ate else NA_real_)
  }
  ## Percentile bootstrap CI -- all methods; the whole estimator is refit
  if ("Boot" %in% cfg$METHODS) {
    r <- time_it(safely("bootstrap_ci",
      if (is_kernel) {
        bootstrap_ci(d$X, d$A, d$Y, method = density_name, lambda = "ipw",
                     moment_ratio = s$c0, moment_features = feats,
                     lambda_const = LAMBDA_CONST, lambda_decay = LAMBDA_DECAY,
                     B = B_boot, estimand = "ate", seed = SEED, full_w = w)
      } else {
        bootstrap_ci(d$X, d$A, d$Y, method = tolower(kernel_label), B = B_boot,
                     estimand = "ate", seed = SEED, full_w = w)
      }))
    ok <- !is.null(r$value)
    reps <- if (ok) r$value$reps[, "ate"] else NA_real_
    row <- cbind(row, if (!ok) ci_cols("Boot") else
      ci_cols("Boot", unname(unlist(r$value$ci$ate)), stats::sd(reps, na.rm = TRUE),
              r$seconds),
      Boot.B = if (ok) sum(!is.na(reps)) else NA_real_)
  }
  row
})

RESULT <- do.call(rbind, rows)
write.csv(RESULT,
          file = sprintf("Result_%s_%s_%s_kappa%.1f_N%05d_SEED%05d.csv",
                          STAGE, DESIGN, kernel_label, KAPPA, N, SEED),
          row.names = FALSE)
