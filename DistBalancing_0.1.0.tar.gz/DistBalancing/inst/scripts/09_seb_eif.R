#!/usr/bin/env Rscript
## ============================================================================
## SEB: the semiparametric efficiency bound, as a standard error.
##
## The efficient influence function (EIF) of the ATE (eq. 42 of the
## asymptotic-normality write-up) is
##
##   IF(Y, Z, X) = (2Z - 1) {Y - mu_Z(X)} / [Z e(X) + (1 - Z){1 - e(X)}]
##                 + mu_1(X) - mu_0(X) - tau,
##
## and V = E[IF^2] is the asymptotic variance of sqrt(n)(tau_hat - tau) for the DB
## estimator (eq. 43). This script draws N_MC observations from the simulation
## DGP (dgp_design() in sim_design.R, for the selected DESIGN), with outcome noise
## and treatment assignment, evaluates IF at each (using the true e, mu_0, mu_1),
## and records its empirical SD. The SEB
## reported for sample size n is then
##
##   SEB(n) = sd(IF) / sqrt(n),
##
## identical for every method in a row of the simulation table. It is checked
## against the closed form V = E[sigma^2/e(X) + sigma^2/(1 - e(X))] +
## Var{mu_1(X) - mu_0(X)}, also reported. The Monte Carlo mean of mu_1 - mu_0 is
## the true ATE used by the report script.
##
##   Rscript 09_seb_eif.R            # writes SEB_EIF.csv (read by the report script)
##
## Needs sim_design.R in the same folder; base R only.
##
## N_MC = 1e8 is processed in chunks of CHUNK draws, accumulating the mean and
## the sum of squared deviations with the exact pairwise update, so memory stays
## small (~1 GB for CHUNK = 1e6 with p = 10). Runtime: a few minutes.
## ============================================================================

source("sim_design.R")

N_MC       <- 1e8
CHUNK      <- 1e6
KAPPA_GRID <- c(1)
N_SIZES    <- c(500, 1000, 2000, 4000)
SEED       <- 20260926

## Exact pooled mean / sum of squared deviations (Chan, Golub and LeVeque).
combine <- function(acc, x) {
  n_b <- length(x); m_b <- mean(x); ss_b <- sum((x - m_b)^2)
  if (acc$n == 0) return(list(n = n_b, mean = m_b, ss = ss_b))
  n <- acc$n + n_b; delta <- m_b - acc$mean
  list(n = n, mean = acc$mean + delta * n_b / n,
       ss = acc$ss + ss_b + delta^2 * acc$n * n_b / n)
}

out <- list()
for (kappa in KAPPA_GRID) {
  set.seed(SEED)
  n_chunks <- ceiling(N_MC / CHUNK)
  acc_if <- list(n = 0, mean = 0, ss = 0)     # IF without the -tau term
  acc_tx <- list(n = 0, mean = 0, ss = 0)     # tau(X) = mu_1(X) - mu_0(X)
  sum_inv <- 0                                 # sum of 1/e + 1/(1-e)
  t0 <- proc.time()[["elapsed"]]
  for (b in seq_len(n_chunks)) {
    m <- min(CHUNK, N_MC - (b - 1) * CHUNK)
    d <- dgp_design(m, DESIGN_ROW, p = 10, kappa = kappa)   # includes noise, treatment
    Z <- d$A
    muZ <- ifelse(Z == 1, d$mu1, d$mu0)
    pZ  <- ifelse(Z == 1, d$e, 1 - d$e)
    tau_x <- d$mu1 - d$mu0
    if_raw <- (2 * Z - 1) * (d$Y - muZ) / pZ + tau_x   # = IF + tau
    acc_if <- combine(acc_if, if_raw)
    acc_tx <- combine(acc_tx, tau_x)
    sum_inv <- sum_inv + sum(DESIGN_ROW$sigma^2 * (1 / d$e + 1 / (1 - d$e)))
    rm(d, Z, muZ, pZ, tau_x, if_raw)
  }
  sd_if <- sqrt(acc_if$ss / (acc_if$n - 1))
  V_closed <- sum_inv / acc_tx$n + acc_tx$ss / (acc_tx$n - 1)
  message(sprintf("design %s, kappa = %.1f: tau = %.5f, sd(IF) = %.5f, closed-form sqrt(V) = %.5f (%.0fs)",
                  DESIGN, kappa, acc_if$mean, sd_if, sqrt(V_closed),
                  proc.time()[["elapsed"]] - t0))
  ## Design H has a known ATE of exactly 0 (E C(X) = 0); use it instead of the MC mean.
  tau_out <- if (DESIGN_ROW$family == "haoran") 0 else acc_if$mean
  out[[length(out) + 1]] <- data.frame(
    design = DESIGN, kappa = kappa, N_MC = acc_if$n, tau = tau_out, tau_mc = acc_if$mean,
    sd_eif = sd_if,
    V = sd_if^2, sd_eif_closed_form = sqrt(V_closed),
    n = N_SIZES, SEB = sd_if / sqrt(N_SIZES), SEB_x100 = 100 * sd_if / sqrt(N_SIZES)
  )
}

res <- do.call(rbind, out)
write.csv(res, "SEB_EIF.csv", row.names = FALSE)
print(res, digits = 5)
