#!/usr/bin/env Rscript
## Reconstruction of DataAnalysis/401k_Final.R using DistBalancing functions. Each
## job draws one resample (bootstrap if resample.N == N, else a without-replacement
## subsample) of the 401(k) data, computes the weighting estimator, and writes one
## row of output -- exactly the original script's one-resample-per-HTCondor-job
## design, so aggregation and subsample-size selection happen afterwards, in
## 05_401k_report.R.
##
##   Rscript 04_401k_final.R <BATCH>

suppressMessages(library(DistBalancing))

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1) stop("Usage: Rscript 04_401k_final.R <BATCH>")
BATCH <- as.numeric(args[1])

d401k <- load_401k()
Y_full <- d401k$Y; A_full <- d401k$A; Z_full <- d401k$Z; X_full <- as.matrix(d401k$X)
N <- length(Y_full)

range.ss <- c(sqrt(N), 3 * sqrt(N))
grid.ss <- unique(round(seq(range.ss[1], range.ss[2], length.out = 20)))

Hyperparameter <- expand.grid(
  kernel = c("gaussian", "laplacian", "energy", "t", "matern", "IPW", "CBPS"),
  resample.N = c(grid.ss, N),
  SEED = 1:750
)
Hyperparameter$inference <- ifelse(Hyperparameter$resample.N == N, "Boot", "SS")
Hyperparameter <- Hyperparameter[!(Hyperparameter$kernel %in% c("IPW", "CBPS") &
                                      Hyperparameter$inference == "SS"), ]

kernel        <- as.character(Hyperparameter[BATCH, "kernel"])
inference     <- as.character(Hyperparameter[BATCH, "inference"])
Subsamplesize <- Hyperparameter[BATCH, "resample.N"]
SEED          <- Hyperparameter[BATCH, "SEED"]
set.seed(SEED)

idx <- if (inference == "Boot") sample.int(N, N, replace = TRUE) else sample.int(N, Subsamplesize, replace = FALSE)
Y <- Y_full[idx]; A <- A_full[idx]; Z <- Z_full[idx]; X <- X_full[idx, , drop = FALSE]
m <- length(idx)

is_kernel <- kernel %in% c("gaussian", "laplacian", "energy", "t", "matern")

w <- if (is_kernel) {
  cfd_weights(Z = Z, X = X, density = kernel, lambda = default_lambda(N))$w
} else if (kernel == "IPW") {
  ipw_estimate(Z, X)$w
} else {
  cbps_estimate(Z, X)$w
}

est <- late_weighting_estimate(Y, A, Z, w)

RESULT <- data.frame(kernel = kernel, m = m, SEED = SEED, Inference = inference,
                      num = est$numerator, denom = est$denominator, late = est$late)

write.csv(RESULT,
          file = sprintf("Result_401k_%s_N%05d_%s_SEED%05d.csv", kernel, m, inference, SEED),
          row.names = FALSE)
