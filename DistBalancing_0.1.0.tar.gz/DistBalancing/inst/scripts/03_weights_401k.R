#!/usr/bin/env Rscript
## Reconstruction of DataAnalysis/weights_Final.R using DistBalancing::cfd_weights().
## Computes the CFD balancing weights for one kernel against the full 401(k) dataset.
##
##   Rscript 03_weights_401k.R <BATCH>

suppressMessages(library(DistBalancing))

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1) stop("Usage: Rscript 03_weights_401k.R <BATCH>")
BATCH <- as.numeric(args[1])
set.seed(BATCH)

Hyperparameter <- expand.grid(kernel = c("gaussian", "laplacian", "energy", "t", "matern"))
kernel <- as.character(Hyperparameter[BATCH, "kernel"])

d401k <- load_401k()
N <- nrow(d401k$X)

res <- cfd_weights(Z = d401k$Z, X = as.matrix(d401k$X), density = kernel,
                    lambda = default_lambda(N))

write.csv(res$w, file = sprintf("weights_%s.csv", kernel), row.names = FALSE)
