#!/usr/bin/env Rscript
## Reconstruction of Simulation/Simulation_Report.R: aggregates the per-job CSVs
## produced by 01_simulation_final.R (concatenated into Result_merge.csv, as in the
## original) into Bias / SE / MSE / Coverage / Length summary tables.
##
## Note on rescaling: because subsample_ci() (see 01_simulation_final.R) already
## performs the sqrt(m/n) rescaling internally per Algorithm 1, the CI bounds
## written to each result CSV are already on the full-sample scale. This script
## therefore does *not* re-apply a sqrt(m/N) correction to the Lower/Upper columns,
## unlike the original Simulation_Report.R -- which had to, because the original
## choose_best_m_ss() left the CI endpoints unscaled.

suppressMessages({
  library(dplyr)
})

Denom_Linear <- 0.3126122; Numer_Linear <- 0.3127464; LATE_Linear <- 1.000429
Denom_nonLinear <- 0.31246; Numer_nonLinear <- 0.3124363; LATE_nonLinear <- 0.9999239

results <- read.csv("Result_merge.csv", header = TRUE)

summarize_effect <- function(results, dgp_type, est_col, lower_col, upper_col, true_val) {
  results %>%
    filter(DGP.type == dgp_type) %>%
    group_by(kernel, N, Inference) %>%
    summarise(
      Bias = 100 * mean(.data[[est_col]] - true_val),
      SE = 100 * sd(.data[[est_col]]),
      MSE = Bias^2 + SE^2,
      Coverage = mean(true_val >= .data[[lower_col]] & true_val <= .data[[upper_col]]),
      length = mean(.data[[upper_col]] - .data[[lower_col]]),
      .groups = "drop"
    )
}

num1   <- summarize_effect(results, 1, "num",   "Lower.num",   "Upper.num",   Numer_Linear)
denom1 <- summarize_effect(results, 1, "denom", "Lower.denom", "Upper.denom", Denom_Linear)
late1  <- summarize_effect(results, 1, "late",  "Lower.late",  "Upper.late",  LATE_Linear)

num2   <- summarize_effect(results, 2, "num",   "Lower.num",   "Upper.num",   Numer_nonLinear)
denom2 <- summarize_effect(results, 2, "denom", "Lower.denom", "Upper.denom", Denom_nonLinear)
late2  <- summarize_effect(results, 2, "late",  "Lower.late",  "Upper.late",  LATE_nonLinear)
