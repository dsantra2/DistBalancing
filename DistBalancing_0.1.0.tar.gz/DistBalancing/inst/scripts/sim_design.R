## ============================================================================
## sim_design.R -- the data-generating process shared by
##   06_ate_simulation_cluster.R (the simulation jobs) and
##   09_seb_eif.R               (true ATE and SEB),
## so that jobs, truth and SEB always use exactly the same DGP.
##
## Select the design with DESIGN below.
##
## "H": the DGP of Zhang, Chen and Park (2026), "Sliced L^p distributional
##   balancing", Section 5.1 (arXiv:2609.09600):
##     X ~ Uniform[0, 1]^10,  C(X) = (X3 - 0.5)^2 - (X4 - 0.5)^2,
##     e(X)  = expit(0.2 - 0.3 X1 + 0.3 X2 + 6 C(X) + 0.05 sum_{j=5}^{10} (Xj - 0.5)),
##     mu0(X) = 0.4 X1 + 0.4 X2 + 0.2 sum_{j=5}^{10} Xj,   mu1(X) = mu0(X) + 1.5 C(X),
##     Y(a) = mu_a(X) + eps_a, eps_0, eps_1 iid N(0, 1).   True ATE = 0.
##   Nonlinear (quadratic) confounding through C(X); e(X) lies in about [0.15, 0.90].
##
## "D0"-"D5": dgp_ate()'s kappa design (from the DGP pilot) with
##   e(X) = e_lo + (e_hi - e_lo) * plogis(X' rep(e_scale, p)), X ~ N(0, I_p),
##   mu0(X) = X' rep(c(mu0, -mu0), each = p/2), noise SD sigma, and
##   mu1 = (gamma_kappa - e mu0) / (1 - e) as in dgp_ate():
##   D0  dgp_ate() itself: coefficients 0.1, no cap, mu0 +-0.5, sigma 1
##   D1  coefficients 0.3, e(X) capped into [0.05, 0.95]
##   D2  coefficients 0.4, e(X) capped into [0.05, 0.95]
##   D3  D2 with mu0 +-0.2;  D4  D2 with sigma = 3;  D5  D2 with mu0 +-0.2, sigma = 3
## Base R only.
## ============================================================================

DESIGN <- "H"

SIM_DESIGNS <- data.frame(
  design  = c("H",      "D0",    "D1",    "D2",    "D3",    "D4",    "D5"),
  family  = c("haoran", "kappa", "kappa", "kappa", "kappa", "kappa", "kappa"),
  e_scale = c(NA,       0.1,     0.3,     0.4,     0.4,     0.4,     0.4),
  e_lo    = c(NA,       0,       0.05,    0.05,    0.05,    0.05,    0.05),
  e_hi    = c(NA,       1,       0.95,    0.95,    0.95,    0.95,    0.95),
  mu0     = c(NA,       0.5,     0.5,     0.5,     0.2,     0.5,     0.2),
  sigma   = c(1,        1,       1,       1,       1,       3,       3),
  stringsAsFactors = FALSE
)
DESIGN_ROW <- SIM_DESIGNS[SIM_DESIGNS$design == DESIGN, ]
if (nrow(DESIGN_ROW) != 1) stop("sim_design.R: unknown DESIGN '", DESIGN, "'")

## Simulate one dataset from design `des`; returns X, A, Y and the true e, mu0, mu1.
## `p`, `kappa` and `c_const` apply to the kappa family only (design H has p = 10).
dgp_design <- function(n, des = DESIGN_ROW, p = 10, kappa = 1, c_const = 1) {
  if (des$family == "haoran") return(dgp_haoran(n, sigma = des$sigma))
  ## kappa family: same random-number order as dgp_ate(); D0 reproduces it
  X <- matrix(stats::rnorm(n * p), nrow = n)
  e <- des$e_lo + (des$e_hi - des$e_lo) *
    as.numeric(stats::plogis(X %*% rep(des$e_scale, p)))
  mu0 <- as.numeric(X %*% rep(c(des$mu0, -des$mu0), each = p / 2))
  fX <- c_const + as.numeric(X %*% rep(c(-0.3, 0.3), each = p / 2))
  gamma_kappa <- (1 - kappa) * c_const + kappa * fX
  mu1 <- (gamma_kappa - e * mu0) / (1 - e)
  A <- stats::rbinom(n, 1, e)
  Y1 <- mu1 + stats::rnorm(n, sd = des$sigma)
  Y0 <- mu0 + stats::rnorm(n, sd = des$sigma)
  list(X = X, A = A, Y = A * Y1 + (1 - A) * Y0, mu1 = mu1, mu0 = mu0, e = e)
}

## Design H: Zhang, Chen and Park (2026), Section 5.1.
dgp_haoran <- function(n, sigma = 1) {
  X <- matrix(stats::runif(n * 10), nrow = n)
  C <- (X[, 3] - 0.5)^2 - (X[, 4] - 0.5)^2
  e <- stats::plogis(0.2 - 0.3 * X[, 1] + 0.3 * X[, 2] + 6 * C +
                       0.05 * rowSums(X[, 5:10] - 0.5))
  mu0 <- 0.4 * X[, 1] + 0.4 * X[, 2] + 0.2 * rowSums(X[, 5:10])
  mu1 <- mu0 + 1.5 * C
  A <- stats::rbinom(n, 1, e)
  Y1 <- mu1 + stats::rnorm(n, sd = sigma)
  Y0 <- mu0 + stats::rnorm(n, sd = sigma)
  list(X = X, A = A, Y = A * Y1 + (1 - A) * Y0, mu1 = mu1, mu0 = mu0, e = e)
}
