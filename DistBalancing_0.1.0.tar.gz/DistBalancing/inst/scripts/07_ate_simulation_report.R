#!/usr/bin/env Rscript
## ============================================================================
## Summary tables for the staged ATE simulation (06_ate_simulation_cluster.R).
##
##   Rscript 07_ate_simulation_report.R <STAGE>      # dgp | moments | inference
##
## Reads Result_<STAGE>_combined.csv (the concatenated per-job CSVs of that stage)
## and SEB_EIF.csv (from 09_seb_eif.R), and writes
##   ATE_<STAGE>_summary.csv   all numbers
##   ATE_<STAGE>_table.tex     LaTeX table (booktabs + multirow)
##
## Columns:
##   Bias  = 100 * mean(point_est - tau)
##   ESE   = 100 * sd(point_est)                    (empirical SE across replicates)
##   SEB   = 100 * sd(EIF) / sqrt(n)                (efficiency bound: the SD of the
##           efficient influence function from 1e8 draws, 09_seb_eif.R, rescaled to
##           the sample size; the same for every method in a row)
##   RMSE  = 100 * sqrt(mean((point_est - tau)^2)); Rel. = RMSE / RMSE of phi = none
##           for the same kernel and N (paired: same datasets)       [moments stage]
##   Length / Cov. / Time = mean length, empirical coverage of tau, and mean time
##           (seconds) of each 95% CI:
##     Wald   = estimate +/- 1.96 * sqrt(V_raw / n), raw plug-in variance (44)
##     C-adj. Wald = the same with the constant centering (56)
##     SS     = subsampling CI (subsample_ci())
##     Boot   = percentile bootstrap CI (bootstrap_ci())
##   IPW and CBPS report the bootstrap CI only.
## tau is the Monte Carlo mean from SEB_EIF.csv (1e8 draws) when available,
## otherwise true_ate(kappa).
## ============================================================================

suppressMessages({
  library(dplyr)
})

args <- tolower(trimws(gsub("\r", "", commandArgs(trailingOnly = TRUE))))
args <- args[args != ""]
if (length(args) < 1 || !(args[1] %in% c("dgp", "moments", "inference"))) {
  stop("Usage: Rscript 07_ate_simulation_report.R <STAGE>, with STAGE one of dgp, ",
       "moments, inference. Received: ",
       if (length(args)) paste0("'", args, "'", collapse = " ") else "(none)", call. = FALSE)
}
STAGE <- args[1]

## Per-job CSVs of the stage are read directly (Result_<STAGE>_combined.csv is used
## instead if present).
combined_file <- sprintf("Result_%s_combined.csv", STAGE)
if (file.exists(combined_file)) {
  results <- read.csv(combined_file, stringsAsFactors = FALSE)
} else {
  files <- setdiff(list.files(pattern = sprintf("^Result_%s_.*\\.csv$", STAGE)), combined_file)
  if (!length(files)) stop("No Result_", STAGE, "_*.csv files in ", getwd(), call. = FALSE)
  parts <- lapply(files, read.csv, stringsAsFactors = FALSE)
  all_cols <- unique(unlist(lapply(parts, names)))
  results <- do.call(rbind, lapply(parts, function(x) {
    x[setdiff(all_cols, names(x))] <- NA; x[all_cols] }))
  message("Read ", length(files), " per-job files.")
}
if (!"design" %in% names(results)) results$design <- "dgp_ate"
results$phi[is.na(results$phi) | results$phi == ""] <- "-"

KERNEL_ORDER <- c("Gaussian", "Laplace", "Isotropic", "ED", "IPW", "CBPS")
PHI_ORDER    <- c("none", "linear", "quadratic", "-")

## ---- truth and SEB (from SEB_EIF.csv, written by 09_seb_eif.R) -------------------
if (!file.exists("SEB_EIF.csv")) {
  stop("SEB_EIF.csv not found: run 09_seb_eif.R (same sim_design.R as the jobs) first.",
       call. = FALSE)
}
seb_tab <- read.csv("SEB_EIF.csv", stringsAsFactors = FALSE)
if (!"design" %in% names(seb_tab)) seb_tab$design <- "dgp_ate"
seb_row <- function(design, kappa) {
  r <- seb_tab[seb_tab$design == design & seb_tab$kappa == kappa, ]
  if (!nrow(r)) stop("SEB_EIF.csv has no row for design ", design, ", kappa ", kappa,
                     ": re-run 09_seb_eif.R with the same sim_design.R.", call. = FALSE)
  r[1, ]
}
truth_of <- function(design, kappa) seb_row(design, kappa)$tau
seb_of <- function(design, kappa, n) 100 * seb_row(design, kappa)$sd_eif / sqrt(n)

ci_methods <- intersect(c("Wald", "CAdj", "SS", "Boot"),
                        sub("\\.Lower$", "", grep("\\.Lower$", names(results), value = TRUE)))

summarize_ci <- function(df, prefix, truth) {
  lower <- df[[paste0(prefix, ".Lower")]]; upper <- df[[paste0(prefix, ".Upper")]]
  ok <- !is.na(lower) & !is.na(upper)
  out <- if (!any(ok)) {
    data.frame(Length = NA_real_, Coverage = NA_real_, Time = NA_real_, MeanSE = NA_real_)
  } else {
    data.frame(Length = mean(upper[ok] - lower[ok]),
               Coverage = mean(truth >= lower[ok] & truth <= upper[ok]),
               Time = mean(df[[paste0(prefix, ".Time")]][ok]),
               MeanSE = 100 * mean(df[[paste0(prefix, ".SE")]][ok]))
  }
  setNames(out, paste0(prefix, ".", names(out)))
}

report <- results %>%
  group_by(design, kappa, N, kernel, phi, c0) %>%
  group_modify(function(df, key) {
    truth <- truth_of(key$design, key$kappa)
    sw_p <- if (nrow(df) >= 3 && stats::sd(df$point_est) > 0)
      stats::shapiro.test(df$point_est)$p.value else NA_real_
    bind_cols(
      data.frame(n_reps = nrow(df),
                 Bias = 100 * mean(df$point_est - truth),
                 ESE  = 100 * stats::sd(df$point_est),
                 SEB  = seb_of(key$design, key$kappa, key$N),
                 RMSE = 100 * sqrt(mean((df$point_est - truth)^2)),
                 Shapiro_p = sw_p,
                 Fit.Time = mean(df$Fit.Time)),
      if (length(ci_methods)) bind_cols(lapply(ci_methods, function(p) summarize_ci(df, p, truth)))
      else NULL
    )
  }) %>%
  ungroup()

base <- report %>% filter(phi == "none") %>% select(design, kappa, N, kernel, RMSE_none = RMSE)
report <- report %>%
  left_join(base, by = c("design", "kappa", "N", "kernel")) %>%
  mutate(Rel = RMSE / RMSE_none) %>% select(-RMSE_none) %>%
  mutate(kernel = factor(kernel, levels = KERNEL_ORDER),
         phi = factor(phi, levels = PHI_ORDER)) %>%
  arrange(design, kappa, N, kernel, phi, c0) %>%
  mutate(across(where(is.numeric), ~ ifelse(is.nan(.x), NA_real_, .x)))

write.csv(report, sprintf("ATE_%s_summary.csv", STAGE), row.names = FALSE)

## ---- LaTeX table -------------------------------------------------------------------
fmt <- function(x, digits) ifelse(is.na(x), "--", formatC(x, format = "f", digits = digits))
fmt_time <- function(x) ifelse(is.na(x), "--", ifelse(x >= 1, formatC(x, format = "f", digits = 2),
                                                        formatC(x, format = "f", digits = 4)))
ci_label <- c(Wald = "Wald CI", CAdj = "C-adj.\\ Wald CI", SS = "SS CI", Boot = "Boot CI")
phi_label <- c(none = "None", linear = "Linear", quadratic = "Quadratic", `-` = "")

if (STAGE == "moments") {
  lead <- c("N", "Kernel", "$\\varphi$", "$c_0$")
  point <- c("Bias", "ESE", "SEB", "RMSE", "Rel.")
} else {
  lead <- c("N", "Kernel")
  point <- c("Bias", "ESE", "SEB")
}
n_lead <- length(lead); n_point <- length(point)
n_cols <- n_lead + n_point + 3 * length(ci_methods)

for (k in sort(unique(report$kappa))) {
  tab <- report %>% filter(kappa == k)
  top <- paste0(paste(c(lead, point), collapse = " & "),
                if (length(ci_methods)) paste0(" & \\multicolumn{3}{c}{", ci_label[ci_methods], "}",
                                               collapse = "") else "", " \\\\")
  lines <- c("% requires \\usepackage{booktabs,multirow}",
             "\\begin{table}[ht]", "\\centering", "\\footnotesize",
             "\\setlength{\\tabcolsep}{3pt}",
             sprintf("\\begin{tabular}{%s}", paste0(strrep("c", n_lead), strrep("c", n_point),
                                                     strrep("c", 3 * length(ci_methods)))),
             "\\toprule", top)
  if (length(ci_methods)) {
    starts <- n_lead + n_point + 1 + 3 * (seq_along(ci_methods) - 1)
    lines <- c(lines,
      paste0(sprintf("\\cmidrule(lr){%d-%d}", starts, starts + 2), collapse = ""),
      paste0(strrep(" & ", n_lead + n_point - 1),
             paste(rep(" & Length & Cov. & Time", length(ci_methods)), collapse = ""), " \\\\"))
  }
  lines <- c(lines, "\\midrule")
  Ns <- sort(unique(tab$N))
  for (j in seq_along(Ns)) {
    blk <- tab %>% filter(N == Ns[j])
    for (r in seq_len(nrow(blk))) {
      row <- blk[r, ]
      first_of_kernel <- r == 1 || blk$kernel[r] != blk$kernel[r - 1]
      lead_cells <- c(if (r == 1) sprintf("\\multirow{%d}{*}{%d}", nrow(blk), Ns[j]) else "",
                      if (first_of_kernel) as.character(row$kernel) else "")
      if (STAGE == "moments") {
        lead_cells <- c(lead_cells, phi_label[[as.character(row$phi)]],
                        if (is.na(row$c0) || row$phi == "none") "--" else format(row$c0))
      }
      point_cells <- c(fmt(row$Bias, 2), fmt(row$ESE, 2), fmt(row$SEB, 2))
      if (STAGE == "moments") point_cells <- c(point_cells, fmt(row$RMSE, 2), fmt(row$Rel, 3))
      ci_cells <- unlist(lapply(ci_methods, function(p) c(
        fmt(row[[paste0(p, ".Length")]], 3), fmt(row[[paste0(p, ".Coverage")]], 3),
        fmt_time(row[[paste0(p, ".Time")]]))))
      if (STAGE == "moments" && r > 1 && first_of_kernel) lines <- c(lines, "\\addlinespace[2pt]")
      lines <- c(lines, paste0(paste(c(lead_cells, point_cells, ci_cells), collapse = " & "),
                               " \\\\"))
    }
    if (j < length(Ns)) lines <- c(lines, "\\midrule")
  }
  lines <- c(lines, "\\bottomrule", "\\end{tabular}",
    sprintf(paste0("\\caption{ATE simulation (%s stage, design %s), $\\kappa = %s$, %d replicates per ",
                   "cell. Bias, ESE, SEB%s are multiplied by 100; SEB is the efficiency ",
                   "bound $\\mathrm{sd}(\\mathrm{EIF})/\\sqrt{n}$. Times are in seconds.}"),
            STAGE, paste(unique(tab$design), collapse = ", "), format(k), max(tab$n_reps), if (STAGE == "moments") " and RMSE" else ""),
    "\\end{table}")
  out_file <- if (length(unique(report$kappa)) > 1)
    sprintf("ATE_%s_table_kappa%s.tex", STAGE, format(k)) else sprintf("ATE_%s_table.tex", STAGE)
  writeLines(lines, out_file)
  message("wrote ", out_file)
}

show_cols <- c("N", "kernel", "phi", "c0", "n_reps", "Bias", "ESE", "SEB", "RMSE", "Rel",
               paste0(ci_methods, ".Coverage"))
print(as.data.frame(report[, intersect(show_cols, names(report))]), digits = 3)
