test_that("cfd_weights() satisfies the sum-to-group-size constraints (eq. 13/17)", {
  set.seed(10)
  n <- 40
  X <- matrix(rnorm(n * 3), n, 3)
  Z <- rbinom(n, 1, 0.5)
  res <- cfd_weights(Z, X, density = "gaussian")
  expect_true(all(res$w >= -1e-8))
  expect_equal(sum(res$w[Z == 1]), sum(Z == 1), tolerance = 1e-4)
  expect_equal(sum(res$w[Z == 0]), sum(Z == 0), tolerance = 1e-4)
})

test_that("cfd_weights() Q matrix matches the paper's eq. (17) three-way construction", {
  set.seed(11)
  n <- 25
  X <- matrix(rnorm(n * 2), n, 2)
  Z <- rbinom(n, 1, 0.5)
  lambda <- default_lambda(n)
  gram <- cfd_kernel_gram(X, "gaussian")
  K <- gram$K
  i1 <- as.numeric(Z == 1); i0 <- as.numeric(Z == 0)
  n1 <- sum(i1); n0 <- sum(i0)
  D1 <- diag(i1); D0 <- diag(i0)
  Q_expected <- (D1 %*% K %*% D1) / n1^2 + (D0 %*% K %*% D0) / n0^2 -
    (D1 %*% K %*% D0) / (n1 * n0) + lambda^2 * diag(n)

  res <- cfd_weights(Z, X, density = "gaussian", bandwidth = gram$bandwidth, lambda = lambda)
  expect_equal(res$Q, Q_expected, tolerance = 1e-8)
})

test_that("a user-supplied Q matrix is used directly (flexible Q hook)", {
  set.seed(12)
  n <- 20
  Z <- rbinom(n, 1, 0.5)
  custom_Q <- diag(n) * 0.01
  res <- cfd_weights(Z, Q = custom_Q)
  expect_equal(res$Q, custom_Q)
  expect_true(all(res$w >= -1e-8))
})

test_that("a user-supplied custom density (kernel_fun) is honored", {
  set.seed(13)
  n <- 20
  X <- matrix(rnorm(n * 2), n, 2)
  Z <- rbinom(n, 1, 0.5)
  my_density <- cfd_density("custom", kernel_fun = function(D, bandwidth) exp(-D / bandwidth),
                             distance = "manhattan")
  res <- cfd_weights(Z, X, density = my_density)
  expect_true(all(is.finite(res$w)))
})

test_that("bug fix: the energy-distance QP solves reliably via solve_qp_safe()", {
  set.seed(14)
  n <- 60
  X <- matrix(rnorm(n * 5), n, 5)
  Z <- rbinom(n, 1, 0.5)
  # A tiny lambda stresses the conditionally-PSD-only energy kernel the hardest.
  res <- cfd_weights(Z, X, density = "energy", lambda = 1e-10)
  expect_true(all(is.finite(res$w)))
  expect_true(all(res$w >= -1e-6))
})

test_that("solve_qp_safe() eigenvalue-floors an indefinite Q and still solves", {
  set.seed(15)
  n <- 10
  # An intentionally indefinite matrix (negative eigenvalues), mimicking -D for ED.
  M <- matrix(rnorm(n * n), n, n); Qbad <- -(M %*% t(M)) / n
  Amat <- matrix(1, 1, n); dvec <- n
  res <- solve_qp_safe(Qbad, rep(0, n), Amat, dvec)
  expect_true(res$jittered)
  expect_true(all(is.finite(res$w)))
})

test_that("default_lambda() satisfies lambda = o(n^-1) and .check_lambda_rate warns otherwise", {
  expect_lt(default_lambda(100) * 100, 1)
  expect_lt(default_lambda(10000) * 10000, default_lambda(100) * 100)  # ratio shrinks
  expect_warning(cfd_weights(rbinom(20, 1, 0.5), Q = diag(20), lambda = 1 / 20 * 2),
                  "does not satisfy")
})
