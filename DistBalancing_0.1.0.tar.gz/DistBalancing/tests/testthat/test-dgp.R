test_that("dgp_iv() produces correctly shaped, reproducible output", {
  d1 <- dgp_iv(1, n = 100, p = 10)
  expect_equal(dim(d1$X), c(100, 10))
  expect_equal(length(d1$Z), 100)
  expect_true(all(d1$Z %in% c(0, 1)))
  expect_true(all(d1$A %in% c(0, 1)))
  expect_true(is.finite(d1$LATE))

  set.seed(99); a <- dgp_iv(2, n = 50, p = 10)
  set.seed(99); b <- dgp_iv(2, n = 50, p = 10)
  expect_equal(a, b)
})
