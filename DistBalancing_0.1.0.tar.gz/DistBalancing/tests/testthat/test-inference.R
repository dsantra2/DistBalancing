test_that("bug fix demonstration: rescaling before vs. after computing the volatility index can select a different subsample size", {
  # Minimal, deterministic illustration of why order matters (Summary item
  # "correcting the subsampling calculation" / Appendix A.8 Algorithm 1).
  # Three candidate m's, with RAW (unscaled) CI half-widths that are *locally flattest*
  # (lowest volatility) at m2 -- so the old, buggy order (compute VI on raw bounds)
  # would pick m2. But once every bound is rescaled by sqrt(m/n), the *scaled* bounds
  # are locally flattest at m3 instead -- which is what Algorithm 1 actually requires.
  n <- 400
  grid <- c(m1 = 50, m2 = 100, m3 = 200)
  raw_lower <- c(-1.00, -0.60, -0.30)
  raw_upper <- c(1.00, 0.60, 0.50)

  # "Old" (buggy) selection: volatility computed directly on the raw bounds.
  vi_raw <- function(i) sd(raw_lower[max(1, i - 1):min(3, i + 1)]) +
    sd(raw_upper[max(1, i - 1):min(3, i + 1)])
  old_best <- which.min(vapply(1:3, vi_raw, numeric(1)))

  # "New" (fixed) selection: rescale every bound by sqrt(m/n) *first*, per Algorithm 1.
  scale_factor <- sqrt(grid / n)
  scaled_lower <- scale_factor * raw_lower
  scaled_upper <- scale_factor * raw_upper
  vi_scaled <- function(i) sd(scaled_lower[max(1, i - 1):min(3, i + 1)]) +
    sd(scaled_upper[max(1, i - 1):min(3, i + 1)])
  new_best <- which.min(vapply(1:3, vi_scaled, numeric(1)))

  expect_false(identical(old_best, new_best))
})

test_that("subsample_ci() actually rescales before computing the CI/VI (not just at the end)", {
  set.seed(123)
  n <- 80
  d <- dgp_iv(1, n = n, p = 4)
  grid <- c(15, 20, 25)
  B <- 60

  res <- subsample_ci(d$X, d$Z, d$Y, d$A, density = "gaussian", grid = grid, B = B,
                       estimand = "late", seed = 123)

  # Manually reproduce the *same* grid loop with the same seed / RNG draw order, so
  # that the middle grid point's replicates can be checked against the reported
  # per-m confidence interval: this confirms `ci_by_m` really is the quantile of the
  # *rescaled* replicates, not the raw ones with rescaling applied only at the end.
  set.seed(123)
  gram <- cfd_kernel_gram(d$X, "gaussian")
  K <- gram$K
  lambda <- default_lambda(n)
  full_w <- cfd_weights(Z = d$Z, K = K, lambda = lambda)$w
  full_late <- late_weighting_estimate(d$Y, d$A, d$Z, full_w)$late

  expected_ci_at_m20 <- NULL
  for (m in grid) {
    raw <- numeric(B)
    for (b in seq_len(B)) {
      idx <- sample.int(n, m, replace = FALSE)
      w_sub <- cfd_weights(Z = d$Z[idx], K = K[idx, idx, drop = FALSE], lambda = lambda)$w
      raw[b] <- late_weighting_estimate(d$Y[idx], d$A[idx], d$Z[idx], w_sub)$late
    }
    scaled <- full_late + sqrt(m / n) * (raw - full_late)
    if (m == 20) {
      expected_ci_at_m20 <- stats::quantile(scaled, c(0.025, 0.975), na.rm = TRUE)
    }
  }

  reported_ci_at_m20 <- res$ci_by_m[["20"]][, "late"]
  expect_equal(unname(reported_ci_at_m20), unname(expected_ci_at_m20), tolerance = 1e-6)
})

test_that("subsample_ci() end-to-end smoke test (ATE and LATE) returns finite, ordered CIs", {
  set.seed(1)
  n <- 150
  d <- dgp_iv(1, n = n, p = 4)

  res_late <- subsample_ci(d$X, d$Z, d$Y, d$A, density = "gaussian", B = 40,
                            estimand = "late", seed = 1)
  expect_true(res_late$ci$late[1] <= res_late$ci$late[2])
  expect_true(res_late$best_m$late %in% res_late$grid)

  res_ate <- subsample_ci(d$X, d$Z, d$Y, density = "gaussian", B = 40,
                           estimand = "ate", seed = 1)
  expect_true(res_ate$ci$ate[1] <= res_ate$ci$ate[2])
})

test_that("bootstrap_ci() smoke test returns a valid interval", {
  set.seed(2)
  n <- 100
  d <- dgp_iv(1, n = n, p = 4)
  res <- bootstrap_ci(d$X, d$Z, d$Y, d$A, method = "gaussian", B = 40,
                       estimand = "late", seed = 2)
  expect_true(res$ci$late[1] <= res$ci$late[2])
})
