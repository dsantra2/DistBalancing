test_that("ate_weighting_estimate() reduces to a simple mean difference for unit weights", {
  set.seed(20)
  n <- 50
  Z <- rbinom(n, 1, 0.5)
  Y <- rnorm(n)
  est <- ate_weighting_estimate(Y, Z, rep(1, n))
  expect_equal(est, mean(Y[Z == 1]) - mean(Y[Z == 0]))
})

test_that("late_weighting_estimate() is the ratio of the two ATE-form components", {
  set.seed(21)
  n <- 50
  Z <- rbinom(n, 1, 0.5)
  Y <- rnorm(n); A <- rbinom(n, 1, 0.5)
  w <- runif(n, 0.5, 1.5)
  res <- late_weighting_estimate(Y, A, Z, w)
  expect_equal(res$late, res$numerator / res$denominator)
  expect_equal(res$numerator, ate_weighting_estimate(Y, Z, w))
  expect_equal(res$denominator, ate_weighting_estimate(A, Z, w))
})

test_that("ipw_estimate() returns weights summing consistently within each arm", {
  set.seed(22)
  n <- 200
  X <- matrix(rnorm(n * 3), n, 3)
  Z <- rbinom(n, 1, plogis(X %*% c(0.3, -0.2, 0.1)))
  Y <- rnorm(n)
  res <- ipw_estimate(Z, X, Y = Y)
  expect_true(is.finite(res$ate))
  expect_true(all(res$prop_score > 0 & res$prop_score < 1))
})
