test_that("Gaussian kernel closed form matches direct computation", {
  set.seed(1)
  X <- matrix(rnorm(20 * 3), 20, 3)
  gamma <- 1.3
  K <- cfd_kernel_gram(X, cfd_density("gaussian"), bandwidth = gamma)$K
  D <- as.matrix(dist(X))
  expect_equal(K, exp(-(D / gamma)^2), tolerance = 1e-10)
})

test_that("Laplacian kernel closed form matches direct computation", {
  set.seed(2)
  X <- matrix(rnorm(20 * 3), 20, 3)
  gamma <- 0.7
  K <- cfd_kernel_gram(X, cfd_density("laplacian"), bandwidth = gamma)$K
  D1 <- as.matrix(dist(X, method = "manhattan"))
  expect_equal(K, exp(-D1 / gamma), tolerance = 1e-10)
})

test_that("Energy (ED) Gram matrix is the double-centered -||x - x'||_2 and is PSD", {
  set.seed(3)
  X <- matrix(rnorm(15 * 4), 15, 4)
  K <- cfd_kernel_gram(X, cfd_density("energy"))$K
  D <- as.matrix(dist(X))
  J <- diag(15) - matrix(1 / 15, 15, 15)
  expect_equal(unname(K), unname(-J %*% D %*% J), tolerance = 1e-10)
  expect_true(isSymmetric(K))
  expect_gt(min(eigen(K, symmetric = TRUE, only.values = TRUE)$values), -1e-10)
})

test_that("centering the ED kernel leaves every equal-mass discrepancy unchanged", {
  set.seed(31)
  n <- 30
  X <- matrix(runif(n * 3), n, 3)
  Kc <- cfd_kernel_gram(X, "energy")$K
  Kd <- -as.matrix(dist(X))
  a <- runif(n); a <- a / sum(a); b <- runif(n); b <- b / sum(b)
  expect_equal(drop(t(a - b) %*% Kc %*% (a - b)), drop(t(a - b) %*% Kd %*% (a - b)),
               tolerance = 1e-10)
  Z <- rbinom(n, 1, 0.5)
  w <- runif(n); w[Z == 1] <- w[Z == 1] * sum(Z) / sum(w[Z == 1])
  w[Z == 0] <- w[Z == 0] * sum(1 - Z) / sum(w[Z == 0])
  for (tw in c(TRUE, FALSE)) {
    Gc <- DistBalancing:::.cfd_kernel_terms(Kc, Z, tw)
    Gd <- DistBalancing:::.cfd_kernel_terms(Kd, Z, tw)
    loss <- function(G) drop(t(w) %*% G$Q %*% w) + sum(G$q * w) + G$const
    expect_equal(loss(Gc), loss(Gd), tolerance = 1e-10)
  }
})

test_that("Matern kernel with nu = 2.5 matches the paper's closed form (Appendix A.2.3)", {
  set.seed(4)
  X <- matrix(rnorm(15 * 3), 15, 3)
  gamma <- 0.9
  K <- cfd_kernel_gram(X, cfd_density("matern", nu = 2.5), bandwidth = gamma)$K
  D <- as.matrix(dist(X))
  r <- D / gamma
  K_expected <- (1 + sqrt(5) * r + 5 * r^2 / 3) * exp(-sqrt(5) * r)
  diag(K_expected) <- 1
  expect_equal(K, K_expected, tolerance = 1e-10)
})

test_that("Monte Carlo kernel approximation converges to the closed form (Gaussian)", {
  set.seed(5)
  X <- matrix(rnorm(10 * 2), 10, 2)
  gamma <- 1
  K_exact <- cfd_kernel_gram(X, cfd_density("gaussian"), bandwidth = gamma)$K
  gaussian_sampler <- function(L, d, bandwidth) {
    matrix(rnorm(L * d, sd = sqrt(2) / bandwidth), L, d)
  }
  K_mc <- mc_kernel_gram(X, gaussian_sampler, L = 2e4, bandwidth = gamma)
  dimnames(K_mc) <- dimnames(K_exact) <- NULL
  expect_equal(K_mc, K_exact, tolerance = 0.05)
})

test_that("median heuristic bandwidth is used when bandwidth = NULL", {
  set.seed(6)
  X <- matrix(rnorm(30 * 2), 30, 2)
  D <- as.matrix(dist(X))
  expected_bw <- median(D[upper.tri(D)])
  gram <- cfd_kernel_gram(X, cfd_density("gaussian"))
  expect_equal(gram$bandwidth, expected_bw)
})
