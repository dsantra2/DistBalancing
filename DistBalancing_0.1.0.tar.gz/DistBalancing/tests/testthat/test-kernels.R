test_that("Gaussian kernel closed form matches direct computation", {
  set.seed(1)
  X <- matrix(rnorm(20 * 3), 20, 3)
  gamma <- 1.3
  K <- cfd_kernel_gram(X, cfd_density("gaussian"), bandwidth = gamma)$K
  D <- as.matrix(dist(X))
  expect_equal(K, exp(-(D / gamma)^2), tolerance = 1e-10)
})

test_that("Laplacian kernel closed form matches direct computation", {
  set.seed(2)
  X <- matrix(rnorm(20 * 3), 20, 3)
  gamma <- 0.7
  K <- cfd_kernel_gram(X, cfd_density("laplacian"), bandwidth = gamma)$K
  D1 <- as.matrix(dist(X, method = "manhattan"))
  expect_equal(K, exp(-D1 / gamma), tolerance = 1e-10)
})

test_that("Energy (ED) kernel is exactly -||x - x'||_2 (bug fix: ED Gram matrix)", {
  set.seed(3)
  X <- matrix(rnorm(15 * 4), 15, 4)
  K <- cfd_kernel_gram(X, cfd_density("energy"))$K
  D <- as.matrix(dist(X))
  expect_equal(K, -D, tolerance = 1e-12)
  expect_equal(unname(diag(K)), rep(0, 15))
  expect_true(isSymmetric(K))
})

test_that("Matern kernel with nu = 2.5 matches the paper's closed form (Appendix A.2.3)", {
  set.seed(4)
  X <- matrix(rnorm(15 * 3), 15, 3)
  gamma <- 0.9
  K <- cfd_kernel_gram(X, cfd_density("matern", nu = 2.5), bandwidth = gamma)$K
  D <- as.matrix(dist(X))
  r <- D / gamma
  K_expected <- (1 + sqrt(5) * r + 5 * r^2 / 3) * exp(-sqrt(5) * r)
  diag(K_expected) <- 1
  expect_equal(K, K_expected, tolerance = 1e-10)
})

test_that("Monte Carlo kernel approximation converges to the closed form (Gaussian)", {
  set.seed(5)
  X <- matrix(rnorm(10 * 2), 10, 2)
  gamma <- 1
  K_exact <- cfd_kernel_gram(X, cfd_density("gaussian"), bandwidth = gamma)$K
  gaussian_sampler <- function(L, d, bandwidth) {
    matrix(rnorm(L * d, sd = sqrt(2) / bandwidth), L, d)
  }
  K_mc <- mc_kernel_gram(X, gaussian_sampler, L = 2e4, bandwidth = gamma)
  dimnames(K_mc) <- dimnames(K_exact) <- NULL
  expect_equal(K_mc, K_exact, tolerance = 0.05)
})

test_that("median heuristic bandwidth is used when bandwidth = NULL", {
  set.seed(6)
  X <- matrix(rnorm(30 * 2), 30, 2)
  D <- as.matrix(dist(X))
  expected_bw <- median(D[upper.tri(D)])
  gram <- cfd_kernel_gram(X, cfd_density("gaussian"))
  expect_equal(gram$bandwidth, expected_bw)
})
