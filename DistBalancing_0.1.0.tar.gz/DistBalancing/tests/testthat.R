library(testthat)
library(DistBalancing)

test_check("DistBalancing")
