#!/usr/bin/env Rscript
## ============================================================================
## Aggregates the per-job CSVs from 06_ate_simulation_cluster.R (concatenated into
## Result_ATE_combined.csv -- see the header of that script) into the summary
## table: one row per (kernel, phi, c0, N, kappa) cell.
##
##   Rscript 07_ate_simulation_report.R
##
## Columns (point-estimate summaries are x100, standard Monte Carlo terminology):
##   Bias       = 100 * mean(point_est - truth)
##   ESE        = 100 * sd(point_est)       (empirical SE across replicates)
##   RMSE       = 100 * sqrt(mean((point_est - truth)^2))
##   RMSE_rel   = RMSE / RMSE of the c0 = 0 fit of the same kernel and N (on the same
##                datasets, so this is a paired comparison); 1 for c0 = 0 itself
##   Shapiro_p  = Shapiro-Wilk p-value of the standardized point estimates
##   SE.SS / SE.Plugin / SE.CenterAdj = 100 * mean estimated SE of each method,
##                to compare against ESE
##   <method>.Length / .Coverage / .Time for SS (percentile), SS.Wald, Plugin,
##                CenterAdj; Fit.Time is the time of one full-sample fit
##   lambda_n, moment_k, SS.m = mean data-driven lambda_n, mean scale factor
##                k = ||Q_phi|| / ||Q_G||, mean selected subsample size
## ============================================================================

suppressMessages({
  library(dplyr)
  library(purrr)
})

results <- read.csv("Result_ATE_combined.csv", header = TRUE, stringsAsFactors = FALSE)
results$phi[is.na(results$phi) | results$phi == ""] <- "-"

truth_by_kappa <- sort(unique(results$kappa)) %>%
  purrr::map_dbl(~ DistBalancing::true_ate(.x, n_mc = 2e6, seed = 1)) %>%
  setNames(as.character(sort(unique(results$kappa))))

summarize_ci <- function(df, prefix, time_col, truth) {
  lower <- df[[paste0(prefix, ".Lower")]]; upper <- df[[paste0(prefix, ".Upper")]]
  out <- data.frame(
    Length = mean(upper - lower, na.rm = TRUE),
    Coverage = mean(truth >= lower & truth <= upper, na.rm = TRUE),
    Time = mean(df[[time_col]], na.rm = TRUE)
  )
  setNames(out, paste0(prefix, ".", names(out)))
}

report <- results %>%
  group_by(kernel, phi, c0, N, kappa) %>%
  group_modify(function(df, key) {
    truth <- truth_by_kappa[[as.character(key$kappa)]]
    z <- (df$point_est - mean(df$point_est)) / stats::sd(df$point_est)
    sw_p <- if (length(z) >= 3 && length(z) <= 5000 && stats::sd(z) > 0)
      stats::shapiro.test(z)$p.value else NA_real_

    bind_cols(
      data.frame(
        n_reps = nrow(df),
        Bias = 100 * mean(df$point_est - truth),
        ESE = 100 * stats::sd(df$point_est),
        RMSE = 100 * sqrt(mean((df$point_est - truth)^2)),
        Shapiro_p = sw_p,
        SE.SS = 100 * mean(df$SS.SE, na.rm = TRUE),
        SE.Plugin = 100 * mean(df$Plugin.SE, na.rm = TRUE),
        SE.CenterAdj = 100 * mean(df$CenterAdj.SE, na.rm = TRUE)
      ),
      # SS.Wald reuses SS.Time: it comes out of the same subsample_ci() call as SS.
      summarize_ci(df, "SS", "SS.Time", truth),
      summarize_ci(df, "SS.Wald", "SS.Time", truth),
      summarize_ci(df, "Plugin", "Plugin.Time", truth),
      summarize_ci(df, "CenterAdj", "CenterAdj.Time", truth),
      data.frame(
        Fit.Time = mean(df$Fit.Time, na.rm = TRUE),
        lambda_n = mean(df$lambda_n, na.rm = TRUE),
        moment_k = mean(df$moment_k, na.rm = TRUE),
        SS.m = mean(df$SS.m, na.rm = TRUE)
      )
    )
  }) %>%
  ungroup()

## RMSE relative to the purely distributional fit (c0 = 0) of the same kernel/N/kappa.
base_rmse <- report %>% filter(c0 == 0) %>% select(kernel, N, kappa, RMSE_c0_0 = RMSE)
report <- report %>%
  left_join(base_rmse, by = c("kernel", "N", "kappa")) %>%
  mutate(RMSE_rel = RMSE / RMSE_c0_0) %>%
  select(-RMSE_c0_0) %>%
  relocate(RMSE_rel, .after = RMSE) %>%
  mutate(phi = factor(phi, levels = c("none", "linear", "quadratic", "-")),
         kernel = factor(kernel, levels = c("Gaussian", "Laplace", "Isotropic", "ED",
                                             "IPW", "CBPS"))) %>%
  arrange(N, kappa, kernel, phi, c0)

write.csv(report, file = "ATE_simulation_summary_table.csv", row.names = FALSE)
print(as.data.frame(report), digits = 3)
