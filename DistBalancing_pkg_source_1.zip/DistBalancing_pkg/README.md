# DistBalancing

An R package implementing the characteristic function distance (CFD) framework of
Santra, Chen, and Park (2026), *"Distributional Balancing for Causal Inference: A
Unified Framework via Characteristic Function Distance."* The package provides
CFD-based distributional balancing weights, average and local average treatment
effect (ATE/LATE) weighting estimators, several confidence-interval constructions
(including the subsampling procedure the paper recommends), and scripts reproducing
the paper's simulation study and 401(k) data application.

## Installation

```r
# from the package source directory
devtools::install(".")

# core dependency not on CRAN's usual mirrors in every environment:
# install.packages("optiSolve")   # or: remotes::install_github("cran/optiSolve")
```

`CBPS` (for `cbps_estimate()`) and `DoubleML`/`mlr3`/`mlr3learners` (for
`load_401k()`) are `Suggests`-only — the core package builds, loads, and passes its
test suite without them.

## Quick start

```r
library(DistBalancing)

# Simulate an observational-study dataset, or supply your own (Y, Z, X).
d <- dgp_ate(kappa = 0, n = 500)

# Compute CFD balancing weights and the ATE weighting estimator.
w   <- cfd_weights(Z = d$A, X = d$X, density = "gaussian")$w
ate <- ate_weighting_estimate(d$Y, d$A, w)

# Confidence intervals: subsampling (recommended by the paper), bootstrap, or a
# closed-form plug-in variance estimator.
ss   <- subsample_ci(d$X, d$A, d$Y, density = "gaussian", estimand = "ate")
boot <- bootstrap_ci(d$X, d$A, d$Y, method = "gaussian", estimand = "ate")
pi   <- plugin_ci(d$Y, d$A, w)

ss$ci$ate; boot$ci$ate; pi$ci
```

## The flexible `cfd_weights()` entry point

```r
# 1. Built-in kernel by name (bandwidth defaults to the median heuristic):
w <- cfd_weights(Z, X, density = "gaussian")$w

# 2. A different built-in family, explicit bandwidth:
w <- cfd_weights(Z, X, density = "matern", bandwidth = 0.8)$w

# 3. A fully custom spectral density / kernel:
my_density <- cfd_density("custom",
  kernel_fun = function(D, bandwidth) exp(-(D / bandwidth)^1.5),  # some other kernel
  distance   = "euclidean")
w <- cfd_weights(Z, X, density = my_density)$w

# 4. Bypass kernel construction entirely and hand the QP its Q matrix directly:
w <- cfd_weights(Z, Q = my_own_Q_matrix)$w
```

`density` accepts `"gaussian"`, `"laplacian"`, `"t"` (Student-t / the paper's `t5`
family), `"matern"` (isotropic), `"energy"` (energy distance / ED), or a
`cfd_density("custom", ...)` object.

By default, `three_way = TRUE` balances each treatment arm against both the full
sample and against each other (eq. 13/17); `three_way = FALSE` uses the simpler
two-way objective of eq. (12). In both cases the quadratic program's objective
\(w^\top Q_G w + q_G^\top w\) is, up to a constant, exactly the sum of the pairwise
squared MMDs between the weighted treated arm, the weighted control arm and the
pooled sample (see `?cfd_weights` for \(Q_G\) and \(q_G\)).

### Balancing user-specified moments alongside the distribution

Specific moments can be balanced in addition to the full distribution, with a
ratio parameter `moment_ratio` (\(c_0\)) controlling their relative weight:

```r
# first and second moments, given as a function of X ...
fit <- cfd_weights(Z, X, density = "gaussian", moment_ratio = 1,
                   moment_features = function(X) cbind(X, X^2))
# ... or as a precomputed n x m matrix of moment functions
fit <- cfd_weights(Z, X, density = "gaussian", moment_ratio = 1,
                   moment_features = my_moment_matrix)
```

With moments \(\Phi\) (default: \(\Phi(X) = X\), i.e. covariate means) and weighting
matrix \(Q_m\) (`moment_Q`; default: inverse feature variances), the moment term is
the same pairwise construction under the finite-rank kernel
\(\Phi(x)^\top Q_m \Phi(y)\), giving a matrix \(\bar Q_\Phi\)
(`moment_balance_gram()`). The two terms are combined as

\[ L(w) = w^\top\Big(\tfrac{c_0}{k}\,\bar Q_\Phi + Q_G\Big)w + \text{(linear and
constant terms)}, \qquad k = \frac{\|\bar Q_\Phi\|}{\|Q_G\|}, \]

so that after dividing by \(k\) the two matrices have the same (Frobenius) norm and
\(c_0\) is directly their relative weight: `moment_ratio = 0` is pure distributional
balancing, `1` weights the two terms equally, and e.g. `0.1` / `10` tilt towards the
distribution / the moments. The scale factor and the implied absolute weight are
returned as `fit$moment_scale` (\(k\)) and `fit$moment_gamma` (\(c_0/k\));
`moment_gamma` can also be set directly instead of `moment_ratio`.

### Data-driven regularization

`lambda = "ipw"` chooses the ridge parameter from the data. Writing the penalty as
\(\lambda_n \|w/n\|_2^2\), \(\lambda_n\) is set so that, at the (Hajek-normalized)
inverse-propensity weights \(\hat w_{\rm IPW}\), the penalty is a small, slowly
vanishing fraction of the loss:

\[ \lambda_n = \frac{n^2 L(\hat w_{\rm IPW})}{\|\hat w_{\rm IPW}\|_2^2}\times 0.1\times
n^{-0.01}, \]

where \(L\) is the full objective above (moment term included). The constants are
`lambda_const = 0.1` and `lambda_decay = 0.01`; `lambda_ref_w` replaces
\(\hat w_{\rm IPW}\) by another reference weight vector. The value used is returned as
`fit$lambda`. The default, `lambda = NULL`, keeps the fixed rate
`default_lambda(n) = n^-2` with penalty \(\lambda^2\|w\|_2^2\).

`subsample_ci()` and `bootstrap_ci()` accept the same `moment_ratio`,
`moment_features`, `moment_Q` and `lambda = "ipw"` arguments and re-apply the whole
specification on every resample (recomputing \(k\) and \(\lambda_n\), and subsetting a
matrix of moments to the resampled rows), so the confidence interval describes the
same estimator as the point estimate.

## Weighting estimators and inference

`ate_weighting_estimate()` and `late_weighting_estimate()` compute the paper's
weighting estimators of the ATE (eq. 2/18) and LATE (eq. 21) from any weight vector
— CFD weights, or the `ipw_estimate()`/`cbps_estimate()` alternatives (Appendix
A.10) provided for comparison.

Four confidence-interval constructions are available:

- **`subsample_ci()`** — the paper's recommended method (Section 4.2, Algorithm 1 of
  Appendix A.8): valid without assuming the weighting estimator is asymptotically
  regular, unlike a naive bootstrap. The estimator is recomputed on `B` subsamples of
  size `m` drawn without replacement, and the confidence interval is built by
  inverting the pivot \(\sqrt n(\hat\tau - \tau)\) using the rescaled subsample
  distribution of \(\sqrt m(\hat\tau^{(m,b)} - \hat\tau)\) (Politis, Romano and Wolf,
  1999); `m` itself is chosen automatically by a data-adaptive minimum-volatility
  search. The resampling, subsample-size search, and CI construction are all carried
  out via the [`moonboot`](https://cran.r-project.org/package=moonboot) package
  (`moonboot::estimate.m()`, `mboot()`, and `mboot.ci()`); pass `m` directly to use a
  fixed subsample size instead of searching for one. See `?subsample_ci` for the
  exact formula and the full set of tuning arguments.
- **`bootstrap_ci()`** — a standard nonparametric percentile bootstrap. The paper
  notes (Section 4.2) that this can fail to attain nominal coverage for the CFD
  weighting estimator, since it need not be a regular estimator; `subsample_ci()` is
  the provably valid alternative.

Both `subsample_ci()` and `bootstrap_ci()` accept the moment-term and
regularization arguments of `cfd_weights()` (`moment_ratio`, `moment_features`,
`lambda = "ipw"`, ...), applied identically to the full-sample point estimate and to
every subsample/bootstrap replicate, so the interval describes the *same*
specification as the point estimate. A custom `Q`
(the `cfd_weights()` escape hatch bypassing kernel construction) is a different
matter: because it is a fixed matrix tied to the full sample's own size and arm
composition, it cannot be validly rebuilt for a subsample or bootstrap resample of a
different size/composition, so `subsample_ci()`/`bootstrap_ci()` raise an error if
`Q` is supplied — use `K`/`density` (or `method`, for `bootstrap_ci()`) instead,
which they *can* correctly rebuild per replicate.
- **`plugin_ci()`** / **`center_adjusted_plugin_ci()`** — closed-form,
  design-based (Horvitz-Thompson-/Hajek-style) variance estimators, giving a Wald CI
  directly without resampling. `center_adjusted_plugin_ci()` centers each arm's
  weighted squared residuals at an auxiliary in-sample outcome-regression fit rather
  than at the raw weighted group mean, adjusting for covariate heterogeneity within
  each arm; see `?center_adjusted_plugin_ci` for the exact formula and for how to
  substitute a different regression specification.
- **`wald_ci(estimate, se, alpha)`** — the general-purpose normal-approximation
  construction (`estimate +/- z*se`) used internally by the two functions above.
  `subsample_ci()` and `bootstrap_ci()` also each return a Wald CI (`$wald_ci`,
  alongside their `se`) as an alternative to their percentile CI, computed at no
  extra cost from the same replicates.

## Reproducing the paper's analyses

`system.file("scripts", package = "DistBalancing")` contains worked examples built
entirely from the package's own functions:

| Script | What it does |
|---|---|
| `01_simulation_final.R` | LATE simulation study (one job per batch index, for cluster array jobs) |
| `02_simulation_report.R` | Aggregates `01`'s output into summary tables |
| `03_weights_401k.R` | Computes CFD weights for the 401(k) application |
| `04_401k_final.R` | Per-resample 401(k) inference job (for cluster array jobs) |
| `05_401k_report.R` | Aggregates `04`'s output into the 401(k) results table |
| `06_ate_simulation_cluster.R` | ATE simulation study of distributional + user-specified-moment balancing: per dataset, fits `c0 = 0` and every (moment set × `c0`) configuration with the data-driven `lambda_n`, and reports point estimates and subsampling / plug-in / center-adjusted CIs (see below); one job per batch index |
| `07_ate_simulation_report.R` | Aggregates `06`'s output into the summary table (Bias, ESE, RMSE and RMSE relative to `c0 = 0`, Shapiro-Wilk, estimated SEs, CI length/coverage/time) |
| `08_moment_gamma_study.R` | Small standalone comparison of the moment term across absolute weights `moment_gamma` (superseded for the main study by `06`'s `moment_ratio` grid) |

Scripts `01`, `04`, and `06` are designed as cluster/array jobs:

```bash
Rscript 06_ate_simulation_cluster.R <BATCH>          # BATCH = 1 .. nrow(Hyperparameter)
# e.g. Slurm:
sbatch --array=1-<N_JOBS> --wrap='Rscript 06_ate_simulation_cluster.R $SLURM_ARRAY_TASK_ID'
```

### The ATE simulation study's design choices

`06_ate_simulation_cluster.R` simulates one dataset per job from `dgp_ate()` for
each (kernel, `kappa`, `N`, seed) cell — by default the Gaussian, Laplace, isotropic
(Matérn) and energy-distance kernels plus IPW and CBPS comparators, `kappa = 1`,
`N` in {500, 1000, 2000, 4000} and 55 replicates (1,320 jobs). On each dataset a
kernel job fits the purely distributional objective (`c0 = 0`) and every
combination of the moment set (`linear`: \(\Phi(X) = X\); `quadratic`:
\(\Phi(X) = (X, X^2)\)) and ratio `c0` in {0.1, 1, 10}, always with the data-driven
\(\lambda_n\). All of these are set at the top of the script. Because every
configuration is fitted to the same datasets, the report's `RMSE_rel` column is a
paired comparison against `c0 = 0`.

`kappa` controls how far \((1-e(X))\mu_1(X) + e(X)\mu_0(X)\) is from constant
(`kappa = 0`: constant; `kappa = 1`: a non-constant linear function of the
covariates). Two components of the design are modeling choices rather than fixed
quantities from the paper, and can be substituted:

1. **The `kappa` data-generating process** (`dgp_ate()`) interpolates linearly
   between the two boundary cases and uses specific, documented, easy-to-edit
   coefficient vectors for the propensity, baseline outcome, and non-constant target
   models — see `?dgp_ate`.
2. **The center-adjusted plug-in variance estimator** (`center_adjusted_plugin_ci()`)
   uses the auxiliary-regression construction described above. If a different
   variance construction is wanted, only that one function's body needs to change —
   both simulation scripts call it by name and do not depend on its internals.

**Cost note:** one full-sample fit takes about 1 s at `N = 1000` and 50 s at
`N = 4000`, and subsampling at a fixed `m = round(2*sqrt(N))` is cheap. For
`N <= 1000` the subsample size is chosen by `moonboot::estimate.m()`, which
dominates the runtime there (a kernel job at `N = 1000` takes roughly 25 minutes;
at `N = 4000`, about 11 minutes).
Peak memory at `N = 4000` is about 2 GB. The script header lists the per-`N`
timings and the knobs (`B_SS`, `M_SEARCH_MAX_N`, `M_SEARCH_R`) to adjust.

## Numerically solving the balancing QP

`cfd_weights()` solves its quadratic program via `solve_qp_safe()`, which supports
two interchangeable backends (`quadprog::solve.QP()`, tried first by default for
speed, and `optiSolve::solvecop()`, used in the paper's own simulation and data
analysis — pass `prefer_solver = "optiSolve"` to match that exactly) and guards
against numerical indefiniteness that can arise for kernels that are only
*conditionally* negative definite, such as the energy-distance kernel of Example 4.
See `?solve_qp_safe` for details.

## Testing

```r
devtools::test(".")       # unit tests across kernels, weights, estimators, dgp, inference
devtools::check(".")      # 0 errors (a Suggests-availability NOTE only, when offline)
```

## References

Santra, D., Chen, G., and Park, C. (2026). *Distributional Balancing for Causal
Inference: A Unified Framework via Characteristic Function Distance.*

Politis, D. N., Romano, J. P., and Wolf, M. (1999). *Subsampling.* Springer.

Hainmueller, J. (2012). Entropy Balancing for Causal Effects. *Political Analysis.*

Zubizarreta, J. R. (2015). Stable Weights that Balance Covariates for Estimation
with Incomplete Outcome Data. *JASA.*

Imai, K. and Ratkovic, M. (2014). Covariate Balancing Propensity Score. *JRSS-B.*
